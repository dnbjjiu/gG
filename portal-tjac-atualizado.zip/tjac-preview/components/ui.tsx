import React from 'react';

export interface AvisoProps {
  tipo?: 'info' | 'alerta' | 'erro' | 'sucesso';
  children: React.ReactNode;
  className?: string;
}

export function Aviso({ tipo = 'info', children, className = '' }: AvisoProps) {
  const estilos: Record<NonNullable<AvisoProps['tipo']>, string> = {
    info: 'bg-white border-linha text-tinta',
    alerta: 'bg-[#FFFDF7] border-ouro/50 text-tinta',
    erro: 'bg-[#FDF4F5] border-carmim/40 text-carmimEscuro',
    sucesso: 'bg-[#F3FAF6] border-verde/40 text-verde',
  };
  const rotulos: Record<NonNullable<AvisoProps['tipo']>, string> = {
    info: 'Informação',
    alerta: 'Atenção',
    erro: 'Erro',
    sucesso: 'Confirmação',
  };

  return (
    <div
      role={tipo === 'erro' ? 'alert' : 'status'}
      className={`border rounded-lg px-4 py-3 text-sm leading-relaxed ${estilos[tipo]} ${className}`}
    >
      <span className="sr-only">{rotulos[tipo]}: </span>
      {children}
    </div>
  );
}

export interface SecaoProps {
  numero: string;
  titulo: string;
  subtitulo?: string;
  children: React.ReactNode;
  acaoDireita?: React.ReactNode;
}

export function Secao({ numero, titulo, subtitulo, children, acaoDireita }: SecaoProps) {
  return (
    <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-linha">
        <div className="space-y-1">
          <h2 className="text-base sm:text-lg font-bold text-tinta leading-snug">
            <span className="text-carmim tabular-nums mr-1.5">{numero}.</span>
            {titulo}
          </h2>
          {subtitulo && <p className="text-xs sm:text-sm text-suave leading-relaxed">{subtitulo}</p>}
        </div>
        {acaoDireita && <div className="shrink-0">{acaoDireita}</div>}
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export interface CampoProps {
  id: string;
  rotulo: string;
  obrigatorio?: boolean;
  ajuda?: string;
  erro?: string;
  children: React.ReactNode;
}

export function Campo({ id, rotulo, obrigatorio, ajuda, erro, children }: CampoProps) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-xs sm:text-sm font-semibold text-tinta">
        {rotulo}
        {obrigatorio && <span className="text-carmim ml-1" title="Campo obrigatório">*</span>}
      </label>
      {children}
      {ajuda && !erro && <p className="text-xs text-suave leading-normal">{ajuda}</p>}
      {erro && <p className="text-xs font-medium text-carmim">{erro}</p>}
    </div>
  );
}

export const CLASSE_INPUT =
  'w-full rounded-md border border-linha bg-white px-3 py-2 text-sm text-tinta placeholder:text-suave/60 focus:border-carmim focus:outline-none focus:ring-2 focus:ring-carmim/20 disabled:bg-fundo disabled:text-suave';

export function SeloStatus({ status }: { status?: string }) {
  const s = (status || 'PENDENTE').toUpperCase();
  const mapa: Record<string, { rotulo: string; classe: string }> = {
    ENVIADO: {
      rotulo: 'Enviado',
      classe: 'bg-emerald-50 text-emerald-900 border-emerald-200',
    },
    EM_ENVIO: {
      rotulo: 'Em envio',
      classe: 'bg-amber-50 text-amber-900 border-amber-200',
    },
    PENDENTE: {
      rotulo: 'Pendente',
      classe: 'bg-fundo text-suave border-linha',
    },
    EM_ANALISE: {
      rotulo: 'Em análise',
      classe: 'bg-amber-50 text-amber-900 border-amber-200',
    },
    PROVIDO: {
      rotulo: 'Provido',
      classe: 'bg-emerald-50 text-emerald-900 border-emerald-200',
    },
    PARCIALMENTE_PROVIDO: {
      rotulo: 'Parcialmente provido',
      classe: 'bg-emerald-50 text-emerald-900 border-emerald-200',
    },
    IMPROVIDO: {
      rotulo: 'Improvido',
      classe: 'bg-red-50 text-red-900 border-red-200',
    },
    NAO_CONHECIDO: {
      rotulo: 'Não conhecido',
      classe: 'bg-red-50 text-red-900 border-red-200',
    },
  };
  const item = mapa[s] || { rotulo: s, classe: 'bg-fundo text-suave border-linha' };
  return (
    <span
      className={`inline-block px-2 py-0.5 rounded border text-[11px] font-semibold ${item.classe}`}
    >
      {item.rotulo}
    </span>
  );
}

