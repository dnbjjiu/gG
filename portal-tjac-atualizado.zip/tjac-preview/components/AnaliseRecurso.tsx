import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PORTARIA, TIPOS_IMPUGNACAO_INFO, TIPOS_UNIDADE_INFO } from '../catalogo';
import {
  ehAdmin,
  papelPadraoUsuario,
  podeAtuarComoComissao,
  podeAtuarComoSumae,
} from '../config';
import {
  ORDEM_TRAMITACAO,
  ROTULO_ESTADO_TRAMITACAO,
  baixarBytesPdfNoNavegador,
  detectarFaltaEvidenciaRecurso,
  gerarPdfDecisaoComissaoSei,
  gerarPdfParecerTecnicoSei,
} from '../services/analiseLogica';
import { ApiError, api } from '../services/api';
import type {
  AnaliseRecursoProtocolo,
  ConclusaoTecnicaItemSumae,
  DecisaoFinalComissao,
  DecisaoItemComissao,
  EstadoTramitacao,
  PapelInstitucional,
  ParecerTecnicoSumae,
  RecomendacaoTecnicaItem,
  RecursoAdmin,
  ResultadoGeralDecisao,
  ResultadoMeritoItem,
  Usuario,
} from '../types';
import { formatarBytes, formatarCpf, formatarDataHora } from '../utils';
import { LogoTJAC } from './LogoTJAC';
import { Aviso, CLASSE_INPUT, SeloStatus } from './ui';

interface AnaliseRecursoProps {
  idToken: string;
  usuario: Usuario;
  protocoloInicial?: string;
  onSelecionarProtocolo?: (protocolo: string) => void;
  onVoltarLista?: () => void;
}

const ROTULO_RECOMENDACAO_SUMAE: Record<RecomendacaoTecnicaItem, string> = {
  ACOLHER_INTEGRALMENTE: 'Acolher integralmente (Deferir)',
  ACOLHER_PARCIALMENTE: 'Acolher parcialmente',
  REJEITAR: 'Rejeitar / Manter resultado preliminar',
  NAO_CONHECER: 'Opina pelo Não Conhecimento (falta de requisito formal)',
};

const ROTULO_RESULTADO_DECISAO: Record<ResultadoGeralDecisao, string> = {
  NAO_CONHECIDO: 'Não conhecido',
  PROVIDO: 'Provido',
  PARCIALMENTE_PROVIDO: 'Parcialmente provido',
  DESPROVIDO: 'Desprovido',
};

export function AnaliseRecurso({
  idToken,
  usuario,
  protocoloInicial,
  onSelecionarProtocolo,
  onVoltarLista,
}: AnaliseRecursoProps) {
  const [listaProtocolos, setListaProtocolos] = useState<
    { protocolo: string; unidade: string; estadoTramitacao: EstadoTramitacao; processoSei: string }[]
  >([]);
  const [protocoloAtivo, setProtocoloAtivo] = useState<string>(protocoloInicial || '');
  const [recurso, setRecurso] = useState<RecursoAdmin | null>(null);
  const [analise, setAnalise] = useState<AnaliseRecursoProtocolo | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  // Papel institucional ativo para verificação no cliente e no servidor
  const [papelAtivo, setPapelAtivo] = useState<PapelInstitucional>(() =>
    papelPadraoUsuario(usuario.email)
  );

  // Vínculo SEI
  const [inputProcessoSei, setInputProcessoSei] = useState('');
  const [editandoSei, setEditandoSei] = useState(false);
  const [msgVinculoSei, setMsgVinculoSei] = useState('');

  // Estado editável do Parecer Técnico da SUMAE
  const [formParecer, setFormParecer] = useState<
    Omit<
      ParecerTecnicoSumae,
      | 'statusDocumento'
      | 'versao'
      | 'atualizadoEm'
      | 'emitidoEm'
      | 'codigoVerificadorSei'
      | 'codigoCrcSei'
      | 'ultimoEmissionId'
    >
  >({
    numeroParecer: '001/2026',
    sintesePedido: '',
    tempestivo: true,
    conferenciaPrazoEvidencias: '',
    possuiFaltaEvidenciaObrigatoria: false,
    registroFaltasEvidencias: '',
    dadosFontesConsultadas: '',
    filtrosAplicados: '',
    periodoReferencia: '',
    metodologiaMemoriaCalculo: '',
    conclusoesPorItem: [],
    conclusaoGeral: '',
    responsavelNome: '',
    responsavelCargo: '',
    responsavelEmail: '',
    lotacao: '',
    encaminhamentoComissao: '',
    justificativaRetificacao: '',
  });

  // Estado editável da Decisão Final da Comissão Revisora
  const [formDecisao, setFormDecisao] = useState<
    Omit<
      DecisaoFinalComissao,
      | 'statusDocumento'
      | 'versao'
      | 'atualizadoEm'
      | 'emitidoEm'
      | 'codigoVerificadorSei'
      | 'codigoCrcSei'
      | 'ultimoEmissionId'
    >
  >({
    numeroDecisao: 'DEC-001/2026',
    relatorio: '',
    conhecido: true,
    faltaEvidenciaObrigatoria: false,
    fundamentacaoAdmissibilidade: '',
    resultadoGeral: 'PROVIDO',
    fundamentacaoGeral: '',
    itensDecididos: [],
    dispositivo: '',
    encaminhamentoCienciaProvidencias: '',
    relatorNome: '',
    relatorCargo: '',
    relatorEmail: '',
    membrosComissao: '',
    justificativaRetificacao: '',
  });

  // Controle de salvamento / idempotência contra duplo clique
  const [processandoParecer, setProcessandoParecer] = useState(false);
  const [processandoDecisao, setProcessandoDecisao] = useState(false);
  const parecerEmissionKeyRef = useRef<string>(`em-sumae-${Date.now()}`);
  const decisaoEmissionKeyRef = useRef<string>(`em-com-${Date.now()}`);

  // Modal de Visualização no Modelo Oficial SEI (Parecer ou Decisão)
  const [modalVisualizacao, setModalVisualizacao] = useState<{
    tipo: 'PARECER_SUMAE' | 'DECISAO_COMISSAO';
    parecer?: ParecerTecnicoSumae;
    decisao?: DecisaoFinalComissao;
  } | null>(null);

  const sincronizarFormsComAnalise = useCallback((an: AnaliseRecursoProtocolo) => {
    setInputProcessoSei(an.processoSei);
    const p = an.parecerSumae;
    setFormParecer({
      numeroParecer: p.numeroParecer,
      sintesePedido: p.sintesePedido,
      tempestivo: p.tempestivo,
      conferenciaPrazoEvidencias: p.conferenciaPrazoEvidencias,
      possuiFaltaEvidenciaObrigatoria: p.possuiFaltaEvidenciaObrigatoria,
      registroFaltasEvidencias: p.registroFaltasEvidencias,
      dadosFontesConsultadas: p.dadosFontesConsultadas,
      filtrosAplicados: p.filtrosAplicados,
      periodoReferencia: p.periodoReferencia,
      metodologiaMemoriaCalculo: p.metodologiaMemoriaCalculo,
      conclusoesPorItem: p.conclusoesPorItem.map((c) => ({ ...c })),
      conclusaoGeral: p.conclusaoGeral,
      responsavelNome: p.responsavelNome,
      responsavelCargo: p.responsavelCargo,
      responsavelEmail: p.responsavelEmail,
      lotacao: p.lotacao,
      encaminhamentoComissao: p.encaminhamentoComissao,
      justificativaRetificacao: '',
    });

    const d = an.decisaoComissao;
    setFormDecisao({
      numeroDecisao: d.numeroDecisao,
      relatorio: d.relatorio,
      conhecido: d.conhecido,
      faltaEvidenciaObrigatoria: d.faltaEvidenciaObrigatoria,
      fundamentacaoAdmissibilidade: d.fundamentacaoAdmissibilidade,
      resultadoGeral: d.resultadoGeral,
      fundamentacaoGeral: d.fundamentacaoGeral,
      itensDecididos: d.itensDecididos.map((it) => ({ ...it })),
      dispositivo: d.dispositivo,
      encaminhamentoCienciaProvidencias: d.encaminhamentoCienciaProvidencias,
      relatorNome: d.relatorNome,
      relatorCargo: d.relatorCargo,
      relatorEmail: d.relatorEmail,
      membrosComissao: d.membrosComissao,
      justificativaRetificacao: '',
    });
  }, []);

  const carregarProtocolo = useCallback(
    async (prot: string) => {
      if (!prot) return;
      setCarregando(true);
      setErro('');
      try {
        const res = await api.obterAnaliseRecurso(idToken, prot);
        setRecurso(res.recurso);
        setAnalise(res.analise);
        sincronizarFormsComAnalise(res.analise);
        parecerEmissionKeyRef.current = `em-sumae-${prot}-v${(res.analise.parecerSumae.versao || 0) + 1}`;
        decisaoEmissionKeyRef.current = `em-com-${prot}-v${(res.analise.decisaoComissao.versao || 0) + 1}`;
      } catch (e) {
        setErro(
          e instanceof ApiError || e instanceof Error
            ? e.message
            : 'Não foi possível carregar a Análise do Recurso.'
        );
      } finally {
        setCarregando(false);
      }
    },
    [idToken, sincronizarFormsComAnalise]
  );

  // Carrega a lista de protocolos disponíveis para seleção rápida
  useEffect(() => {
    let ativo = true;
    const buscarLista = async () => {
      try {
        if (ehAdmin(usuario.email)) {
          const adm = await api.adminList(idToken);
          if (!ativo) return;
          const itens = adm.recursos.map((r) => ({
            protocolo: r.protocolo,
            unidade: `${r.unidade.codigo} — ${r.unidade.nome}`,
            estadoTramitacao: (r.estadoTramitacao || 'RECEBIDO') as EstadoTramitacao,
            processoSei: r.processoSei || '',
          }));
          setListaProtocolos(itens);
          const alvo = protocoloInicial || itens[0]?.protocolo || '';
          if (alvo) {
            setProtocoloAtivo(alvo);
            await carregarProtocolo(alvo);
          } else {
            setCarregando(false);
          }
        } else {
          const meus = await api.myAppeals(idToken);
          if (!ativo) return;
          const itens = meus.recursos.map((r) => ({
            protocolo: r.protocolo,
            unidade: r.unidade,
            estadoTramitacao: (r.estadoTramitacao || 'RECEBIDO') as EstadoTramitacao,
            processoSei: r.processoSei || '',
          }));
          setListaProtocolos(itens);
          const alvo = protocoloInicial || itens[0]?.protocolo || '';
          if (alvo) {
            setProtocoloAtivo(alvo);
            await carregarProtocolo(alvo);
          } else {
            setCarregando(false);
          }
        }
      } catch (e) {
        if (!ativo) return;
        setErro(e instanceof Error ? e.message : 'Erro ao listar recursos cadastrados.');
        setCarregando(false);
      }
    };
    buscarLista();
    return () => {
      ativo = false;
    };
  }, [idToken, usuario.email, protocoloInicial, carregarProtocolo]);

  const trocarProtocolo = async (novoProt: string) => {
    setProtocoloAtivo(novoProt);
    setSucesso('');
    setMsgVinculoSei('');
    if (onSelecionarProtocolo) onSelecionarProtocolo(novoProt);
    await carregarProtocolo(novoProt);
  };

  // Verificação de permissões por papel
  const usuarioPodeSumae = podeAtuarComoSumae(usuario.email);
  const usuarioPodeComissao = podeAtuarComoComissao(usuario.email);
  const podeEditarParecer = usuarioPodeSumae && papelAtivo === 'SUMAE';
  const podeEditarDecisao = usuarioPodeComissao && papelAtivo === 'COMISSAO';

  // Verificação automática de evidências obrigatórias (Item 3)
  const verificacaoEvidenciasOriginal = useMemo(() => {
    if (!recurso) return { faltaEvidencia: false, detalhesFaltas: [] as string[] };
    return detectarFaltaEvidenciaRecurso(recurso);
  }, [recurso]);

  // Regra crítica (item 3): quando faltar qualquer evidência obrigatória,
  // registra resultado "Não conhecido", exige fundamentação e mantém mérito desabilitado.
  const bloqueioMeritoPorFaltaEvidencia =
    verificacaoEvidenciasOriginal.faltaEvidencia ||
    formParecer.possuiFaltaEvidenciaObrigatoria ||
    formDecisao.faltaEvidenciaObrigatoria ||
    !formDecisao.conhecido;

  // Mantém o resultadoGeral sincronizado como "NAO_CONHECIDO" quando houver falta de evidência obrigatória
  useEffect(() => {
    if (bloqueioMeritoPorFaltaEvidencia && formDecisao.resultadoGeral !== 'NAO_CONHECIDO') {
      setFormDecisao((prev) => ({
        ...prev,
        conhecido: false,
        resultadoGeral: 'NAO_CONHECIDO',
      }));
    }
  }, [bloqueioMeritoPorFaltaEvidencia, formDecisao.resultadoGeral]);

  const handleVincularSei = async (forcarAtualizacao = false) => {
    if (!recurso) return;
    setErro('');
    setMsgVinculoSei('');
    try {
      const res = await api.vincularProcessoSei(idToken, {
        protocolo: recurso.protocolo,
        processoSei: inputProcessoSei.trim(),
        forcarAtualizacao,
      });
      setAnalise(res.analise);
      setInputProcessoSei(res.processoSei);
      setEditandoSei(false);
      setMsgVinculoSei(
        res.reutilizado
          ? `O número SEI ${res.processoSei} já estava registrado para o protocolo ${recurso.protocolo} — vínculo existente reutilizado.`
          : `Processo SEI ${res.processoSei} vinculado individualmente ao protocolo ${recurso.protocolo}.`
      );
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Falha ao vincular processo SEI.');
    }
  };

  const atualizarConclusaoItemSumae = (
    itemN: number,
    parcial: Partial<ConclusaoTecnicaItemSumae>
  ) => {
    setFormParecer((prev) => ({
      ...prev,
      conclusoesPorItem: prev.conclusoesPorItem.map((c) =>
        c.itemN === itemN ? { ...c, ...parcial } : c
      ),
    }));
  };

  const atualizarDecisaoItemComissao = (
    itemN: number,
    parcial: Partial<DecisaoItemComissao>
  ) => {
    setFormDecisao((prev) => ({
      ...prev,
      itensDecididos: prev.itensDecididos.map((it) =>
        it.itemN === itemN ? { ...it, ...parcial } : it
      ),
    }));
  };

  const executarAcaoParecerSumae = async (acao: 'SALVAR_RASCUNHO' | 'EMITIR_ENCAMINHAR') => {
    if (!recurso || !analise || processandoParecer) return;
    setProcessandoParecer(true);
    setErro('');
    setSucesso('');
    try {
      const res = await api.salvarParecerSumae(idToken, {
        protocolo: recurso.protocolo,
        processoSei: inputProcessoSei.trim() || analise.processoSei,
        papelAtivo,
        acao,
        emissionRequestId: parecerEmissionKeyRef.current,
        parecer: formParecer,
      });
      setAnalise(res.analise);
      sincronizarFormsComAnalise(res.analise);
      if (acao === 'EMITIR_ENCAMINHAR') {
        // Prepara nova chave apenas para eventual futura retificação (v2+)
        parecerEmissionKeyRef.current = `em-sumae-${recurso.protocolo}-v${res.analise.parecerSumae.versao + 1}-${Date.now()}`;
        setSucesso(
          res.reaproveitado
            ? `Emissão já registrada anteriormente (v${res.analise.parecerSumae.versao}) — evitada duplicação.`
            : `Parecer Técnico SUMAE n.º ${res.analise.parecerSumae.numeroParecer} (v${res.analise.parecerSumae.versao}) emitido com sucesso e encaminhado à Comissão Revisora!`
        );
      } else {
        setSucesso('Rascunho do Parecer Técnico da SUMAE salvo no protocolo.');
      }
    } catch (e) {
      setErro(
        e instanceof ApiError || e instanceof Error
          ? e.message
          : 'Erro ao processar o Parecer Técnico da SUMAE.'
      );
    } finally {
      setProcessandoParecer(false);
    }
  };

  const executarAcaoDecisaoComissao = async (acao: 'SALVAR_RASCUNHO' | 'EMITIR_DECISAO') => {
    if (!recurso || !analise || processandoDecisao) return;
    setProcessandoDecisao(true);
    setErro('');
    setSucesso('');
    try {
      const res = await api.salvarDecisaoComissao(idToken, {
        protocolo: recurso.protocolo,
        processoSei: inputProcessoSei.trim() || analise.processoSei,
        papelAtivo,
        acao,
        emissionRequestId: decisaoEmissionKeyRef.current,
        decisao: formDecisao,
      });
      setAnalise(res.analise);
      sincronizarFormsComAnalise(res.analise);
      if (acao === 'EMITIR_DECISAO') {
        decisaoEmissionKeyRef.current = `em-com-${recurso.protocolo}-v${res.analise.decisaoComissao.versao + 1}-${Date.now()}`;
        setSucesso(
          res.reaproveitado
            ? `Decisão já emitida anteriormente (v${res.analise.decisaoComissao.versao}) — evitada duplicação.`
            : `Decisão Final da Comissão Revisora (${res.analise.decisaoComissao.numeroDecisao} — v${res.analise.decisaoComissao.versao}) emitida com sucesso! Tramitação atualizada para “Decidido”.`
        );
      } else {
        setSucesso('Rascunho da Decisão da Comissão Revisora salvo no protocolo.');
      }
    } catch (e) {
      setErro(
        e instanceof ApiError || e instanceof Error
          ? e.message
          : 'Erro ao processar a Decisão Final da Comissão Revisora.'
      );
    } finally {
      setProcessandoDecisao(false);
    }
  };

  const alternarDivulgacaoCronograma = async (divulgado: boolean) => {
    if (!recurso) return;
    setErro('');
    try {
      const res = await api.atualizarDivulgacaoResultado(idToken, {
        protocolo: recurso.protocolo,
        divulgado,
      });
      setAnalise(res.analise);
      setSucesso(
        divulgado
          ? 'Etapa de divulgação oficial ativada para este protocolo conforme cronograma do Prêmio.'
          : 'Resultado mantido restrito à tramitação interna até a data oficial de divulgação.'
      );
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Erro ao atualizar etapa de divulgação.');
    }
  };

  const baixarPdfParecer = (parecerCustom?: ParecerTecnicoSumae) => {
    if (!recurso || !analise) return;
    const alvo: ParecerTecnicoSumae = parecerCustom || {
      ...analise.parecerSumae,
      ...formParecer,
    };
    setErro('');
    try {
      const bytes = gerarPdfParecerTecnicoSei(recurso, analise, alvo);
      const ver = Math.max(1, alvo.versao || 1);
      baixarBytesPdfNoNavegador(
        bytes,
        `Parecer_Tecnico_SUMAE_${recurso.protocolo}_v${ver}_SEI_${analise.processoSei.replace(/\D/g, '')}.pdf`
      );
    } catch {
      setErro('Não foi possível baixar o PDF. Tente novamente.');
    }
  };

  const baixarPdfDecisao = (decisaoCustom?: DecisaoFinalComissao) => {
    if (!recurso || !analise) return;
    const alvo: DecisaoFinalComissao = decisaoCustom || {
      ...analise.decisaoComissao,
      ...formDecisao,
    };
    setErro('');
    try {
      const bytes = gerarPdfDecisaoComissaoSei(recurso, analise, alvo);
      const ver = Math.max(1, alvo.versao || 1);
      baixarBytesPdfNoNavegador(
        bytes,
        `Decisao_Comissao_Revisora_${recurso.protocolo}_v${ver}_SEI_${analise.processoSei.replace(/\D/g, '')}.pdf`
      );
    } catch {
      setErro('Não foi possível baixar o PDF. Tente novamente.');
    }
  };

  if (carregando && !recurso) {
    return (
      <div className="bg-white border border-linha rounded-lg p-6 text-sm text-suave">
        Carregando módulo de Análise do Recurso (Parecer Técnico da SUMAE e Decisão da Comissão Revisora)…
      </div>
    );
  }

  if (!recurso || !analise) {
    return (
      <div className="bg-white border border-linha rounded-lg p-6 space-y-4">
        <Aviso tipo="alerta">
          Selecione um recurso já cadastrado para abrir a aba <strong>Análise do Recurso</strong>.
        </Aviso>
        {onVoltarLista && (
          <button
            type="button"
            onClick={onVoltarLista}
            className="px-4 py-2 rounded-md bg-carmim text-white text-xs font-semibold cursor-pointer"
          >
            ← Voltar para a lista de recursos
          </button>
        )}
      </div>
    );
  }

  const rotuloTipoUnidade =
    TIPOS_UNIDADE_INFO.find((t) => t.codigo === recurso.unidade.tipo)?.rotulo ||
    recurso.unidade.tipo;
  const indiceEstadoAtual = ORDEM_TRAMITACAO.indexOf(analise.estadoTramitacao);

  return (
    <div className="space-y-6">
      {/* =====================================================================
       * MODAL DE VISUALIZAÇÃO DO DOCUMENTO NO PADRÃO SEI/TJAC (PARECER OU DECISÃO)
       * =================================================================== */}
      {modalVisualizacao && (
        <div
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white border border-linha rounded-lg max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="px-5 py-3.5 bg-fundo border-b border-linha flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-wider font-bold text-carmim">
                  Visualização de Documento Oficial (Modelo Fixo para Juntada ao SEI)
                </p>
                <h3 className="text-sm sm:text-base font-bold text-tinta truncate">
                  {modalVisualizacao.tipo === 'PARECER_SUMAE'
                    ? `Parecer Técnico SUMAE n.º ${modalVisualizacao.parecer?.numeroParecer} — Protocolo ${recurso.protocolo}`
                    : `Decisão Final da Comissão Revisora (${modalVisualizacao.decisao?.numeroDecisao}) — Protocolo ${recurso.protocolo}`}
                </h3>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {modalVisualizacao.tipo === 'PARECER_SUMAE' ? (
                  <button
                    type="button"
                    onClick={() => baixarPdfParecer(modalVisualizacao.parecer)}
                    className="px-3.5 py-1.5 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold cursor-pointer"
                  >
                    Baixar PDF para Juntada ao SEI
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => baixarPdfDecisao(modalVisualizacao.decisao)}
                    className="px-3.5 py-1.5 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold cursor-pointer"
                  >
                    Baixar PDF para Juntada ao SEI
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-tinta cursor-pointer"
                >
                  Imprimir
                </button>
                <button
                  type="button"
                  onClick={() => setModalVisualizacao(null)}
                  className="px-3 py-1.5 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-suave hover:text-tinta cursor-pointer"
                >
                  Fechar ✕
                </button>
              </div>
            </div>

            {/* Corpo do Documento Formatado conforme Modelo Oficial SEI (págs. 23–28 do PDF) */}
            <div className="p-6 sm:p-10 overflow-y-auto space-y-6 bg-white text-tinta text-xs sm:text-sm leading-relaxed">
              <div className="text-center space-y-1.5 border-b border-linha pb-4">
                <div className="flex justify-center mb-2">
                  <LogoTJAC variante="carmim" mostrarSubtituloPortal={false} />
                </div>
                <p className="text-xs font-bold uppercase tracking-wider text-tinta">
                  PODER JUDICIÁRIO DO ESTADO DO ACRE
                </p>
                <p className="text-xs font-semibold text-suave">
                  {modalVisualizacao.tipo === 'PARECER_SUMAE'
                    ? 'Subsecretaria de Monitoramento e Análise Estratégica — SUMAE/SEGOV'
                    : 'Comissão Revisora do Prêmio TJAC de Qualidade 2026 / Divisão de Consultoria e Suporte Jurídico Institucional'}
                </p>
                <h4 className="text-base sm:text-lg font-bold text-tinta pt-2 uppercase">
                  {modalVisualizacao.tipo === 'PARECER_SUMAE' ? 'PARECER TÉCNICO' : 'DECISÃO'}
                </h4>
              </div>

              {modalVisualizacao.tipo === 'PARECER_SUMAE' && modalVisualizacao.parecer && (
                <div className="space-y-4">
                  <div className="border border-tinta/40 p-4 space-y-1 text-xs">
                    <p>
                      <strong>Parecer Técnico SUMAE n.º:</strong>{' '}
                      {modalVisualizacao.parecer.numeroParecer} (Versão v
                      {Math.max(1, modalVisualizacao.parecer.versao)})
                    </p>
                    <p>
                      <strong>Processo SEI:</strong>{' '}
                      <span className="font-mono">{analise.processoSei}</span> ·{' '}
                      <strong>Protocolo do Recurso:</strong>{' '}
                      <span className="font-mono">{recurso.protocolo}</span>
                    </p>
                    <p>
                      <strong>Data de Análise:</strong>{' '}
                      {formatarDataHora(
                        modalVisualizacao.parecer.emitidoEm ||
                          modalVisualizacao.parecer.atualizadoEm ||
                          new Date().toISOString()
                      )}
                    </p>
                    <p>
                      <strong>Analista Técnico:</strong>{' '}
                      {modalVisualizacao.parecer.responsavelNome} (
                      {modalVisualizacao.parecer.responsavelCargo})
                    </p>
                    <p>
                      <strong>Unidade Recorrente:</strong> {recurso.unidade.nome} (
                      {recurso.unidade.comarca}–AC)
                    </p>
                    <p>
                      <strong>Respondente:</strong> {recurso.responsavel.nome} (
                      {recurso.responsavel.cargo})
                    </p>
                    <p>
                      <strong>E-mail:</strong> {recurso.emailGoogle} · <strong>Telefone:</strong>{' '}
                      {recurso.responsavel.telefone}
                    </p>
                  </div>

                  <div className="border border-tinta/40 p-4 space-y-2">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">I. OBJETO DO RECURSO</h5>
                    <p className="whitespace-pre-wrap">{modalVisualizacao.parecer.sintesePedido}</p>
                  </div>

                  <div className="border border-tinta/40 p-4 space-y-3">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">
                      II. ANÁLISE PRÉVIA DOS ARGUMENTOS APRESENTADOS
                    </h5>
                    <div className="space-y-1">
                      <p className="font-semibold">
                        2.1. Conferência do prazo e das evidências obrigatórias:
                      </p>
                      <p className="whitespace-pre-wrap">
                        {modalVisualizacao.parecer.conferenciaPrazoEvidencias}
                      </p>
                      {modalVisualizacao.parecer.possuiFaltaEvidenciaObrigatoria && (
                        <div className="p-2.5 bg-red-50 border border-red-200 rounded text-xs text-red-950">
                          <strong>Registro de faltas documentais (Art. 13):</strong>
                          <p className="whitespace-pre-wrap mt-1">
                            {modalVisualizacao.parecer.registroFaltasEvidencias}
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="space-y-1">
                      <p className="font-semibold">
                        2.2. Dados e fontes consultadas, filtros aplicados e período de referência:
                      </p>
                      <p>
                        <strong>Fontes consultadas:</strong>{' '}
                        {modalVisualizacao.parecer.dadosFontesConsultadas}
                      </p>
                      <p>
                        <strong>Filtros aplicados:</strong>{' '}
                        {modalVisualizacao.parecer.filtrosAplicados}
                      </p>
                      <p>
                        <strong>Período de referência:</strong>{' '}
                        {modalVisualizacao.parecer.periodoReferencia}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="font-semibold">
                        2.3. Metodologia, memória de cálculo e fundamentação técnica:
                      </p>
                      <p className="whitespace-pre-wrap">
                        {modalVisualizacao.parecer.metodologiaMemoriaCalculo}
                      </p>
                    </div>
                  </div>

                  <div className="border border-tinta/40 p-4 space-y-3">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">
                      III. CONCLUSÃO DO PARECER TÉCNICO
                    </h5>
                    {modalVisualizacao.parecer.conclusoesPorItem.map((c) => (
                      <div key={c.itemN} className="p-3 bg-fundo/60 border border-linha rounded space-y-1">
                        <p className="font-bold">
                          Item #{c.itemN} — {c.sigla} ({c.indicador}) · Recomendação:{' '}
                          <span className="text-carmim">
                            {ROTULO_RECOMENDACAO_SUMAE[c.recomendacao]}
                          </span>
                        </p>
                        <p className="text-xs text-suave tabular-nums">
                          Pontuação Preliminar: <strong>{c.pontuacaoPreliminar} pts</strong> →
                          Pontuação Recomendada: <strong>{c.pontuacaoRecomendada} pts</strong> ·
                          Impacto: <strong>{c.impactoPontuacao}</strong>
                        </p>
                        <p className="whitespace-pre-wrap text-xs">{c.conclusaoTecnica}</p>
                      </div>
                    ))}
                    <p className="whitespace-pre-wrap font-medium">
                      {modalVisualizacao.parecer.conclusaoGeral}
                    </p>
                  </div>

                  <div className="border border-tinta/40 p-4 space-y-3">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">IV. ENCAMINHAMENTO</h5>
                    <p className="whitespace-pre-wrap">
                      {modalVisualizacao.parecer.encaminhamentoComissao}
                    </p>
                    <p>É o Parecer, S.M.J.</p>
                    <div className="pt-2">
                      <p className="font-bold">{modalVisualizacao.parecer.responsavelNome}</p>
                      <p className="text-xs text-suave">
                        {modalVisualizacao.parecer.responsavelCargo} —{' '}
                        {modalVisualizacao.parecer.lotacao}
                      </p>
                    </div>
                  </div>

                  <div className="border-t border-linha pt-3 text-xs text-suave space-y-1">
                    <p>
                      <strong>sei! Assinatura Eletrônica:</strong> Documento assinado
                      eletronicamente por{' '}
                      <strong className="text-tinta">
                        {modalVisualizacao.parecer.responsavelNome}
                      </strong>
                      , conforme art. 1º, III, &ldquo;b&rdquo;, da Lei 11.419/2006.
                    </p>
                    <p className="font-mono">
                      Processo SEI: {analise.processoSei} · Código verificador:{' '}
                      <strong>
                        {modalVisualizacao.parecer.codigoVerificadorSei || 'RASCUNHO'}
                      </strong>{' '}
                      · Código CRC:{' '}
                      <strong>{modalVisualizacao.parecer.codigoCrcSei || 'PENDENTE'}</strong>
                    </p>
                  </div>
                </div>
              )}

              {modalVisualizacao.tipo === 'DECISAO_COMISSAO' && modalVisualizacao.decisao && (
                <div className="space-y-4">
                  <div className="border border-tinta/40 p-4 space-y-1 text-xs">
                    <p>
                      <strong>Processo Administrativo SEI nº:</strong>{' '}
                      <span className="font-mono">{analise.processoSei}</span>
                    </p>
                    <p>
                      <strong>Protocolo do Recurso:</strong>{' '}
                      <span className="font-mono">{recurso.protocolo}</span> ·{' '}
                      <strong>Local:</strong> Rio Branco–AC
                    </p>
                    <p>
                      <strong>Unidade Recorrente:</strong> {recurso.unidade.codigo} —{' '}
                      {recurso.unidade.nome} ({recurso.unidade.comarca})
                    </p>
                    <p>
                      <strong>Decisão n.º:</strong> {modalVisualizacao.decisao.numeroDecisao}{' '}
                      (Versão v{Math.max(1, modalVisualizacao.decisao.versao)}) ·{' '}
                      <strong>Resultado Geral:</strong>{' '}
                      <span className="font-bold text-carmim">
                        {ROTULO_RESULTADO_DECISAO[modalVisualizacao.decisao.resultadoGeral]}
                      </span>
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">I – RELATÓRIO</h5>
                    <p className="whitespace-pre-wrap">{modalVisualizacao.decisao.relatorio}</p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">
                      II – EXAME DE ADMISSIBILIDADE E FUNDAMENTAÇÃO
                    </h5>
                    <p className="font-semibold">
                      1. Admissibilidade:{' '}
                      {modalVisualizacao.decisao.conhecido &&
                      !modalVisualizacao.decisao.faltaEvidenciaObrigatoria
                        ? 'RECURSO CONHECIDO'
                        : 'RECURSO NÃO CONHECIDO (Art. 13 e Anexo III, item 3)'}
                    </p>
                    <p className="whitespace-pre-wrap">
                      {modalVisualizacao.decisao.fundamentacaoAdmissibilidade}
                    </p>

                    {modalVisualizacao.decisao.conhecido &&
                      !modalVisualizacao.decisao.faltaEvidenciaObrigatoria && (
                        <>
                          <p className="font-semibold pt-2">2. Fundamentação de Mérito:</p>
                          <p className="whitespace-pre-wrap">
                            {modalVisualizacao.decisao.fundamentacaoGeral}
                          </p>
                          <div className="space-y-2 pt-2">
                            {modalVisualizacao.decisao.itensDecididos.map((it) => (
                              <div
                                key={it.itemN}
                                className="p-3 bg-fundo/60 border border-linha rounded space-y-1"
                              >
                                <p className="font-bold">
                                  Item #{it.itemN} — {it.sigla} ({it.indicador}) · Decisão:{' '}
                                  <span className="text-carmim">{it.resultadoItem}</span>
                                </p>
                                <p className="text-xs text-suave tabular-nums">
                                  Pontuação Preliminar: <strong>{it.pontuacaoPreliminar} pts</strong>{' '}
                                  → Pontuação Final: <strong>{it.pontuacaoFinal} pts</strong> ·
                                  Impacto: <strong>{it.impactoPontuacao}</strong>
                                </p>
                                <p className="text-xs whitespace-pre-wrap">{it.fundamentacao}</p>
                                {it.providenciaDeterminada && (
                                  <p className="text-xs">
                                    <strong>Providência determinada:</strong>{' '}
                                    {it.providenciaDeterminada}
                                  </p>
                                )}
                              </div>
                            ))}
                          </div>
                        </>
                      )}
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold uppercase text-xs sm:text-sm">III – DISPOSITIVO</h5>
                    <p className="whitespace-pre-wrap">{modalVisualizacao.decisao.dispositivo}</p>
                    <p className="text-xs text-suave">
                      <strong>Encaminhamento institucional:</strong>{' '}
                      {modalVisualizacao.decisao.encaminhamentoCienciaProvidencias}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-linha space-y-1 text-xs">
                    <p className="font-bold text-tinta">{modalVisualizacao.decisao.relatorNome}</p>
                    <p className="text-suave">{modalVisualizacao.decisao.relatorCargo}</p>
                    <p className="text-suave">{modalVisualizacao.decisao.membrosComissao}</p>
                    <p className="font-mono text-suave pt-1">
                      Processo SEI: {analise.processoSei} · Código verificador:{' '}
                      <strong>
                        {modalVisualizacao.decisao.codigoVerificadorSei || 'RASCUNHO'}
                      </strong>{' '}
                      · Código CRC:{' '}
                      <strong>{modalVisualizacao.decisao.codigoCrcSei || 'PENDENTE'}</strong>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
       * BARRA DE SELEÇÃO DE RECURSO CADASTRADO E PERFIL DE ATUAÇÃO (SUMAE / COMISSÃO)
       * =================================================================== */}
      <section className="bg-white border border-linha rounded-lg p-4 sm:p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-3">
          <div className="flex flex-wrap sm:flex-nowrap items-end gap-3 flex-1 min-w-0">
            {onVoltarLista && (
              <button
                type="button"
                onClick={onVoltarLista}
                className="shrink-0 px-3 py-2 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
              >
                ← Voltar aos Recursos
              </button>
            )}
            <div className="flex-1 min-w-[240px] max-w-xl">
              <label
                htmlFor="seletor-protocolo-analise"
                className="block text-[10px] font-bold uppercase tracking-wider text-suave"
              >
                Recurso Cadastrado em Análise (Vínculo Permanente pelo Protocolo)
              </label>
              <select
                id="seletor-protocolo-analise"
                value={protocoloAtivo}
                onChange={(e) => trocarProtocolo(e.target.value)}
                className="mt-0.5 w-full px-3 py-1.5 rounded-md border border-linha bg-white text-xs sm:text-sm font-bold text-carmim focus:outline-none focus:border-carmim"
              >
                {listaProtocolos.map((p) => (
                  <option key={p.protocolo} value={p.protocolo}>
                    {p.protocolo} — {p.unidade} [{ROTULO_ESTADO_TRAMITACAO[p.estadoTramitacao]}]
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Seletor de Perfil Institucional Ativo (Restrição SUMAE vs Comissão Revisora) */}
          {(usuarioPodeSumae || usuarioPodeComissao) && (
            <div className="space-y-1 shrink-0">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-suave lg:text-right">
                Perfil de Edição Ativo (Validado no Servidor)
              </span>
              <div className="inline-flex bg-fundo border border-linha rounded-lg p-1 text-xs">
                <button
                  type="button"
                  disabled={!usuarioPodeSumae}
                  onClick={() => setPapelAtivo('SUMAE')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer disabled:opacity-40 ${
                    papelAtivo === 'SUMAE'
                      ? 'bg-carmim text-white'
                      : 'text-suave hover:text-tinta'
                  }`}
                >
                  Equipe Técnica SUMAE (Parecer)
                </button>
                <button
                  type="button"
                  disabled={!usuarioPodeComissao}
                  onClick={() => setPapelAtivo('COMISSAO')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer disabled:opacity-40 ${
                    papelAtivo === 'COMISSAO'
                      ? 'bg-carmim text-white'
                      : 'text-suave hover:text-tinta'
                  }`}
                >
                  Comissão Revisora (Decisão Final)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ===================================================================
         * 1. CABEÇALHO DE IDENTIFICAÇÃO E VÍNCULO PERMANENTE COM O PROTOCOLO E SEI
         * ================================================================= */}
        <div className="border-t border-linha pt-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="space-y-1 min-w-0">
              <p className="text-[11px] uppercase tracking-widest font-bold text-carmim">
                1. Identificação do Recurso e Vínculo Permanente de Protocolo e SEI
              </p>
              <h2 className="text-lg sm:text-xl font-bold text-tinta">
                Protocolo <span className="font-mono text-carmim">{recurso.protocolo}</span> —{' '}
                {recurso.unidade.codigo} · {recurso.unidade.nome}
              </h2>
              <p className="text-xs text-suave">
                Comarca: <strong className="text-tinta">{recurso.unidade.comarca}</strong> ·{' '}
                {recurso.unidade.grau === '1G' ? '1º Grau' : '2º Grau'} ({rotuloTipoUnidade}) ·
                Signatário: <strong className="text-tinta">{recurso.responsavel.nome}</strong> (
                {recurso.responsavel.cargo})
              </p>
            </div>

            <div className="flex flex-col sm:items-end gap-1.5 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-xs text-suave">Situação da Análise:</span>
                <span className="px-2.5 py-1 rounded-md bg-carmim text-white text-xs font-bold">
                  {ROTULO_ESTADO_TRAMITACAO[analise.estadoTramitacao]}
                </span>
              </div>
              <p className="text-xs text-suave tabular-nums">
                Enviado em:{' '}
                <strong className="text-tinta">
                  {formatarDataHora(recurso.enviadoEm || recurso.criadoEm)}
                </strong>
              </p>
            </div>
          </div>

          {/* Grade de Metadados Obrigatórios do Cabeçalho */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-fundo/70 border border-linha rounded-lg p-3.5 text-xs">
            <div>
              <span className="text-[11px] uppercase font-semibold text-suave block">
                Número do Protocolo
              </span>
              <strong className="font-mono text-sm text-carmim tabular-nums">
                {recurso.protocolo}
              </strong>
              <span className="block text-[11px] text-suave">
                Vínculo permanente Recurso ↔ Parecer ↔ Decisão
              </span>
            </div>

            <div>
              <span className="text-[11px] uppercase font-semibold text-suave block">
                Unidade Recorrente
              </span>
              <strong className="text-tinta block truncate" title={recurso.unidade.nome}>
                {recurso.unidade.codigo} — {recurso.unidade.nome}
              </strong>
              <span className="text-[11px] text-suave">
                {recurso.responsavel.nome} ({recurso.emailGoogle})
              </span>
            </div>

            <div>
              <span className="text-[11px] uppercase font-semibold text-suave block">
                Indicadores Contestados ({recurso.itens.length})
              </span>
              <strong className="text-tinta font-mono block">
                {recurso.itens.length > 0
                  ? recurso.itens.map((i) => i.sigla).join(', ')
                  : 'LISTA_SERVIDORES'}
              </strong>
              <span className="text-[11px] text-suave">
                {recurso.impugnaListaServidores
                  ? 'Inclui Lista de Servidores (Art. 5º, III, "b")'
                  : 'Resultado Preliminar (Art. 5º, III, "a")'}
              </span>
            </div>

            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] uppercase font-semibold text-suave">
                  Processo SEI Individual
                </span>
                {ehAdmin(usuario.email) && (
                  <button
                    type="button"
                    onClick={() => setEditandoSei((v) => !v)}
                    className="text-[11px] text-carmim font-semibold hover:underline cursor-pointer"
                  >
                    {editandoSei ? 'Cancelar' : 'Verificar / Alterar SEI'}
                  </button>
                )}
              </div>
              <strong className="font-mono text-sm text-tinta tabular-nums block">
                {analise.processoSei}
              </strong>
              <span className="text-[11px] text-verde font-medium">
                ✓ Vínculo SEI individual registrado e reutilizado
              </span>
            </div>
          </div>

          {/* Barra de vínculo / reutilização de processo SEI */}
          {editandoSei && (
            <div className="bg-fundo border border-linha rounded-md p-3.5 flex flex-wrap items-end gap-3">
              <div className="flex-1 min-w-[240px]">
                <label
                  htmlFor="input-processo-sei"
                  className="block text-xs font-semibold text-tinta mb-1"
                >
                  Número do Processo SEI vinculado ao protocolo {recurso.protocolo}
                </label>
                <input
                  id="input-processo-sei"
                  type="text"
                  value={inputProcessoSei}
                  onChange={(e) => setInputProcessoSei(e.target.value)}
                  placeholder="Ex.: 0013175-86.2026.8.01.0000"
                  className={CLASSE_INPUT}
                />
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleVincularSei(false)}
                  className="px-3.5 py-2 rounded-md bg-verde text-white text-xs font-semibold cursor-pointer"
                >
                  Vincular (Reutilizar se já existir)
                </button>
                <button
                  type="button"
                  onClick={() => handleVincularSei(true)}
                  className="px-3.5 py-2 rounded-md bg-carmim text-white text-xs font-semibold cursor-pointer"
                >
                  Substituir Número SEI
                </button>
              </div>
            </div>
          )}

          {msgVinculoSei && <Aviso tipo="sucesso">{msgVinculoSei}</Aviso>}

          {/* Stepper Visual dos 5 Estados de Tramitação */}
          <div className="pt-2">
            <p className="text-[11px] uppercase tracking-wider font-bold text-suave mb-2">
              Fluxo Institucional de Tramitação do Recurso
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
              {ORDEM_TRAMITACAO.map((est, idx) => {
                const concluido = idx < indiceEstadoAtual;
                const atual = idx === indiceEstadoAtual;
                return (
                  <div
                    key={est}
                    className={`px-2.5 py-2 rounded-md border text-[11px] leading-snug flex items-center justify-between gap-1.5 ${
                      atual
                        ? 'bg-carmim text-white border-carmim font-bold'
                        : concluido
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900 font-semibold'
                          : 'bg-fundo/50 border-linha text-suave'
                    }`}
                  >
                    <span>
                      {idx + 1}. {ROTULO_ESTADO_TRAMITACAO[est]}
                    </span>
                    <span className="shrink-0 text-[10px]">
                      {atual ? '● Atual' : concluido ? '✓' : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {erro && <Aviso tipo="erro">{erro}</Aviso>}
      {sucesso && <Aviso tipo="sucesso">{sucesso}</Aviso>}

      {/* =====================================================================
       * CONSULTA EM MODO DE LEITURA: PEDIDO, EVIDÊNCIAS E ANEXOS DO RECURSO ORIGINAL
       * =================================================================== */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-linha pb-3">
          <div>
            <p className="text-[11px] uppercase tracking-wider font-bold text-suave">
              Consulta em Modo de Leitura (Cadastro Original Preservado)
            </p>
            <h3 className="text-base font-bold text-tinta">
              Pedido, Evidências Obrigatórias e Anexos do Recurso Original ({recurso.protocolo})
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <SeloStatus status={recurso.status} />
          </div>
        </div>

        {verificacaoEvidenciasOriginal.faltaEvidencia && (
          <Aviso tipo="alerta">
            <strong>Alerta de Admissibilidade (Art. 13 e Anexo III, item 3):</strong> O recurso
            original apresenta ausência de requisito(s) de evidência obrigatória:{' '}
            {verificacaoEvidenciasOriginal.detalhesFaltas.join(' ')}
          </Aviso>
        )}

        {recurso.impugnaListaServidores && (
          <div className="bg-amber-50/60 border border-amber-200 rounded-md p-4 space-y-1.5 text-xs">
            <p className="font-bold text-amber-950">
              Impugnação da Lista de Servidores Vinculados (Art. 5º, III, &ldquo;b&rdquo; e Art. 6º):
            </p>
            <p className="text-tinta whitespace-pre-wrap">{recurso.impugnacaoListaTexto}</p>
          </div>
        )}

        <div className="space-y-4">
          {recurso.itens.map((it) => {
            const rotImp =
              TIPOS_IMPUGNACAO_INFO.find((t) => t.codigo === it.tipoImpugnacao)?.rotulo ||
              it.tipoImpugnacao;
            return (
              <div
                key={it.itemN}
                className="border border-linha rounded-md p-4 bg-fundo/30 space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <span className="font-mono text-xs font-bold text-carmim">
                      Item #{it.itemN} · {it.sigla}
                    </span>
                    <h4 className="text-sm font-bold text-tinta">{it.indicador}</h4>
                    <p className="text-xs text-suave">
                      Subitem: <strong className="text-tinta">{it.subitem}</strong> · Natureza:{' '}
                      <strong className="text-tinta">{rotImp}</strong>
                    </p>
                  </div>
                  <div className="text-xs tabular-nums bg-white border border-linha rounded px-3 py-1.5">
                    Preliminar: <strong>{it.pontuacaoPreliminar !== '' ? `${it.pontuacaoPreliminar} pts` : '—'}</strong>{' '}
                    → Pleiteada: <strong className="text-carmim">{it.pontuacaoPleiteada !== '' ? `${it.pontuacaoPleiteada} pts` : 'N/A'}</strong>
                  </div>
                </div>

                <div className="bg-white border border-linha rounded p-3 text-xs text-tinta whitespace-pre-wrap leading-relaxed">
                  <strong className="block text-suave uppercase text-[10px] mb-1">
                    Pedido e Fundamentação da Unidade Recorrente (Somente Leitura):
                  </strong>
                  {it.fundamentacao}
                </div>

                {/* Checklist de Evidências Obrigatórias do Item */}
                <div className="flex flex-wrap items-center gap-2 text-[11px]">
                  <span className="font-semibold text-suave">
                    Evidências Obrigatórias (Anexo III, item 3):
                  </span>
                  {[
                    { k: 'a', rot: '(a) Painel/Relatório' },
                    { k: 'b', rot: '(b) Filtros Aplicados' },
                    { k: 'c', rot: '(c) Período 01/01 a 30/11/2026' },
                    { k: 'd', rot: '(d) Memória de Cálculo' },
                    { k: 'e', rot: '(e) NPU e Qtd. Processos' },
                  ].map(({ k, rot }) => {
                    const ok = it.evidencias[k as keyof typeof it.evidencias];
                    return (
                      <span
                        key={k}
                        className={`px-2 py-0.5 rounded border font-medium ${
                          ok
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                            : 'bg-red-50 border-red-300 text-red-900 font-bold'
                        }`}
                      >
                        {ok ? '✓ ' : '✗ FALTA: '}
                        {rot}
                      </span>
                    );
                  })}
                </div>

                {/* Anexos do Item */}
                <div className="space-y-1.5">
                  <span className="text-xs font-semibold text-tinta block">
                    Anexos e Evidências Documentais ({it.arquivos.length}):
                  </span>
                  {it.arquivos.length === 0 ? (
                    <p className="text-xs text-carmim font-semibold">
                      Nenhum anexo enviado para este item.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {it.arquivos.map((arq, idx) => (
                        <div
                          key={`${arq.fileId}-${idx}`}
                          className="flex items-center justify-between gap-2 p-2.5 rounded border border-linha bg-white text-xs"
                        >
                          <div className="min-w-0">
                            <p className="font-semibold text-tinta truncate">{arq.nome}</p>
                            <p className="text-[11px] text-suave tabular-nums">
                              {formatarBytes(arq.bytes)} · SHA-256: {arq.sha256.slice(0, 14)}…
                            </p>
                          </div>
                          <a
                            href={arq.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="shrink-0 px-2.5 py-1 rounded border border-linha hover:bg-carmim hover:text-white text-carmim font-semibold transition-colors"
                          >
                            Consultar Anexo ↗
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* =====================================================================
       * 2. PARECER TÉCNICO DA SUMAE (EDIÇÃO RESTRITA À SUMAE)
       * =================================================================== */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-linha pb-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider font-bold text-carmim">
                2. Parecer Técnico da SUMAE (Subsecretaria de Monitoramento e Análise Estratégica)
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  analise.parecerSumae.statusDocumento === 'EMITIDO'
                    ? 'bg-emerald-100 text-emerald-900'
                    : 'bg-amber-100 text-amber-900'
                }`}
              >
                {analise.parecerSumae.statusDocumento === 'EMITIDO'
                  ? `Emitido (Versão v${analise.parecerSumae.versao})`
                  : 'Rascunho em elaboração'}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-tinta">
              Instrução e Análise Técnica Fundamentada — Parecer SUMAE n.º {formParecer.numeroParecer}
            </h3>
            {analise.parecerSumae.emitidoEm && (
              <p className="text-xs text-suave">
                Última emissão em{' '}
                <strong className="text-tinta">
                  {formatarDataHora(analise.parecerSumae.emitidoEm)}
                </strong>{' '}
                por <strong className="text-tinta">{analise.parecerSumae.responsavelNome}</strong> ·
                Verificador SEI:{' '}
                <code className="font-mono text-tinta">
                  {analise.parecerSumae.codigoVerificadorSei}
                </code>{' '}
                (CRC <code className="font-mono text-tinta">{analise.parecerSumae.codigoCrcSei}</code>)
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() =>
                setModalVisualizacao({
                  tipo: 'PARECER_SUMAE',
                  parecer: {
                    ...analise.parecerSumae,
                    ...formParecer,
                  },
                })
              }
              className="px-3 py-1.5 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
            >
              Visualizar parecer
            </button>
            <button
              type="button"
              onClick={() => baixarPdfParecer()}
              className="px-3 py-1.5 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold cursor-pointer"
            >
              PDF do Parecer (SEI)
            </button>
          </div>
        </div>

        {!podeEditarParecer && (
          <div className="bg-fundo border border-linha rounded-md p-3 text-xs text-suave flex items-center justify-between gap-2">
            <span>
              <strong>Modo Somente Leitura para o Parecer Técnico:</strong> a edição do Parecer
              Técnico é restrita ao perfil <strong>SUMAE</strong>.
              {usuarioPodeSumae &&
                ' Para editar o parecer, alterne o seletor de perfil no topo para "Equipe Técnica SUMAE (Parecer)".'}
            </span>
          </div>
        )}

        <details key={recurso.protocolo} className="group border-t border-linha pt-3">
          <summary className="min-h-11 cursor-pointer rounded py-3 text-sm font-semibold text-carmim focus-visible:outline-2 focus-visible:outline-carmim">
            <span className="group-open:hidden">Ver detalhes do parecer</span>
            <span className="hidden group-open:inline">Ocultar detalhes</span>
          </summary>
          <div className="space-y-5 pt-3">
            <fieldset disabled={!podeEditarParecer} className="space-y-4 disabled:opacity-80">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Número do Parecer Técnico SUMAE
                  </label>
                  <input
                    type="text"
                    value={formParecer.numeroParecer}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, numeroParecer: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                    placeholder="Ex.: 001/2026"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Conferência do Prazo Recursal (Art. 5º, III)
                  </label>
                  <select
                    value={formParecer.tempestivo ? 'SIM' : 'NAO'}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, tempestivo: e.target.value === 'SIM' }))
                    }
                    className={CLASSE_INPUT}
                  >
                    <option value="SIM">Tempestivo (enviado dentro do prazo regulamentar)</option>
                    <option value="NAO">Intempestivo (fora do prazo regulamentar)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Evidências Obrigatórias (Art. 13 e Anexo III, item 3)
                  </label>
                  <select
                    value={formParecer.possuiFaltaEvidenciaObrigatoria ? 'FALTA' : 'COMPLETO'}
                    onChange={(e) => {
                      const falta = e.target.value === 'FALTA';
                      setFormParecer((p) => ({ ...p, possuiFaltaEvidenciaObrigatoria: falta }));
                    }}
                    className={CLASSE_INPUT}
                  >
                    <option value="COMPLETO">Todas as evidências obrigatórias apresentadas</option>
                    <option value="FALTA">Constata-se falta de evidência obrigatória</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-tinta mb-1">
                  Síntese do pedido e identificação dos itens ou indicadores contestados (I. Objeto do Recurso)
                </label>
                <textarea
                  rows={3}
                  value={formParecer.sintesePedido}
                  onChange={(e) =>
                    setFormParecer((p) => ({ ...p, sintesePedido: e.target.value }))
                  }
                  className={CLASSE_INPUT}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Conferência do prazo e das evidências obrigatórias (2.1)
                  </label>
                  <textarea
                    rows={3}
                    value={formParecer.conferenciaPrazoEvidencias}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, conferenciaPrazoEvidencias: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Registro de eventuais faltas nas evidências obrigatórias
                  </label>
                  <textarea
                    rows={3}
                    value={formParecer.registroFaltasEvidencias}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, registroFaltasEvidencias: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                    placeholder="Descreva eventuais ausências de relação de processos, filtros ou relatórios..."
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Dados e fontes consultadas (BI TJAC, DataJud, SEEU)
                  </label>
                  <textarea
                    rows={2}
                    value={formParecer.dadosFontesConsultadas}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, dadosFontesConsultadas: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Filtros aplicados na auditoria
                  </label>
                  <textarea
                    rows={2}
                    value={formParecer.filtrosAplicados}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, filtrosAplicados: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Período de referência auditado
                  </label>
                  <textarea
                    rows={2}
                    value={formParecer.periodoReferencia}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, periodoReferencia: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-tinta mb-1">
                  Metodologia, memória de cálculo e fundamentação técnica da SUMAE
                </label>
                <textarea
                  rows={3}
                  value={formParecer.metodologiaMemoriaCalculo}
                  onChange={(e) =>
                    setFormParecer((p) => ({ ...p, metodologiaMemoriaCalculo: e.target.value }))
                  }
                  className={CLASSE_INPUT}
                />
              </div>

              {/* Conclusão técnica por item contestado */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-carmim">
                  Conclusão Técnica da SUMAE por Item Impugnado (com Recomendação e Impacto na Pontuação)
                </h4>
                {formParecer.conclusoesPorItem.map((c) => (
                  <div
                    key={c.itemN}
                    className="border border-linha rounded-md p-4 bg-fundo/40 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-mono text-xs font-bold text-tinta">
                        Item #{c.itemN} · {c.sigla} — {c.indicador}
                      </span>
                      <span className="text-xs text-suave">Subitem: {c.subitem}</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-tinta mb-1">
                          Recomendação Técnica da SUMAE
                        </label>
                        <select
                          value={c.recomendacao}
                          onChange={(e) =>
                            atualizarConclusaoItemSumae(c.itemN, {
                              recomendacao: e.target.value as RecomendacaoTecnicaItem,
                            })
                          }
                          className={CLASSE_INPUT}
                        >
                          {Object.entries(ROTULO_RECOMENDACAO_SUMAE).map(([k, rot]) => (
                            <option key={k} value={k}>
                              {rot}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-tinta mb-1">
                          Pontuação Recomendada (Preliminar: {c.pontuacaoPreliminar !== '' ? c.pontuacaoPreliminar : '—'})
                        </label>
                        <input
                          type="number"
                          step="any"
                          value={c.pontuacaoRecomendada}
                          onChange={(e) =>
                            atualizarConclusaoItemSumae(c.itemN, {
                              pontuacaoRecomendada:
                                e.target.value === '' ? '' : Number(e.target.value),
                            })
                          }
                          className={CLASSE_INPUT}
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-tinta mb-1">
                          Impacto na Pontuação
                        </label>
                        <input
                          type="text"
                          value={c.impactoPontuacao}
                          onChange={(e) =>
                            atualizarConclusaoItemSumae(c.itemN, {
                              impactoPontuacao: e.target.value,
                            })
                          }
                          className={CLASSE_INPUT}
                          placeholder="Ex.: +40 pontos (0 → 40 pts)"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-tinta mb-1">
                        Conclusão técnica detalhada do Item #{c.itemN} ({c.sigla})
                      </label>
                      <textarea
                        rows={2}
                        value={c.conclusaoTecnica}
                        onChange={(e) =>
                          atualizarConclusaoItemSumae(c.itemN, {
                            conclusaoTecnica: e.target.value,
                          })
                        }
                        className={CLASSE_INPUT}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-xs font-semibold text-tinta mb-1">
                  Síntese da Conclusão Técnica Geral da SUMAE (III. Conclusão do Parecer Técnico)
                </label>
                <textarea
                  rows={2}
                  value={formParecer.conclusaoGeral}
                  onChange={(e) =>
                    setFormParecer((p) => ({ ...p, conclusaoGeral: e.target.value }))
                  }
                  className={CLASSE_INPUT}
                />
              </div>

              {/* Identificação do responsável e encaminhamento à Comissão Revisora */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-linha">
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Responsável Técnico / Equipe SUMAE
                  </label>
                  <input
                    type="text"
                    value={formParecer.responsavelNome}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, responsavelNome: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Cargo / Função na SUMAE
                  </label>
                  <input
                    type="text"
                    value={formParecer.responsavelCargo}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, responsavelCargo: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Unidade / Lotação Institucional
                  </label>
                  <input
                    type="text"
                    value={formParecer.lotacao}
                    onChange={(e) => setFormParecer((p) => ({ ...p, lotacao: e.target.value }))}
                    className={CLASSE_INPUT}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-tinta mb-1">
                  Registro do Encaminhamento à Comissão Revisora (IV. Encaminhamento)
                </label>
                <textarea
                  rows={2}
                  value={formParecer.encaminhamentoComissao}
                  onChange={(e) =>
                    setFormParecer((p) => ({ ...p, encaminhamentoComissao: e.target.value }))
                  }
                  className={CLASSE_INPUT}
                />
              </div>

              {analise.parecerSumae.versao >= 1 && (
                <div className="p-3.5 rounded-md bg-amber-50 border border-amber-300 space-y-1.5">
                  <label className="block text-xs font-bold text-amber-950">
                    Justificativa Obrigatória para Retificação (Nova Versão v
                    {analise.parecerSumae.versao + 1} do Parecer Técnico)
                  </label>
                  <textarea
                    rows={2}
                    value={formParecer.justificativaRetificacao}
                    onChange={(e) =>
                      setFormParecer((p) => ({ ...p, justificativaRetificacao: e.target.value }))
                    }
                    placeholder="Informe o motivo técnico da retificação para registro no histórico de versões do protocolo..."
                    className={CLASSE_INPUT}
                  />
                </div>
              )}
            </fieldset>

            {/* Barra de ações do Parecer Técnico da SUMAE */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-linha">
              <div className="text-xs text-suave">
                {analise.parecerSumae.statusDocumento === 'EMITIDO'
                  ? `Documento gravado no protocolo (v${analise.parecerSumae.versao}) — PDF disponível para juntada ao SEI ${analise.processoSei}.`
                  : 'Salve o rascunho ou emita o parecer para encaminhar formalmente à Comissão Revisora.'}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={!podeEditarParecer || processandoParecer}
                  onClick={() => executarAcaoParecerSumae('SALVAR_RASCUNHO')}
                  className="px-3.5 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-tinta cursor-pointer disabled:opacity-50"
                >
                  Salvar rascunho
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setModalVisualizacao({
                      tipo: 'PARECER_SUMAE',
                      parecer: {
                        ...analise.parecerSumae,
                        ...formParecer,
                      },
                    })
                  }
                  className="px-3.5 py-2 rounded-md border border-carmim text-carmim hover:bg-carmim/5 text-xs font-semibold cursor-pointer"
                >
                  Visualizar parecer
                </button>
                <button
                  type="button"
                  disabled={!podeEditarParecer || processandoParecer}
                  onClick={() => executarAcaoParecerSumae('EMITIR_ENCAMINHAR')}
                  className="px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  {processandoParecer
                    ? 'Emitindo…'
                    : analise.parecerSumae.versao >= 1
                      ? `Emitir retificação (v${analise.parecerSumae.versao + 1}) e encaminhar à Comissão`
                      : 'Emitir e encaminhar à Comissão'}
                </button>
              </div>
            </div>
          </div>
        </details>
      </section>

      {/* =====================================================================
       * 3. DECISÃO FINAL DA COMISSÃO REVISORA (EDIÇÃO RESTRITA À COMISSÃO)
       * =================================================================== */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-linha pb-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider font-bold text-carmim">
                3. Decisão Final da Comissão Revisora ({PORTARIA})
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  analise.decisaoComissao.statusDocumento === 'EMITIDO'
                    ? 'bg-emerald-100 text-emerald-900'
                    : 'bg-amber-100 text-amber-900'
                }`}
              >
                {analise.decisaoComissao.statusDocumento === 'EMITIDO'
                  ? `Decisão Emitida (Versão v${analise.decisaoComissao.versao})`
                  : 'Em elaboração pela Comissão'}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-tinta">
              Julgamento de Admissibilidade, Mérito e Dispositivo — {formDecisao.numeroDecisao}
            </h3>
            {analise.decisaoComissao.emitidoEm && (
              <p className="text-xs text-suave">
                Decisão emitida em{' '}
                <strong className="text-tinta">
                  {formatarDataHora(analise.decisaoComissao.emitidoEm)}
                </strong>{' '}
                por <strong className="text-tinta">{analise.decisaoComissao.relatorNome}</strong> ·
                Verificador SEI:{' '}
                <code className="font-mono text-tinta">
                  {analise.decisaoComissao.codigoVerificadorSei}
                </code>{' '}
                (CRC{' '}
                <code className="font-mono text-tinta">
                  {analise.decisaoComissao.codigoCrcSei}
                </code>
                )
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() =>
                setModalVisualizacao({
                  tipo: 'DECISAO_COMISSAO',
                  decisao: {
                    ...analise.decisaoComissao,
                    ...formDecisao,
                  },
                })
              }
              className="px-3 py-1.5 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
            >
              Visualizar decisão
            </button>
            <button
              type="button"
              onClick={() => baixarPdfDecisao()}
              className="px-3 py-1.5 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold cursor-pointer"
            >
              PDF da Decisão (SEI)
            </button>
          </div>
        </div>

        {/* Subsídio Visível: Resumo do Parecer Técnico Emitido pela SUMAE */}
        <div className="bg-fundo/70 border border-linha rounded-md p-4 space-y-2 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <strong className="text-tinta uppercase tracking-wider text-[11px]">
              Subsídio Técnico da SUMAE Vinculado ao Protocolo (Parecer n.º{' '}
              {analise.parecerSumae.numeroParecer} ·{' '}
              {analise.parecerSumae.statusDocumento === 'EMITIDO'
                ? `Emitido v${analise.parecerSumae.versao}`
                : 'Rascunho'}
              )
            </strong>
            <span className="text-suave">
              Responsável: <strong>{analise.parecerSumae.responsavelNome}</strong>
            </span>
          </div>
          <p className="text-tinta whitespace-pre-wrap">{analise.parecerSumae.conclusaoGeral}</p>
        </div>

        {!podeEditarDecisao && (
          <div className="bg-fundo border border-linha rounded-md p-3 text-xs text-suave">
            <strong>Modo Somente Leitura para a Decisão Final:</strong> a edição da Decisão Final é
            restrita ao perfil <strong>Comissão Revisora</strong>.
            {usuarioPodeComissao &&
              ' Para deliberar e emitir a decisão final, selecione o perfil "Comissão Revisora (Decisão Final)" no seletor do topo.'}
          </div>
        )}

        <details key={recurso.protocolo} className="group border-t border-linha pt-3">
          <summary className="min-h-11 cursor-pointer rounded py-3 text-sm font-semibold text-carmim focus-visible:outline-2 focus-visible:outline-carmim">
            <span className="group-open:hidden">Ver detalhes do julgamento</span>
            <span className="hidden group-open:inline">Ocultar detalhes</span>
          </summary>
          <div className="space-y-5 pt-3">
            <fieldset disabled={!podeEditarDecisao} className="space-y-5 disabled:opacity-80">
              {/* I - RELATÓRIO */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-tinta mb-1">
                  I – Relatório
                </label>
                <textarea
                  rows={3}
                  value={formDecisao.relatorio}
                  onChange={(e) => setFormDecisao((d) => ({ ...d, relatorio: e.target.value }))}
                  className={CLASSE_INPUT}
                />
              </div>

              {/* EXAME DE ADMISSIBILIDADE E REGRA DE NÃO CONHECIMENTO POR FALTA DE EVIDÊNCIA OBRIGATÓRIA */}
              <div className="border border-linha rounded-lg p-4 bg-fundo/40 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-carmim">
                    Exame de Admissibilidade (Art. 13 e Anexo III, item 3)
                  </h4>
                  {bloqueioMeritoPorFaltaEvidencia && (
                    <span className="px-2.5 py-0.5 rounded bg-red-100 border border-red-300 text-red-900 text-xs font-bold">
                      Resultado Travado em “Não conhecido” (Campos de Mérito Desabilitados)
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-tinta mb-1">
                      Verificação de Evidências Obrigatórias (Art. 13)
                    </label>
                    <select
                      value={
                        verificacaoEvidenciasOriginal.faltaEvidencia ||
                        formParecer.possuiFaltaEvidenciaObrigatoria ||
                        formDecisao.faltaEvidenciaObrigatoria
                          ? 'FALTA'
                          : 'COMPLETA'
                      }
                      disabled={
                        verificacaoEvidenciasOriginal.faltaEvidencia ||
                        formParecer.possuiFaltaEvidenciaObrigatoria
                      }
                      onChange={(e) => {
                        const falta = e.target.value === 'FALTA';
                        setFormDecisao((prev) => ({
                          ...prev,
                          faltaEvidenciaObrigatoria: falta,
                          conhecido: !falta,
                          resultadoGeral: falta ? 'NAO_CONHECIDO' : 'PROVIDO',
                        }));
                      }}
                      className={CLASSE_INPUT}
                    >
                      <option value="COMPLETA">
                        Evidências obrigatórias completas (habilita exame de mérito)
                      </option>
                      <option value="FALTA">
                        Falta evidência obrigatória → Registrar “Não conhecido” e bloquear mérito
                      </option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-tinta mb-1">
                      Juízo de Admissibilidade da Comissão Revisora
                    </label>
                    <select
                      value={
                        bloqueioMeritoPorFaltaEvidencia || !formDecisao.conhecido
                          ? 'NAO_CONHECIDO'
                          : 'CONHECIDO'
                      }
                      disabled={
                        verificacaoEvidenciasOriginal.faltaEvidencia ||
                        formParecer.possuiFaltaEvidenciaObrigatoria
                      }
                      onChange={(e) => {
                        const conhecido = e.target.value === 'CONHECIDO';
                        setFormDecisao((prev) => ({
                          ...prev,
                          conhecido,
                          faltaEvidenciaObrigatoria: !conhecido,
                          resultadoGeral: conhecido ? 'PROVIDO' : 'NAO_CONHECIDO',
                        }));
                      }}
                      className={CLASSE_INPUT}
                    >
                      <option value="CONHECIDO">Recurso Conhecido (admitido para julgamento de mérito)</option>
                      <option value="NAO_CONHECIDO">
                        Não conhecido (ausência de requisito formal / evidência obrigatória)
                      </option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Fundamentação da Admissibilidade / Não Conhecimento (Obrigatória)
                  </label>
                  <textarea
                    rows={3}
                    value={formDecisao.fundamentacaoAdmissibilidade}
                    onChange={(e) =>
                      setFormDecisao((d) => ({
                        ...d,
                        fundamentacaoAdmissibilidade: e.target.value,
                      }))
                    }
                    className={CLASSE_INPUT}
                    placeholder="Fundamente o conhecimento ou as razões do não conhecimento do recurso..."
                  />
                </div>
              </div>

              {/* II - FUNDAMENTAÇÃO E JULGAMENTO DE MÉRITO POR ITEM (DESABILITADOS QUANDO NÃO CONHECIDO) */}
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-tinta">
                    II – Fundamentação de Mérito e Deliberação por Item Examinado
                  </h4>
                  {bloqueioMeritoPorFaltaEvidencia && (
                    <span className="text-xs text-carmim font-semibold">
                      Campos de mérito desabilitados por ausência de evidência obrigatória (Art. 13).
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Fundamentação Geral de Mérito
                  </label>
                  <textarea
                    rows={3}
                    disabled={bloqueioMeritoPorFaltaEvidencia}
                    value={formDecisao.fundamentacaoGeral}
                    onChange={(e) =>
                      setFormDecisao((d) => ({ ...d, fundamentacaoGeral: e.target.value }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>

                {/* Decisão individual de cada item com Conclusão Técnica da SUMAE sempre visível como subsídio */}
                {formDecisao.itensDecididos.map((itDec) => {
                  const subsidioSumae = formParecer.conclusoesPorItem.find(
                    (c) => c.itemN === itDec.itemN
                  );
                  return (
                    <div
                      key={itDec.itemN}
                      className="border border-linha rounded-lg p-4 space-y-3 bg-white"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-linha pb-2.5">
                        <span className="font-mono text-xs font-bold text-carmim">
                          Item #{itDec.itemN} · {itDec.sigla} — {itDec.indicador}
                        </span>
                        <span className="text-xs text-suave">Subitem: {itDec.subitem}</span>
                      </div>

                      {/* Conclusão Técnica da SUMAE permanentemente visível como subsídio */}
                      {subsidioSumae && (
                        <div className="p-3 rounded bg-emerald-50/70 border border-emerald-200 text-xs space-y-1">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <strong className="text-emerald-950">
                              Subsídio Técnico da SUMAE — Item #{itDec.itemN} ({itDec.sigla}):
                            </strong>
                            <span className="font-bold text-emerald-900">
                              Recomendação: {ROTULO_RECOMENDACAO_SUMAE[subsidioSumae.recomendacao]} (
                              {subsidioSumae.pontuacaoPreliminar} → {subsidioSumae.pontuacaoRecomendada}{' '}
                              pts)
                            </span>
                          </div>
                          <p className="text-emerald-950 whitespace-pre-wrap">
                            {subsidioSumae.conclusaoTecnica}
                          </p>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-tinta mb-1">
                            Decisão da Comissão para o Item #{itDec.itemN}
                          </label>
                          <select
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            value={
                              bloqueioMeritoPorFaltaEvidencia
                                ? 'NAO_CONHECIDO'
                                : itDec.resultadoItem
                            }
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                resultadoItem: e.target.value as ResultadoMeritoItem,
                              })
                            }
                            className={CLASSE_INPUT}
                          >
                            {bloqueioMeritoPorFaltaEvidencia ? (
                              <option value="NAO_CONHECIDO">Não conhecido</option>
                            ) : (
                              <>
                                <option value="PROVIDO">Provido</option>
                                <option value="PARCIALMENTE_PROVIDO">Parcialmente provido</option>
                                <option value="DESPROVIDO">Desprovido</option>
                              </>
                            )}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-tinta mb-1">
                            Pontuação Final Decidida (Preliminar: {itDec.pontuacaoPreliminar !== '' ? itDec.pontuacaoPreliminar : '—'})
                          </label>
                          <input
                            type="number"
                            step="any"
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            value={
                              bloqueioMeritoPorFaltaEvidencia
                                ? itDec.pontuacaoPreliminar
                                : itDec.pontuacaoFinal
                            }
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                pontuacaoFinal:
                                  e.target.value === '' ? '' : Number(e.target.value),
                              })
                            }
                            className={CLASSE_INPUT}
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-tinta mb-1">
                            Impacto na Pontuação
                          </label>
                          <input
                            type="text"
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            value={
                              bloqueioMeritoPorFaltaEvidencia
                                ? 'Sem alteração (Não conhecido)'
                                : itDec.impactoPontuacao
                            }
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                impactoPontuacao: e.target.value,
                              })
                            }
                            className={CLASSE_INPUT}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-tinta mb-1">
                            Fundamentação da Decisão do Item #{itDec.itemN}
                          </label>
                          <textarea
                            rows={2}
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            value={itDec.fundamentacao}
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                fundamentacao: e.target.value,
                              })
                            }
                            className={CLASSE_INPUT}
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-tinta mb-1">
                            Providência Determinada (quando aplicável)
                          </label>
                          <textarea
                            rows={2}
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            value={itDec.providenciaDeterminada}
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                providenciaDeterminada: e.target.value,
                              })
                            }
                            className={CLASSE_INPUT}
                          />
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 pt-1">
                        <label className="inline-flex items-center gap-2 text-xs font-semibold text-tinta cursor-pointer">
                          <input
                            type="checkbox"
                            disabled={bloqueioMeritoPorFaltaEvidencia}
                            checked={
                              bloqueioMeritoPorFaltaEvidencia
                                ? false
                                : itDec.necessitaReavaliacaoReprocessamento
                            }
                            onChange={(e) =>
                              atualizarDecisaoItemComissao(itDec.itemN, {
                                necessitaReavaliacaoReprocessamento: e.target.checked,
                              })
                            }
                          />
                          Necessita de reavaliação ou reprocessamento pela SUMAE/SEGOV
                        </label>
                        {itDec.necessitaReavaliacaoReprocessamento &&
                          !bloqueioMeritoPorFaltaEvidencia && (
                            <input
                              type="text"
                              value={itDec.detalheReprocessamento}
                              onChange={(e) =>
                                atualizarDecisaoItemComissao(itDec.itemN, {
                                  detalheReprocessamento: e.target.value,
                                })
                              }
                              placeholder="Especifique a diretriz de reprocessamento..."
                              className="flex-1 min-w-[240px] px-3 py-1 rounded border border-linha text-xs"
                            />
                          )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* III - RESULTADO GERAL, DISPOSITIVO E ENCAMINHAMENTO */}
              <div className="border-t border-linha pt-4 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-carmim mb-1">
                      Resultado Geral da Decisão Final
                    </label>
                    <select
                      disabled={bloqueioMeritoPorFaltaEvidencia}
                      value={
                        bloqueioMeritoPorFaltaEvidencia
                          ? 'NAO_CONHECIDO'
                          : formDecisao.resultadoGeral
                      }
                      onChange={(e) =>
                        setFormDecisao((d) => ({
                          ...d,
                          resultadoGeral: e.target.value as ResultadoGeralDecisao,
                        }))
                      }
                      className={CLASSE_INPUT}
                    >
                      {bloqueioMeritoPorFaltaEvidencia ? (
                        <option value="NAO_CONHECIDO">
                          Não conhecido (falta de evidência obrigatória / requisito formal)
                        </option>
                      ) : (
                        <>
                          <option value="PROVIDO">Provido</option>
                          <option value="PARCIALMENTE_PROVIDO">Parcialmente provido</option>
                          <option value="DESPROVIDO">Desprovido</option>
                        </>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-tinta mb-1">
                      Identificação do Documento de Decisão
                    </label>
                    <input
                      type="text"
                      value={formDecisao.numeroDecisao}
                      onChange={(e) =>
                        setFormDecisao((d) => ({ ...d, numeroDecisao: e.target.value }))
                      }
                      className={CLASSE_INPUT}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-tinta mb-1">
                    III – Dispositivo da Decisão
                  </label>
                  <textarea
                    rows={3}
                    value={formDecisao.dispositivo}
                    onChange={(e) => setFormDecisao((d) => ({ ...d, dispositivo: e.target.value }))}
                    className={CLASSE_INPUT}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-tinta mb-1">
                    Registro de Encaminhamento para Ciência ou Providências (Fluxo Institucional)
                  </label>
                  <textarea
                    rows={2}
                    value={formDecisao.encaminhamentoCienciaProvidencias}
                    onChange={(e) =>
                      setFormDecisao((d) => ({
                        ...d,
                        encaminhamentoCienciaProvidencias: e.target.value,
                      }))
                    }
                    className={CLASSE_INPUT}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-tinta mb-1">
                      Magistrado(a) Relator(a) / Presidente da Comissão Revisora
                    </label>
                    <input
                      type="text"
                      value={formDecisao.relatorNome}
                      onChange={(e) =>
                        setFormDecisao((d) => ({ ...d, relatorNome: e.target.value }))
                      }
                      className={CLASSE_INPUT}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-tinta mb-1">
                      Cargo / Designação na Comissão Revisora
                    </label>
                    <input
                      type="text"
                      value={formDecisao.relatorCargo}
                      onChange={(e) =>
                        setFormDecisao((d) => ({ ...d, relatorCargo: e.target.value }))
                      }
                      className={CLASSE_INPUT}
                    />
                  </div>
                </div>

                {analise.decisaoComissao.versao >= 1 && (
                  <div className="p-3.5 rounded-md bg-amber-50 border border-amber-300 space-y-1.5">
                    <label className="block text-xs font-bold text-amber-950">
                      Justificativa Obrigatória para Retificação da Decisão Final (Nova Versão v
                      {analise.decisaoComissao.versao + 1})
                    </label>
                    <textarea
                      rows={2}
                      value={formDecisao.justificativaRetificacao}
                      onChange={(e) =>
                        setFormDecisao((d) => ({
                          ...d,
                          justificativaRetificacao: e.target.value,
                        }))
                      }
                      placeholder="Informe o motivo jurídico/técnico da retificação da decisão..."
                      className={CLASSE_INPUT}
                    />
                  </div>
                )}
              </div>
            </fieldset>

            {/* Barra de ações da Decisão Final da Comissão Revisora */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-linha">
              <div className="text-xs text-suave">
                {analise.decisaoComissao.statusDocumento === 'EMITIDO'
                  ? `Decisão final gravada no protocolo (v${analise.decisaoComissao.versao}) — PDF disponível para juntada ao SEI ${analise.processoSei}.`
                  : 'Salve o rascunho ou emita a decisão final para concluir o julgamento do protocolo.'}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={!podeEditarDecisao || processandoDecisao}
                  onClick={() => executarAcaoDecisaoComissao('SALVAR_RASCUNHO')}
                  className="px-3.5 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-tinta cursor-pointer disabled:opacity-50"
                >
                  Salvar rascunho
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setModalVisualizacao({
                      tipo: 'DECISAO_COMISSAO',
                      decisao: {
                        ...analise.decisaoComissao,
                        ...formDecisao,
                      },
                    })
                  }
                  className="px-3.5 py-2 rounded-md border border-carmim text-carmim hover:bg-carmim/5 text-xs font-semibold cursor-pointer"
                >
                  Visualizar decisão
                </button>
                <button
                  type="button"
                  disabled={!podeEditarDecisao || processandoDecisao}
                  onClick={() => executarAcaoDecisaoComissao('EMITIR_DECISAO')}
                  className="px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  {processandoDecisao
                    ? 'Emitindo…'
                    : analise.decisaoComissao.versao >= 1
                      ? `Emitir retificação da decisão (v${analise.decisaoComissao.versao + 1})`
                      : 'Emitir decisão final'}
                </button>
              </div>
            </div>
          </div>
        </details>
      </section>

      {/* =====================================================================
       * 4. HISTÓRICO DE VERSÕES EMITIDAS, TRAMITAÇÃO E ETAPA DE DIVULGAÇÃO (ART. 14)
       * =================================================================== */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-linha pb-3">
          <div>
            <p className="text-[11px] uppercase tracking-wider font-bold text-carmim">
              4. Histórico Documental, Rastreabilidade e Etapa de Divulgação Oficial
            </p>
            <h3 className="text-base font-bold text-tinta">
              Versões Emitidas no Protocolo {recurso.protocolo} (SEI {analise.processoSei})
            </h3>
          </div>

          {/* Controle da etapa própria de divulgação conforme cronograma do prêmio */}
          <div className="flex flex-wrap items-center gap-2 bg-fundo border border-linha rounded-md px-3 py-2 text-xs">
            <span>
              <strong>Divulgação Oficial (Art. 14):</strong>{' '}
              {analise.divulgacao.divulgado
                ? `Publicada (${formatarDataHora(analise.divulgacao.divulgadoEm)})`
                : 'Aguardando etapa própria do cronograma (18/12/2026)'}
            </span>
            {ehAdmin(usuario.email) && (
              <button
                type="button"
                onClick={() => alternarDivulgacaoCronograma(!analise.divulgacao.divulgado)}
                className="px-2.5 py-1 rounded bg-white border border-linha hover:bg-carmim hover:text-white text-tinta font-semibold transition-colors cursor-pointer"
              >
                {analise.divulgacao.divulgado
                  ? 'Retornar para restrito interno'
                  : 'Liberar divulgação oficial'}
              </button>
            )}
          </div>
        </div>

        {/* Tabela de Documentos Emitidos (Pareceres SUMAE e Decisões da Comissão) */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-suave">
            Documentos Emitidos e Versões Preservadas ({analise.historicoDocumentos.length})
          </h4>
          {analise.historicoDocumentos.length === 0 ? (
            <p className="text-xs text-suave bg-fundo/50 border border-linha rounded p-3">
              Nenhum documento oficial emitido ainda para este protocolo. Utilize os botões
              &ldquo;Emitir e encaminhar à Comissão&rdquo; (SUMAE) ou &ldquo;Emitir decisão
              final&rdquo; (Comissão Revisora).
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-linha text-suave uppercase text-[11px]">
                    <th className="py-2 pr-3">Documento / Versão</th>
                    <th className="py-2 pr-3">Autoria e Perfil</th>
                    <th className="py-2 pr-3">Data / Hora de Emissão</th>
                    <th className="py-2 pr-3">Verificador SEI / CRC</th>
                    <th className="py-2 pr-3">Resumo / Justificativa de Retificação</th>
                    <th className="py-2 text-right">PDF para Juntada ao SEI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-linha">
                  {analise.historicoDocumentos.map((doc) => (
                    <tr key={doc.id} className="hover:bg-fundo/40">
                      <td className="py-2.5 pr-3 font-semibold text-tinta whitespace-nowrap">
                        {doc.tipo === 'PARECER_SUMAE'
                          ? `Parecer SUMAE ${doc.numeroDocumento}`
                          : `Decisão ${doc.numeroDocumento}`}
                        <span className="ml-1.5 px-1.5 py-0.5 rounded bg-carmim text-white font-mono text-[10px]">
                          v{doc.versao}
                        </span>
                      </td>
                      <td className="py-2.5 pr-3">
                        <strong className="text-tinta block">{doc.autoriaNome}</strong>
                        <span className="text-[11px] text-suave">{doc.autoriaCargo}</span>
                      </td>
                      <td className="py-2.5 pr-3 tabular-nums whitespace-nowrap">
                        {formatarDataHora(doc.emitidoEm)}
                      </td>
                      <td className="py-2.5 pr-3 font-mono text-[11px] whitespace-nowrap">
                        Verif.: <strong>{doc.codigoVerificadorSei}</strong> · CRC:{' '}
                        <strong>{doc.codigoCrcSei}</strong>
                      </td>
                      <td className="py-2.5 pr-3 text-suave">
                        <span className="text-tinta block">{doc.resumo}</span>
                        {doc.justificativaRetificacao && (
                          <span className="text-[11px] text-amber-900 font-medium block mt-0.5">
                            Justificativa da retificação: {doc.justificativaRetificacao}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 text-right whitespace-nowrap space-x-1.5">
                        {(doc.tipo === 'PARECER_SUMAE' ? doc.snapshotParecer : doc.snapshotDecisao) ? (
                          <>
                            <button
                              type="button"
                              onClick={() =>
                                setModalVisualizacao({
                                  tipo: doc.tipo,
                                  parecer: doc.snapshotParecer,
                                  decisao: doc.snapshotDecisao,
                                })
                              }
                              className="px-2.5 py-1 rounded border border-linha bg-white hover:bg-fundo text-tinta font-semibold cursor-pointer"
                            >
                              Visualizar
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (doc.tipo === 'PARECER_SUMAE' && doc.snapshotParecer) {
                                  baixarPdfParecer(doc.snapshotParecer);
                                } else if (doc.tipo === 'DECISAO_COMISSAO' && doc.snapshotDecisao) {
                                  baixarPdfDecisao(doc.snapshotDecisao);
                                }
                              }}
                              className="px-2.5 py-1 rounded bg-verde text-white font-semibold hover:bg-verde/90 cursor-pointer"
                            >
                              Baixar PDF SEI
                            </button>
                          </>
                        ) : (
                          <span className="text-suave">Cópia indisponível</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Histórico de Tramitação */}
        <div className="space-y-2 pt-3 border-t border-linha">
          <h4 className="text-xs font-bold uppercase tracking-wider text-suave">
            Registro Auditável de Tramitação ({analise.historicoTramitacao.length})
          </h4>
          <div className="space-y-1.5">
            {analise.historicoTramitacao.map((h) => (
              <div
                key={h.id}
                className="flex flex-wrap items-center justify-between gap-2 text-xs p-2.5 rounded border border-linha bg-fundo/30"
              >
                <div>
                  <span className="font-bold text-carmim">
                    [{ROTULO_ESTADO_TRAMITACAO[h.estadoNovo]}]
                  </span>{' '}
                  <span className="text-tinta">{h.descricao}</span>
                </div>
                <div className="text-[11px] text-suave tabular-nums">
                  {h.atorNome} ({h.papel}) · {formatarDataHora(h.dataHora)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
