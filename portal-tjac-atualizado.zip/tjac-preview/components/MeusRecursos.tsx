import React, { useCallback, useEffect, useState } from 'react';
import { ROTULO_ESTADO_TRAMITACAO } from '../services/analiseLogica';
import { api } from '../services/api';
import type { RecursoResumo } from '../types';
import { formatarDataHora } from '../utils';
import { Aviso } from './ui';

interface MeusRecursosProps {
  idToken: string;
  onAbrirAnalise?: (protocolo: string) => void;
}

const ROTULO_STATUS_ANALISE: Record<string, string> = {
  PENDENTE: 'Aguardando análise da Comissão Revisora',
  EM_ANALISE: 'Em análise técnica',
  NAO_CONHECIDO: 'Não conhecido (ausência de requisito formal)',
  PROVIDO: 'Recurso provido',
  PARCIALMENTE_PROVIDO: 'Parcialmente provido',
  IMPROVIDO: 'Recurso improvido',
};

export function MeusRecursos({ idToken, onAbrirAnalise }: MeusRecursosProps) {
  const [recursos, setRecursos] = useState<RecursoResumo[] | null>(null);
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(true);

  const carregar = useCallback(() => {
    setCarregando(true);
    setErro('');
    api
      .myAppeals(idToken)
      .then((res) => setRecursos(res.recursos || []))
      .catch((e) => setErro(e instanceof Error ? e.message : 'Falha ao consultar recursos.'))
      .finally(() => setCarregando(false));
  }, [idToken]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  return (
    <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-linha">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-tinta">
            Meus Recursos Protocolados
          </h2>
          <p className="text-xs sm:text-sm text-suave">
            Histórico de protocolos vinculados à sua conta Google autenticada.
          </p>
        </div>
        <button
          type="button"
          onClick={carregar}
          disabled={carregando}
          className="px-3 py-1.5 rounded-md border border-linha bg-fundo hover:bg-linha/50 text-xs font-semibold text-tinta cursor-pointer disabled:opacity-50"
        >
          {carregando ? 'Atualizando…' : 'Atualizar lista'}
        </button>
      </div>

      {erro && <Aviso tipo="erro">{erro}</Aviso>}

      {carregando && !recursos && (
        <p className="text-sm text-suave py-6 text-center">Consultando protocolos…</p>
      )}

      {!carregando && recursos && recursos.length === 0 && (
        <div className="bg-fundo border border-linha rounded-lg p-6 text-center space-y-1">
          <p className="text-sm font-semibold text-tinta">
            Nenhum recurso encontrado para este e-mail.
          </p>
          <p className="text-xs text-suave">
            Utilize a aba <strong>Novo recurso</strong> para registrar e transmitir sua impugnação.
          </p>
        </div>
      )}

      {recursos && recursos.length > 0 && (
        <div className="space-y-4">
          {recursos.map((r) => (
            <article
              key={r.protocolo}
              className="border border-linha rounded-lg p-4 space-y-3 bg-fundo/40"
            >
              <div className="flex flex-wrap items-start justify-between gap-3 pb-2 border-b border-linha">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-mono text-sm sm:text-base font-bold text-carmim tabular-nums">
                      {r.protocolo}
                    </p>
                    {r.processoSei && (
                      <span className="px-2 py-0.5 rounded bg-white border border-linha font-mono text-[11px] font-semibold text-tinta">
                        SEI {r.processoSei}
                      </span>
                    )}
                    {r.estadoTramitacao && (
                      <span className="px-2 py-0.5 rounded bg-carmim/10 border border-carmim/25 text-[11px] font-semibold text-carmim">
                        {ROTULO_ESTADO_TRAMITACAO[r.estadoTramitacao]}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold text-tinta">{r.unidade}</p>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <div className="text-right text-xs text-suave tabular-nums">
                    <p className="font-semibold text-tinta">
                      Status: {r.status === 'ENVIADO' ? 'ENVIADO' : r.status}
                    </p>
                    <p>
                      Enviado em:{' '}
                      {r.enviadoEm ? formatarDataHora(r.enviadoEm) : formatarDataHora(r.criadoEm)}
                    </p>
                  </div>
                  {onAbrirAnalise && (
                    <button
                      type="button"
                      onClick={() => onAbrirAnalise(r.protocolo)}
                      className="px-3 py-1.5 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer"
                    >
                      Abrir Análise do Recurso →
                    </button>
                  )}
                </div>
              </div>

              {r.itens.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-linha text-suave">
                        <th className="py-1.5 pr-3 font-semibold">Indicador</th>
                        <th className="py-1.5 pr-3 font-semibold">Recorte / Subitem</th>
                        <th className="py-1.5 pr-3 font-semibold text-right">Evidências</th>
                        <th className="py-1.5 font-semibold">Situação da Análise</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-linha/60">
                      {r.itens.map((it, i) => (
                        <tr key={`${r.protocolo}-${it.sigla}-${i}`}>
                          <td className="py-2 pr-3 font-bold text-tinta whitespace-nowrap">
                            {it.sigla}
                          </td>
                          <td className="py-2 pr-3 text-suave">{it.subitem || '—'}</td>
                          <td className="py-2 pr-3 text-right tabular-nums text-tinta">
                            {it.qtdArquivos} arq(s)
                          </td>
                          <td className="py-2 text-tinta">
                            {ROTULO_STATUS_ANALISE[it.statusAnalise] || it.statusAnalise || 'PENDENTE'}
                            {it.decisao ? ` · ${it.decisao}` : ''}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-xs text-suave">
                  Impugnação exclusiva da lista de servidores vinculados (art. 5º, III, &ldquo;b&rdquo;).
                </p>
              )}
              {r.impugnaListaServidores && r.itens.length > 0 && (
                <p className="text-xs text-suave pt-1 border-t border-linha/60">
                  Inclui impugnação da lista de servidores vinculados à unidade (art. 5º, III, &ldquo;b&rdquo;).
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
