import React from 'react';
import { PORTARIA, TIPOS_IMPUGNACAO_INFO, TIPOS_UNIDADE_INFO } from '../catalogo';
import type { ResultadoEnvio } from '../types';
import { formatarBytes, formatarCpf, formatarDataHora } from '../utils';
import { LogoTJAC } from './LogoTJAC';
import { Aviso } from './ui';

interface ComprovanteProps {
  r: ResultadoEnvio;
  onNovo: () => void;
}

export function Comprovante({ r, onNovo }: ComprovanteProps) {
  const { payload } = r;
  const infoTipoUnidade = TIPOS_UNIDADE_INFO.find((t) => t.codigo === payload.unidade.tipo);

  return (
    <div className="space-y-6">
      <div className="print:hidden">
        <Aviso tipo="sucesso">
          <strong>Recurso protocolado com sucesso!</strong> Guarde ou imprima este comprovante. O
          protocolo também pode ser consultado na aba <strong>Meus recursos</strong>.
        </Aviso>
      </div>

      <article className="bg-white border border-linha rounded-lg p-6 sm:p-8 space-y-6 print:border-0 print:p-0">
        {/* Cabeçalho do Comprovante */}
        <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-linha">
          <div className="space-y-2">
            <LogoTJAC variante="carmim" mostrarSubtituloPortal={false} />
            <div className="pt-1">
              <p className="text-xs uppercase tracking-widest text-suave font-semibold">
                Diretoria de Gestão Estratégica (DIGED) · SUMAE / SEGOV
              </p>
              <h2 className="text-xl sm:text-2xl font-bold text-tinta">
                Comprovante de Interposição de Recurso
              </h2>
              <p className="text-xs text-suave">{PORTARIA}</p>
            </div>
          </div>

          <div className="bg-fundo border border-linha rounded-md px-4 py-3 text-right">
            <p className="text-[11px] uppercase tracking-wider text-suave font-semibold">
              Número do Protocolo
            </p>
            <p className="text-lg sm:text-xl font-bold text-carmim font-mono tabular-nums">
              {r.protocolo}
            </p>
            <p className="text-xs text-verde font-semibold">Status: {r.status}</p>
          </div>
        </div>

        {/* Metadados gerais */}
        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm border-b border-linha pb-5">
          <div>
            <dt className="text-xs text-suave">Unidade Judiciária / Órgão</dt>
            <dd className="font-semibold text-tinta">
              {payload.unidade.codigo ? `${payload.unidade.codigo} — ` : ''}
              {payload.unidade.nome}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-suave">Grau / Tipo / Comarca</dt>
            <dd className="font-medium text-tinta">
              {payload.unidade.grau === '1G' ? '1º Grau' : '2º Grau'} ·{' '}
              {infoTipoUnidade?.rotulo || payload.unidade.tipo} · {payload.unidade.comarca || 'AC'}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-suave">Responsável pela Interposição</dt>
            <dd className="font-medium text-tinta">
              {payload.responsavel.nome} ({payload.responsavel.cargo})
            </dd>
          </div>
          <div>
            <dt className="text-xs text-suave">CPF e Conta Google Autenticada</dt>
            <dd className="font-medium text-tinta tabular-nums">
              {formatarCpf(payload.responsavel.cpf)} · {r.usuario.email}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-suave">Data e Hora do Recebimento</dt>
            <dd className="font-semibold text-tinta tabular-nums">
              {formatarDataHora(r.enviadoEm)}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-suave">Identificador de Requisição (Idempotência)</dt>
            <dd className="font-mono text-xs text-suave">{payload.clientRequestId}</dd>
          </div>
        </dl>

        {/* Itens impugnados */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-tinta">
            Itens Impugnados ({payload.itens.length})
          </h3>

          {payload.itens.length === 0 ? (
            <p className="text-sm text-suave">
              Protocolo exclusivo para impugnação da lista de servidores vinculados.
            </p>
          ) : (
            <div className="space-y-4">
              {payload.itens.map((it, i) => {
                const n = i + 1;
                const arqsItem = r.arquivos.filter((a) => a.itemN === n);
                const rotuloTipo =
                  TIPOS_IMPUGNACAO_INFO.find((t) => t.codigo === it.tipoImpugnacao)?.rotulo ||
                  it.tipoImpugnacao;

                return (
                  <div
                    key={`${it.sigla}-${i}`}
                    className="border border-linha rounded-md p-4 space-y-2.5 bg-fundo/40"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h4 className="text-sm font-bold text-tinta">
                        <span className="text-carmim tabular-nums mr-1">#{n}</span>
                        {it.sigla} — {it.indicador}
                      </h4>
                      <span className="text-xs text-suave tabular-nums">
                        Preliminar: <strong className="text-tinta">{it.pontuacaoPreliminar !== '' ? `${it.pontuacaoPreliminar} pts` : '—'}</strong>{' '}
                        → Pleiteada:{' '}
                        <strong className="text-tinta">
                          {it.pontuacaoPleiteada !== '' ? `${it.pontuacaoPleiteada} pts` : 'Exclusão (N/A)'}
                        </strong>
                      </span>
                    </div>

                    <p className="text-xs text-suave">
                      <strong className="text-tinta">Recorte/Subitem:</strong> {it.subitem} ·{' '}
                      <strong className="text-tinta">Natureza:</strong> {rotuloTipo}
                    </p>

                    <div className="bg-white border border-linha rounded p-3 text-xs text-tinta whitespace-pre-wrap leading-relaxed">
                      {it.fundamentacao}
                    </div>

                    <div className="text-xs text-suave">
                      <strong className="text-tinta">
                        Evidências anexadas ({arqsItem.length}):
                      </strong>
                      <ul className="mt-1 space-y-1">
                        {arqsItem.map((a, idxA) => (
                          <li key={idxA} className="font-mono text-[11px] text-suave break-all">
                            • {a.nome} ({formatarBytes(a.bytes)}) — SHA-256: {a.sha256}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Lista de servidores vinculados, se impugnada */}
        {payload.listaServidores.impugna && (
          <div className="space-y-2 pt-3 border-t border-linha">
            <h3 className="text-sm font-bold text-tinta">
              Impugnação da Lista de Servidores Vinculados (Art. 5º, III, &ldquo;b&rdquo; e Art. 6º)
            </h3>
            <p className="bg-fundo border border-linha rounded p-3 text-xs text-tinta whitespace-pre-wrap leading-relaxed">
              {payload.listaServidores.texto}
            </p>
          </div>
        )}

        <div className="pt-4 border-t border-linha text-xs text-suave leading-relaxed">
          Nos termos do art. 14 da Portaria PRESI/TJAC nº 1961/2026 (com redação dada pela Portaria
          PRESI nº 4335, de 8/10/2026), o resultado da avaliação dos recursos interpostos será
          divulgado por ocasião da outorga do Prêmio TJAC de Qualidade (18/12/2026).
        </div>

        {/* Ações */}
        <div className="flex flex-wrap items-center justify-end gap-3 pt-2 print:hidden">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-4 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-xs sm:text-sm font-semibold text-tinta cursor-pointer"
          >
            Imprimir / Salvar em PDF
          </button>
          <button
            type="button"
            onClick={onNovo}
            className="px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs sm:text-sm font-semibold cursor-pointer"
          >
            Apresentar novo recurso
          </button>
        </div>
      </article>
    </div>
  );
}
