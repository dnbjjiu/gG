import React from 'react';
import { PORTARIA } from '../catalogo';
import { LogoTJAC } from './LogoTJAC';

interface InstrucoesProps {
  onIrParaLogin?: () => void;
}

export function Instrucoes({ onIrParaLogin }: InstrucoesProps) {
  return (
    <section className="bg-white border border-linha rounded-lg p-6 sm:p-8 space-y-6 shadow-2xs">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-linha">
        <div className="space-y-1.5">
          <p className="text-xs uppercase tracking-wider text-carmim font-semibold">
            Orientações Normativas e Operacionais · {PORTARIA}
          </p>
          <h2 className="text-xl font-bold text-tinta">
            Submissão de Recursos — Resultado Preliminar e Lista de Servidores
          </h2>
        </div>
        <LogoTJAC variante="carmim" mostrarSubtituloPortal={false} className="hidden sm:flex" />
      </div>

      <p className="text-sm text-suave leading-relaxed">
        Formulário eletrônico destinado às unidades judiciárias de 1º Grau, Gabinetes de
        Desembargadores, Vice-Presidência e Secretaria Judiciária (SEJUD) para interposição de
        recurso fundamentado em face do Resultado Preliminar (art. 5º, III, &ldquo;a&rdquo; e
        art. 13) e/ou impugnação da lista de servidores vinculados (art. 5º, III, &ldquo;b&rdquo;
        e art. 6º).
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <div className="bg-fundo/60 border border-linha rounded-lg p-5 space-y-3">
          <h3 className="text-sm sm:text-base font-bold text-tinta border-b border-linha pb-2">
            Regras de Conhecimento do Recurso
          </h3>
          <ul className="space-y-3 text-xs sm:text-sm text-suave list-disc pl-5 leading-relaxed">
            <li>
              <strong className="text-tinta">Prazo recursal (art. 5º, III):</strong> de 04/12/2026
              a 07/12/2026 (até 23h59min59s, horário de Rio Branco/AC).
            </li>
            <li>
              <strong className="text-tinta">
                Objetividade e evidências (art. 13 e Anexo III, item 3):
              </strong>{' '}
              o recurso deve identificar obrigatoriamente:
              <ul className="mt-1.5 space-y-1 list-none pl-2 text-xs text-tinta">
                <li>
                  <strong>(a)</strong> painel ou relatório oficial consultado;
                </li>
                <li>
                  <strong>(b)</strong> filtros aplicados na extração;
                </li>
                <li>
                  <strong>(c)</strong> período de referência (1º/01 a 30/11/2026);
                </li>
                <li>
                  <strong>(d)</strong> memória de cálculo detalhada; e
                </li>
                <li>
                  <strong>(e)</strong> número (NPU) e quantidade exata dos processos impugnados, sob
                  pena de <strong>não conhecimento</strong> pela Comissão Revisora.
                </li>
              </ul>
            </li>
            <li>
              <strong className="text-tinta">Efeito devolutivo amplo (art. 13, § 2º):</strong> a
              avaliação poderá ensejar acréscimo ou decréscimo da pontuação inicialmente conferida.
            </li>
            <li>
              <strong className="text-tinta">Divulgação do julgamento (art. 14):</strong> o
              resultado da análise dos recursos será divulgado na solenidade de outorga do Prêmio
              (18/12/2026).
            </li>
          </ul>
        </div>

        <div className="bg-fundo/60 border border-linha rounded-lg p-5 space-y-4">
          <h3 className="text-sm sm:text-base font-bold text-tinta border-b border-linha pb-2">
            Perfis de Acesso e Fluxo de Tramitação Institucional
          </h3>
          <ul className="space-y-3 text-xs sm:text-sm text-suave list-disc pl-5 leading-relaxed">
            <li>
              <strong className="text-tinta">Login Administrador (DIGED/TJAC):</strong> acesso
              habilitado para as contas credenciadas (
              <code className="text-tinta font-mono">josue.silva@tjac.jus.br</code> e{' '}
              <code className="text-tinta font-mono">arturgemeos06@gmail.com</code>) para gestão
              consolidada de todos os recursos e acesso às evidências no Google Drive, Sheets e
              Forms.
            </li>
            <li>
              <strong className="text-tinta">Login Unidade Judiciária:</strong> destinado a
              Magistrados(as), Diretores(as) de Secretaria e Assessores(as) de Gabinete para
              interposição de recursos fundamentados, anexação de evidências e acompanhamento dos
              protocolos emitidos.
            </li>
            <li>
              <strong className="text-tinta">Login Comissão Revisora e SUMAE:</strong> ambiente
              integrado da aba <strong>Análise do Recurso</strong> para elaboração e emissão do{' '}
              <strong>Parecer Técnico da SUMAE</strong> (Subsecretaria de Monitoramento e Análise
              Estratégica) e prolação da <strong>Decisão Final da Comissão Revisora</strong>, com
              geração de documentos oficiais em PDF para juntada ao processo SEI individual de cada
              protocolo.
            </li>
          </ul>

          <div className="bg-white border border-linha rounded-md p-3.5 text-xs space-y-1.5">
            <p className="font-bold text-carmim uppercase tracking-wider text-[11px]">
              Etapas da Análise do Recurso (Vínculo Permanente ao Protocolo e SEI)
            </p>
            <p className="text-suave leading-relaxed">
              1. <strong>Recebido</strong> → 2. <strong>Em análise pela SUMAE</strong> → 3.{' '}
              <strong>Encaminhado à Comissão</strong> → 4.{' '}
              <strong>Em análise pela Comissão</strong> → 5. <strong>Decidido</strong>.
            </p>
          </div>
        </div>
      </div>

      {onIrParaLogin && (
        <div className="pt-2 border-t border-linha flex justify-end">
          <button
            type="button"
            onClick={onIrParaLogin}
            className="px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
          >
            ← Voltar para a tela de Login
          </button>
        </div>
      )}
    </section>
  );
}
