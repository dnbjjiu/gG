import React, { useEffect, useMemo, useState } from 'react';
import {
  COMARCAS_ACRE,
  EVIDENCIAS_OBRIGATORIAS,
  INDICADORES_CATALOGO,
  TIPOS_IMPUGNACAO_INFO,
  TIPOS_UNIDADE_INFO,
  indicadoresParaUnidade,
} from '../catalogo';
import { MODO_DEMO } from '../config';
import { ApiError, api } from '../services/api';
import type {
  ArquivoEnviadoResumo,
  ConfigServidor,
  CriarRecursoPayload,
  Grau,
  ItemRecursoInput,
  ResultadoEnvio,
  TipoImpugnacao,
  TipoUnidade,
  Usuario,
} from '../types';
import {
  apenasDigitos,
  arquivoParaBase64,
  calcularSha256Arquivo,
  cpfValido,
  formatarBytes,
  formatarCpf,
  formatarTelefone,
  gerarIdRequisicao,
  numeroOuVazio,
  validarPayloadRecurso,
} from '../utils';
import { Aviso, CLASSE_INPUT, Campo, Secao } from './ui';

interface FormularioProps {
  usuario: Usuario;
  idToken: string;
  config: ConfigServidor;
  onEnviado: (r: ResultadoEnvio) => void;
  onSessaoExpirada: () => void;
}

const CHAVE_RASCUNHO = 'premio-tjac-2026:rascunho-v1';

const CARGOS_SUGERIDOS = [
  'Juiz(a) de Direito Titular',
  'Juiz(a) de Direito Substituto(a)',
  'Desembargador(a)',
  'Diretor(a) de Secretaria',
  'Assessor(a) de Gabinete',
  'Secretário(a) Judiciário(a)',
];

function criarItemVazio(grau: Grau, tipo: TipoUnidade): ItemRecursoInput {
  const disponiveis = indicadoresParaUnidade(grau, tipo);
  const primeiro = disponiveis[0] || INDICADORES_CATALOGO[0];
  return {
    id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    grupo: primeiro.grupo,
    sigla: primeiro.sigla,
    indicador: primeiro.nome,
    subitem: primeiro.subitens[0] || 'Apuração Geral',
    tipoImpugnacao: 'APURACAO',
    pontuacaoPreliminar: '',
    pontuacaoPleiteada: String(primeiro.pontosMax),
    fundamentacao: '',
    evidencias: { a: false, b: false, c: false, d: false, e: false },
  };
}

function criarPdfExemplo(sigla: string, unidadeNome: string): File {
  const conteudo = `%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >> endobj
% Evidencia ${sigla} - ${unidadeNome} - Data de corte 30/11/2026 - Painel BI PJAC
trailer << /Root 1 0 R >>
%%EOF`;
  const nomeSeguro = `Evidencia_BI_PJAC_${sigla.replace(/[^A-Za-z0-9_-]/g, '_')}_2026.pdf`;
  return new File([conteudo], nomeSeguro, { type: 'application/pdf' });
}

function erroPontuacao(valor: string, maximo?: number): string | undefined {
  if (valor === '' || maximo === undefined) return;
  const pontos = Number(valor.replace(',', '.'));
  if (!Number.isFinite(pontos) || pontos < 0 || pontos > maximo) {
    return `Informe um valor entre 0 e ${maximo} pontos.`;
  }
}

export function Formulario({
  usuario,
  idToken,
  config,
  onEnviado,
  onSessaoExpirada,
}: FormularioProps) {
  const [clientRequestId, setClientRequestId] = useState(gerarIdRequisicao);
  const [nomeResp, setNomeResp] = useState(usuario.nome || '');
  const [cpfResp, setCpfResp] = useState('');
  const [cargoResp, setCargoResp] = useState('Juiz(a) de Direito Titular');
  const [telefoneResp, setTelefoneResp] = useState('');

  const [grau, setGrau] = useState<Grau>('1G');
  const [tipoUnidade, setTipoUnidade] = useState<TipoUnidade>('CIVEL');
  const [modoUnidadeManual, setModoUnidadeManual] = useState(false);
  const [codigoUnidade, setCodigoUnidade] = useState('RB-1CIV');
  const [nomeUnidade, setNomeUnidade] = useState('1ª Vara Cível da Comarca de Rio Branco');
  const [comarca, setComarca] = useState('Rio Branco');

  const [itens, setItens] = useState<ItemRecursoInput[]>(() => [criarItemVazio('1G', 'CIVEL')]);
  const [arquivosPorItem, setArquivosPorItem] = useState<Record<string, File[]>>({});

  const [impugnaLista, setImpugnaLista] = useState(false);
  const [textoLista, setTextoLista] = useState('');
  const [declaracao, setDeclaracao] = useState(false);

  const [erros, setErros] = useState<string[]>([]);
  const [enviando, setEnviando] = useState(false);
  const [etapaEnvio, setEtapaEnvio] = useState('');

  // Restaurar rascunho salvo
  useEffect(() => {
    try {
      const raw = localStorage.getItem(CHAVE_RASCUNHO);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (d.nomeResp) setNomeResp(d.nomeResp);
      if (d.cpfResp) setCpfResp(d.cpfResp);
      if (d.cargoResp) setCargoResp(d.cargoResp);
      if (d.telefoneResp) setTelefoneResp(d.telefoneResp);
      if (d.grau === '1G' || d.grau === '2G') setGrau(d.grau);
      if (d.tipoUnidade) setTipoUnidade(d.tipoUnidade);
      if (d.codigoUnidade != null) setCodigoUnidade(d.codigoUnidade);
      if (d.nomeUnidade) setNomeUnidade(d.nomeUnidade);
      if (d.comarca) setComarca(d.comarca);
      if (Array.isArray(d.itens) && d.itens.length > 0) setItens(d.itens);
      if (typeof d.impugnaLista === 'boolean') setImpugnaLista(d.impugnaLista);
      if (typeof d.textoLista === 'string') setTextoLista(d.textoLista);
    } catch {
      /* ignora rascunho inválido */
    }
  }, []);

  // Salvar rascunho automaticamente
  useEffect(() => {
    try {
      localStorage.setItem(
        CHAVE_RASCUNHO,
        JSON.stringify({
          nomeResp,
          cpfResp,
          cargoResp,
          telefoneResp,
          grau,
          tipoUnidade,
          codigoUnidade,
          nomeUnidade,
          comarca,
          itens,
          impugnaLista,
          textoLista,
        })
      );
    } catch {
      /* ignora erro de armazenamento */
    }
  }, [
    nomeResp,
    cpfResp,
    cargoResp,
    telefoneResp,
    grau,
    tipoUnidade,
    codigoUnidade,
    nomeUnidade,
    comarca,
    itens,
    impugnaLista,
    textoLista,
  ]);

  const tiposUnidadeDoGrau = useMemo(
    () => TIPOS_UNIDADE_INFO.filter((t) => t.grau === grau),
    [grau]
  );

  const unidadesFiltradas = useMemo(() => {
    const lista = config.unidades?.length ? config.unidades : [];
    return lista.filter((u) => u.grau === grau && u.tipo === tipoUnidade);
  }, [config.unidades, grau, tipoUnidade]);

  const indicadoresDisponiveis = useMemo(
    () => indicadoresParaUnidade(grau, tipoUnidade),
    [grau, tipoUnidade]
  );

  const selecionarGrau = (novoGrau: Grau) => {
    setGrau(novoGrau);
    const primeiroTipo = TIPOS_UNIDADE_INFO.find((t) => t.grau === novoGrau)?.codigo || 'CIVEL';
    selecionarTipoUnidade(novoGrau, primeiroTipo);
  };

  const selecionarTipoUnidade = (g: Grau, novoTipo: TipoUnidade) => {
    setTipoUnidade(novoTipo);
    const candidatas = (config.unidades || []).filter((u) => u.grau === g && u.tipo === novoTipo);
    if (candidatas.length > 0 && !modoUnidadeManual) {
      setCodigoUnidade(candidatas[0].codigo);
      setNomeUnidade(candidatas[0].nome);
      setComarca(candidatas[0].comarca);
    } else if (candidatas.length === 0) {
      setCodigoUnidade('');
    }
    const disp = indicadoresParaUnidade(g, novoTipo);
    const indPadrao = disp[0];
    if (indPadrao) {
      setItens((atual) =>
        atual.map((it) => {
          const aindaValido = disp.some((d) => d.sigla === it.sigla);
          if (aindaValido) return it;
          return {
            ...it,
            grupo: indPadrao.grupo,
            sigla: indPadrao.sigla,
            indicador: indPadrao.nome,
            subitem: indPadrao.subitens[0] || 'Apuração Geral',
            pontuacaoPleiteada: String(indPadrao.pontosMax),
          };
        })
      );
    }
  };

  const atualizarItem = (id: string, parcial: Partial<ItemRecursoInput>) => {
    setItens((atual) => atual.map((it) => (it.id === id ? { ...it, ...parcial } : it)));
  };

  const selecionarIndicadorItem = (id: string, sigla: string) => {
    const info =
      indicadoresDisponiveis.find((d) => d.sigla === sigla) ||
      INDICADORES_CATALOGO.find((d) => d.sigla === sigla);
    if (!info) return;
    atualizarItem(id, {
      grupo: info.grupo,
      sigla: info.sigla,
      indicador: info.nome,
      subitem: info.subitens[0] || 'Apuração Geral',
      pontuacaoPleiteada: String(info.pontosMax),
    });
  };

  const adicionarItem = () => {
    if (itens.length >= 40) return;
    const novo = criarItemVazio(grau, tipoUnidade);
    // Tenta escolher um indicador ainda não usado para evitar duplicidade inicial
    const usados = new Set(itens.map((i) => i.sigla));
    const livre = indicadoresDisponiveis.find((d) => !usados.has(d.sigla));
    if (livre) {
      novo.grupo = livre.grupo;
      novo.sigla = livre.sigla;
      novo.indicador = livre.nome;
      novo.subitem = livre.subitens[0] || 'Apuração Geral';
      novo.pontuacaoPleiteada = String(livre.pontosMax);
    }
    setItens((atual) => [...atual, novo]);
  };

  const removerItem = (id: string) => {
    setItens((atual) => atual.filter((i) => i.id !== id));
    setArquivosPorItem((atual) => {
      const copia = { ...atual };
      delete copia[id];
      return copia;
    });
  };

  const adicionarArquivos = (itemId: string, novos: FileList | File[] | null) => {
    if (!novos) return;
    const listaNovos = Array.from(novos);
    const msgsErro: string[] = [];

    setArquivosPorItem((atual) => {
      const existentes = atual[itemId] || [];
      const combinados = [...existentes];

      for (const arq of listaNovos) {
        if (combinados.length >= config.limites.maxArqPorItem) {
          msgsErro.push(`Limite máximo de ${config.limites.maxArqPorItem} arquivos por item atingido.`);
          break;
        }
        if (arq.size > config.limites.maxBytesArq) {
          msgsErro.push(`O arquivo "${arq.name}" excede 10 MB.`);
          continue;
        }
        if (arq.type && !config.limites.mimes.includes(arq.type)) {
          msgsErro.push(
            `Formato não permitido em "${arq.name}". Use PDF, PNG, JPG, XLSX, XLS, CSV ou DOCX.`
          );
          continue;
        }
        combinados.push(arq);
      }
      return { ...atual, [itemId]: combinados };
    });

    if (msgsErro.length > 0) {
      setErros(msgsErro);
    }
  };

  const removerArquivo = (itemId: string, index: number) => {
    setArquivosPorItem((atual) => {
      const lista = [...(atual[itemId] || [])];
      lista.splice(index, 1);
      return { ...atual, [itemId]: lista };
    });
  };

  const preencherExemploDemo = () => {
    setNomeResp(usuario.nome || 'Dra. Helena Albuquerque — Juíza de Direito');
    setCpfResp('529.982.247-25');
    setCargoResp('Juiz(a) de Direito Titular');
    setTelefoneResp('(68) 3212-8200');
    setGrau('1G');
    setTipoUnidade('CIVEL');
    setModoUnidadeManual(false);
    setCodigoUnidade('RB-1CIV');
    setNomeUnidade('1ª Vara Cível da Comarca de Rio Branco');
    setComarca('Rio Branco');

    const itemExemploId = `item-demo-${Date.now()}`;
    const itemExemplo: ItemRecursoInput = {
      id: itemExemploId,
      grupo: '1º Grau — Indicadores Gerais',
      sigla: 'IAD-C',
      indicador: 'Índice de Atendimento à Demanda — Critério Conjugado',
      subitem: 'Condição de Compensação pela Taxa de Congestionamento Líquida (TCL < 25%)',
      tipoImpugnacao: 'FAIXA_ARREDONDAMENTO',
      pontuacaoPreliminar: '0',
      pontuacaoPleiteada: '80',
      fundamentacao:
        'Conforme extrato do Painel de BI do PJAC (Intranet Institucional) com data de corte em 30/11/2026 às 23h59min59s, a 1ª Vara Cível da Comarca de Rio Branco alcançou IAD de 96,42% (2.154 processos baixados para 2.234 casos novos no período de 01/01/2026 a 30/11/2026) e Taxa de Congestionamento Líquida (TCL) de 23,18% (< 25%). Nos termos do art. 8º, parágrafo único, II, e Anexo IV, item 1, da Portaria PRESI nº 1961/2026 (alterada pela Portaria PRESI nº 4335/2026), aplica-se a regra de compensação para atribuir 80 pontos no indicador IAD-C.',
      evidencias: { a: true, b: true, c: true, d: true, e: true },
    };

    setItens([itemExemplo]);
    setArquivosPorItem({
      [itemExemploId]: [criarPdfExemplo('IAD-C', '1a_Vara_Civel_Rio_Branco')],
    });
    setImpugnaLista(false);
    setTextoLista('');
    setDeclaracao(true);
    setErros([]);
  };

  const construirPayload = (): CriarRecursoPayload => ({
    clientRequestId,
    declaracao,
    responsavel: {
      nome: nomeResp.trim(),
      cpf: apenasDigitos(cpfResp),
      cargo: cargoResp.trim(),
      telefone: telefoneResp.trim(),
    },
    unidade: {
      grau,
      tipo: tipoUnidade,
      codigo: codigoUnidade.trim(),
      nome: nomeUnidade.trim(),
      comarca: comarca.trim(),
    },
    listaServidores: {
      impugna: impugnaLista,
      texto: impugnaLista ? textoLista.trim() : '',
    },
    itens: itens.map((it) => ({
      grupo: it.grupo,
      sigla: it.sigla,
      indicador: it.indicador,
      subitem: it.subitem,
      tipoImpugnacao: it.tipoImpugnacao,
      pontuacaoPreliminar: numeroOuVazio(it.pontuacaoPreliminar),
      pontuacaoPleiteada: numeroOuVazio(it.pontuacaoPleiteada),
      fundamentacao: it.fundamentacao.trim(),
      evidencias: { ...it.evidencias },
    })),
  });

  const submeter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!config.prazo.aberto) {
      setErros(['O prazo para interposição de recursos encontra-se encerrado.']);
      return;
    }

    const payload = construirPayload();
    const listaErros = validarPayloadRecurso(payload, config.limites);

    // Validação obrigatória de pelo menos 1 arquivo de evidência por item (Anexo III, item 3 e acaoFinalizar_)
    itens.forEach((it, idx) => {
      const maximo = INDICADORES_CATALOGO.find((indicador) => indicador.sigla === it.sigla)?.pontosMax;
      const preliminar = erroPontuacao(it.pontuacaoPreliminar, maximo);
      const solicitada = erroPontuacao(it.pontuacaoPleiteada, maximo);
      if (preliminar) listaErros.push(`Item ${idx + 1} (${it.sigla}), pontuação preliminar: ${preliminar}`);
      if (solicitada) listaErros.push(`Item ${idx + 1} (${it.sigla}), pontuação solicitada: ${solicitada}`);
      const arqs = arquivosPorItem[it.id] || [];
      if (arqs.length < 1) {
        listaErros.push(
          `Item ${idx + 1} (${it.sigla}): anexe ao menos 1 arquivo comprobatório das evidências (Anexo III, item 3).`
        );
      }
    });

    if (listaErros.length > 0) {
      setErros(listaErros);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setErros([]);
    setEnviando(true);

    try {
      setEtapaEnvio('Registrando protocolo recursal…');
      const criado = await api.create(idToken, payload);
      const protocolo = criado.protocolo;

      const arquivosEnviados: ArquivoEnviadoResumo[] = [];

      for (let i = 0; i < itens.length; i++) {
        const item = itens[i];
        const itemN = i + 1;
        const arqs = arquivosPorItem[item.id] || [];

        for (let j = 0; j < arqs.length; j++) {
          const arq = arqs[j];
          setEtapaEnvio(
            `Enviando evidência ${j + 1}/${arqs.length} do item ${itemN} (${item.sigla}): ${arq.name}…`
          );
          const [base64, sha256] = await Promise.all([
            arquivoParaBase64(arq),
            calcularSha256Arquivo(arq),
          ]);
          const up = await api.upload(idToken, {
            protocolo,
            itemN,
            nome: arq.name,
            mime: arq.type || 'application/pdf',
            base64,
            bytes: arq.size,
            sha256,
          });
          arquivosEnviados.push({
            itemN,
            sigla: item.sigla,
            subitem: item.subitem,
            nome: up.nome,
            mime: arq.type || 'application/pdf',
            bytes: up.bytes,
            sha256: up.sha256,
            fileId: up.fileId,
          });
        }
      }

      setEtapaEnvio('Finalizando protocolo e gerando comprovante…');
      const fim = await api.finalize(idToken, { protocolo });

      try {
        localStorage.removeItem(CHAVE_RASCUNHO);
      } catch {
        /* ignora */
      }
      setClientRequestId(gerarIdRequisicao());

      onEnviado({
        protocolo: fim.protocolo,
        status: fim.status,
        enviadoEm: fim.enviadoEm,
        reaproveitado: fim.reaproveitado,
        usuario,
        payload,
        arquivos: arquivosEnviados,
      });
    } catch (err) {
      if (
        err instanceof ApiError &&
        ['TOKEN_EXPIRADO', 'TOKEN_INVALIDO', 'NAO_AUTENTICADO'].includes(err.codigo)
      ) {
        onSessaoExpirada();
        return;
      }
      const msg =
        err instanceof Error ? err.message : 'Falha inesperada ao transmitir o recurso.';
      setErros(msg.split(' | '));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setEnviando(false);
      setEtapaEnvio('');
    }
  };

  return (
    <form onSubmit={submeter} noValidate lang="pt-BR" className="space-y-6 text-base leading-relaxed [&_section_h2]:text-xl [&_section_h2]:leading-snug sm:[&_section_h2]:text-2xl [&_label]:text-sm [&_input]:text-base [&_select]:text-base [&_textarea]:text-base [&_textarea]:leading-relaxed">
      <h2 className="text-2xl font-bold leading-tight tracking-tight text-tinta sm:text-3xl">
        Novo recurso
      </h2>
      {/* Banner orientativo e atalho de demonstração */}
      <div className="bg-white border border-linha rounded-lg p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
        <details className="min-w-0 flex-1 text-sm">
          <summary className="cursor-pointer font-semibold text-carmim">Regras das evidências</summary>
          <p className="mt-2 text-suave">
            Use evidências do BI do PJAC ou de fontes oficiais com data de corte em
            <strong> 30/11/2026 às 23h59min59s</strong>. A ausência das evidências obrigatórias
            implica o não conhecimento do recurso (art. 13 e Anexo III, item 3).
          </p>
        </details>
        {MODO_DEMO && (
          <button
            type="button"
            onClick={preencherExemploDemo}
            className="px-3.5 py-2 rounded-md border border-ouro/60 bg-[#FFFDF7] hover:bg-ouro/10 text-xs font-semibold text-tinta transition-colors cursor-pointer shrink-0"
          >
            Preencher exemplo de recurso
          </button>
        )}
      </div>

      {erros.length > 0 && (
        <Aviso tipo="erro">
          <p className="font-bold mb-1.5">Verifique as pendências abaixo antes de enviar:</p>
          <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
            {erros.map((er, i) => (
              <li key={i}>{er}</li>
            ))}
          </ul>
        </Aviso>
      )}

      {/* 1. IDENTIFICAÇÃO DO RESPONSÁVEL */}
      <Secao
        numero="1"
        titulo="Responsável pelo envio"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Campo id="resp-nome" rotulo="Nome completo" obrigatorio>
            <input
              id="resp-nome"
              type="text"
              value={nomeResp}
              onChange={(e) => setNomeResp(e.target.value)}
              placeholder="Nome completo sem abreviações"
              className={CLASSE_INPUT}
              maxLength={150}
              required
            />
          </Campo>

          <Campo
            id="resp-cpf"
            rotulo="CPF"
            obrigatorio
            erro={cpfResp.length >= 14 && !cpfValido(cpfResp) ? 'CPF inválido (verifique os dígitos).' : undefined}
          >
            <input
              id="resp-cpf"
              type="text"
              inputMode="numeric"
              value={cpfResp}
              onChange={(e) => setCpfResp(formatarCpf(e.target.value))}
              placeholder="000.000.000-00"
              className={`${CLASSE_INPUT} tabular-nums`}
              maxLength={14}
              required
            />
          </Campo>

          <Campo id="resp-cargo" rotulo="Cargo ou função" obrigatorio>
            <input
              id="resp-cargo"
              type="text"
              list="lista-cargos-tjac"
              value={cargoResp}
              onChange={(e) => setCargoResp(e.target.value)}
              placeholder="Ex.: Diretor(a) de Secretaria"
              className={CLASSE_INPUT}
              maxLength={120}
              required
            />
            <datalist id="lista-cargos-tjac">
              {CARGOS_SUGERIDOS.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </Campo>

          <Campo id="resp-telefone" rotulo="Telefone ou WhatsApp">
            <input
              id="resp-telefone"
              type="tel"
              value={telefoneResp}
              onChange={(e) => setTelefoneResp(formatarTelefone(e.target.value))}
              placeholder="(68) 99999-0000"
              className={`${CLASSE_INPUT} tabular-nums`}
              maxLength={20}
            />
          </Campo>
        </div>

        <div className="pt-1 text-xs text-suave">
          Conta Google autenticada para recebimento do comprovante:{' '}
          <strong className="text-tinta">{usuario.email}</strong>
        </div>
      </Secao>

      {/* 2. UNIDADE JUDICIÁRIA / ÓRGÃO AVALIADO */}
      <Secao
        numero="2"
        titulo="Unidade avaliada"
      >
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Campo id="unidade-grau" rotulo="Grau de Jurisdição" obrigatorio>
            <select
              id="unidade-grau"
              value={grau}
              onChange={(e) => selecionarGrau(e.target.value as Grau)}
              className={CLASSE_INPUT}
            >
              <option value="1G">1º Grau de Jurisdição</option>
              <option value="2G">2º Grau (Gabinetes, Vice-Presidência e SEJUD)</option>
            </select>
          </Campo>

          <div className="sm:col-span-2">
            <Campo id="unidade-tipo" rotulo="Tipo de unidade" obrigatorio>
              <select
                id="unidade-tipo"
                value={tipoUnidade}
                onChange={(e) => selecionarTipoUnidade(grau, e.target.value as TipoUnidade)}
                className={CLASSE_INPUT}
              >
                {tiposUnidadeDoGrau.map((t) => (
                  <option key={t.codigo} value={t.codigo}>
                    {t.rotulo} — {t.descricao}
                  </option>
                ))}
              </select>
            </Campo>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <span className="text-xs font-semibold text-tinta">Seleção da Unidade</span>
          <button
            type="button"
            onClick={() => setModoUnidadeManual((v) => !v)}
            className="text-xs text-carmim hover:underline font-medium cursor-pointer"
          >
            {modoUnidadeManual
              ? 'Selecionar da lista oficial de unidades'
              : 'Minha unidade não está na lista (informar manualmente)'}
          </button>
        </div>

        {!modoUnidadeManual && unidadesFiltradas.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <Campo id="unidade-select" rotulo="Unidade" obrigatorio>
                <select
                  id="unidade-select"
                  value={codigoUnidade}
                  onChange={(e) => {
                    const u = unidadesFiltradas.find((x) => x.codigo === e.target.value);
                    if (u) {
                      setCodigoUnidade(u.codigo);
                      setNomeUnidade(u.nome);
                      setComarca(u.comarca);
                    }
                  }}
                  className={CLASSE_INPUT}
                >
                  {unidadesFiltradas.map((u) => (
                    <option key={u.codigo} value={u.codigo}>
                      {u.nome} ({u.comarca})
                    </option>
                  ))}
                </select>
              </Campo>
            </div>

            <Campo id="unidade-comarca-ro" rotulo="Comarca / Sede">
              <input
                id="unidade-comarca-ro"
                type="text"
                value={comarca}
                readOnly
                className={`${CLASSE_INPUT} bg-fundo`}
              />
            </Campo>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <Campo id="unidade-cod-manual" rotulo="Código / Sigla (opcional)">
              <input
                id="unidade-cod-manual"
                type="text"
                value={codigoUnidade}
                onChange={(e) => setCodigoUnidade(e.target.value)}
                placeholder="Ex.: RB-1CIV"
                className={CLASSE_INPUT}
                maxLength={30}
              />
            </Campo>

            <div className="sm:col-span-2">
              <Campo id="unidade-nome-manual" rotulo="Nome da unidade" obrigatorio>
                <input
                  id="unidade-nome-manual"
                  type="text"
                  value={nomeUnidade}
                  onChange={(e) => setNomeUnidade(e.target.value)}
                  placeholder="Ex.: 1ª Vara Cível da Comarca de Rio Branco"
                  className={CLASSE_INPUT}
                  maxLength={200}
                  required
                />
              </Campo>
            </div>

            <Campo id="unidade-comarca-manual" rotulo="Comarca" obrigatorio>
              <input
                id="unidade-comarca-manual"
                type="text"
                list="lista-comarcas-acre"
                value={comarca}
                onChange={(e) => setComarca(e.target.value)}
                placeholder="Rio Branco"
                className={CLASSE_INPUT}
                maxLength={80}
              />
              <datalist id="lista-comarcas-acre">
                {COMARCAS_ACRE.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </Campo>
          </div>
        )}
      </Secao>

      {/* 3. ITENS IMPUGNADOS */}
      <Secao
        numero="3"
        titulo={`Indicadores contestados (${itens.length})`}
        acaoDireita={
          <button
            type="button"
            onClick={adicionarItem}
            disabled={itens.length >= 40}
            className="px-3.5 py-1.5 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
          >
            + Adicionar indicador
          </button>
        }
      >
        {itens.length === 0 ? (
          <div className="bg-fundo border border-linha rounded-lg p-5 text-center space-y-2">
            <p className="text-sm text-suave">
              Nenhum indicador selecionado. Caso o recurso verse apenas sobre a{' '}
              <strong className="text-tinta">Lista de Servidores Vinculados</strong>, preencha a
              Seção 4 abaixo; caso contrário, adicione um indicador.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {itens.map((item, idx) => {
              const infoInd =
                indicadoresDisponiveis.find((d) => d.sigla === item.sigla) ||
                INDICADORES_CATALOGO.find((d) => d.sigla === item.sigla);
              const arqs = arquivosPorItem[item.id] || [];
              const tamTexto = item.fundamentacao.trim().length;
              const todasEvidenciasMarcadas =
                item.evidencias.a &&
                item.evidencias.b &&
                item.evidencias.c &&
                item.evidencias.d &&
                item.evidencias.e;

              return (
                <div
                  key={item.id}
                  className="bg-fundo/70 border border-linha rounded-lg p-4 sm:p-5 space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-linha">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-carmim tabular-nums">
                        Item {idx + 1} de {itens.length}
                      </span>
                      <h3 className="min-w-0 text-base font-bold leading-snug text-tinta [overflow-wrap:anywhere]">
                        {item.sigla} — {item.indicador}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => removerItem(item.id)}
                      className="text-xs text-carmim hover:underline font-medium cursor-pointer"
                      aria-label={`Remover item ${idx + 1} (${item.sigla})`}
                    >
                      Remover este item
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Campo id={`ind-${item.id}`} rotulo="Indicador (Anexo I)" obrigatorio>
                      <select
                        id={`ind-${item.id}`}
                        value={item.sigla}
                        onChange={(e) => selecionarIndicadorItem(item.id, e.target.value)}
                        className={CLASSE_INPUT}
                      >
                        {indicadoresDisponiveis.map((ind) => (
                          <option key={ind.sigla} value={ind.sigla}>
                            {ind.sigla} — {ind.nome} (máx. {ind.pontosMax} pts)
                          </option>
                        ))}
                      </select>
                    </Campo>

                    <Campo id={`sub-${item.id}`} rotulo="Recorte / Subitem / Meta" obrigatorio>
                      {infoInd && infoInd.subitens.length > 0 ? (
                        <select
                          id={`sub-${item.id}`}
                          value={item.subitem}
                          onChange={(e) => atualizarItem(item.id, { subitem: e.target.value })}
                          className={CLASSE_INPUT}
                        >
                          {infoInd.subitens.map((sub) => (
                            <option key={sub} value={sub}>
                              {sub}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          id={`sub-${item.id}`}
                          type="text"
                          value={item.subitem}
                          onChange={(e) => atualizarItem(item.id, { subitem: e.target.value })}
                          placeholder="Apuração Geral"
                          className={CLASSE_INPUT}
                        />
                      )}
                    </Campo>
                  </div>

                  {infoInd && (
                    <div className="bg-white border border-linha rounded-md px-3.5 py-2.5 text-xs text-suave space-y-1">
                      <p>
                        <strong className="text-tinta">Fonte oficial (Anexo III):</strong>{' '}
                        {infoInd.fonte} ·{' '}
                        <strong className="text-tinta">Pontuação máxima:</strong>{' '}
                        <span className="tabular-nums">{infoInd.pontosMax} pontos</span>
                      </p>
                      <p>
                        <strong className="text-tinta">Faixas de avaliação (Anexo IV):</strong>{' '}
                        {infoInd.faixasResumo}
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <Campo id={`tipo-imp-${item.id}`} rotulo="Motivo do recurso" obrigatorio>
                      <select
                        id={`tipo-imp-${item.id}`}
                        value={item.tipoImpugnacao}
                        onChange={(e) =>
                          atualizarItem(item.id, {
                            tipoImpugnacao: e.target.value as TipoImpugnacao,
                          })
                        }
                        className={CLASSE_INPUT}
                      >
                        {TIPOS_IMPUGNACAO_INFO.map((ti) => (
                          <option key={ti.codigo} value={ti.codigo}>
                            {ti.rotulo}
                          </option>
                        ))}
                      </select>
                    </Campo>

                    <Campo
                      id={`pts-pre-${item.id}`}
                      rotulo="Pontuação preliminar"
                      ajuda={infoInd ? `Máximo: ${infoInd.pontosMax} pontos` : undefined}
                      erro={erroPontuacao(item.pontuacaoPreliminar, infoInd?.pontosMax)}
                    >
                      <input
                        id={`pts-pre-${item.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        max={infoInd?.pontosMax}
                        value={item.pontuacaoPreliminar}
                        onChange={(e) =>
                          atualizarItem(item.id, { pontuacaoPreliminar: e.target.value })
                        }
                        placeholder="Ex.: 0"
                        className={`${CLASSE_INPUT} tabular-nums`}
                      />
                    </Campo>

                    <Campo
                      id={`pts-ple-${item.id}`}
                      erro={erroPontuacao(item.pontuacaoPleiteada, infoInd?.pontosMax)}
                      rotulo="Pontuação solicitada"
                      ajuda={
                        item.tipoImpugnacao === 'APLICABILIDADE'
                          ? 'Deixe vazio se pleiteia exclusão da base'
                          : `Máximo do indicador: ${infoInd?.pontosMax} pts`
                      }
                    >
                      <input
                        id={`pts-ple-${item.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        max={infoInd?.pontosMax}
                        value={item.pontuacaoPleiteada}
                        onChange={(e) =>
                          atualizarItem(item.id, { pontuacaoPleiteada: e.target.value })
                        }
                        placeholder={
                          item.tipoImpugnacao === 'APLICABILIDADE'
                            ? 'Exclusão (N/A)'
                            : String(infoInd?.pontosMax ?? '')
                        }
                        className={`${CLASSE_INPUT} tabular-nums`}
                      />
                    </Campo>
                  </div>

                  {/* Fundamentação */}
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label
                        htmlFor={`fund-${item.id}`}
                        className="text-xs sm:text-sm font-semibold text-tinta"
                      >
                        Fundamentação
                        <span className="text-carmim ml-1">*</span>
                      </label>
                      <span
                        className={`text-xs tabular-nums ${
                          tamTexto < config.limites.minTexto
                            ? 'text-carmim font-medium'
                            : 'text-suave'
                        }`}
                      >
                        {tamTexto} / {config.limites.maxTexto} caracteres (mín.{' '}
                        {config.limites.minTexto})
                      </span>
                    </div>
                    <p id={`fund-ajuda-${item.id}`} className="max-w-prose text-sm text-suave">
                      Indique a divergência, a fonte, os filtros, o período (01/01/2026 a 30/11/2026),
                      o cálculo (numerador e denominador) e os números CNJ dos processos.
                    </p>
                    <textarea
                      id={`fund-${item.id}`}
                      aria-describedby={`fund-ajuda-${item.id}`}
                      rows={4}
                      value={item.fundamentacao}
                      onChange={(e) => atualizarItem(item.id, { fundamentacao: e.target.value })}
                      maxLength={config.limites.maxTexto}
                      className={CLASSE_INPUT}
                      required
                    />
                  </div>

                  {/* Checklist obrigatório Anexo III, item 3 */}
                  <div className="bg-white border border-linha rounded-md p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h4 className="text-base font-bold leading-snug text-tinta">
                          Evidências obrigatórias
                        </h4>
                        <p className="text-xs text-suave">
                          O recurso que não apresentar todas as 5 evidências abaixo não será
                          conhecido pela Comissão Revisora:
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          atualizarItem(item.id, {
                            evidencias: todasEvidenciasMarcadas
                              ? { a: false, b: false, c: false, d: false, e: false }
                              : { a: true, b: true, c: true, d: true, e: true },
                          })
                        }
                        className="text-xs font-semibold text-carmim hover:underline cursor-pointer"
                      >
                        {todasEvidenciasMarcadas
                          ? 'Desmarcar confirmações'
                          : 'Confirmar todos os 5 requisitos'}
                      </button>
                    </div>

                    <div className="space-y-2">
                      {EVIDENCIAS_OBRIGATORIAS.map((ev) => {
                        const marcado = item.evidencias[ev.chave];
                        return (
                          <label
                            key={ev.chave}
                            className="flex items-start gap-2.5 text-xs sm:text-sm cursor-pointer select-none"
                          >
                            <input
                              type="checkbox"
                              checked={marcado}
                              onChange={(e) =>
                                atualizarItem(item.id, {
                                  evidencias: {
                                    ...item.evidencias,
                                    [ev.chave]: e.target.checked,
                                  },
                                })
                              }
                              className="mt-0.5 h-4 w-4 rounded border-linha text-carmim focus:ring-carmim"
                            />
                            <span>
                              <strong className="text-tinta">
                                {ev.alínea} {ev.titulo}:
                              </strong>{' '}
                              <span className="text-suave">{ev.detalhe}</span>
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Upload de arquivos comprobatórios */}
                  <div className="bg-white border border-linha rounded-md p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h4 className="text-base font-bold leading-snug text-tinta">
                          Arquivos de Evidência deste Item ({arqs.length} /{' '}
                          {config.limites.maxArqPorItem}) <span className="text-carmim">*</span>
                        </h4>
                        <p className="text-xs text-suave">
                          Formatos aceitos: PDF, PNG, JPG, XLSX, XLS, CSV ou DOCX (máx. 10 MB por
                          arquivo).
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {MODO_DEMO && (
                          <button
                            type="button"
                            onClick={() =>
                              adicionarArquivos(item.id, [
                                criarPdfExemplo(item.sigla, nomeUnidade || 'Unidade_TJAC'),
                              ])
                            }
                            className="px-3 py-1.5 rounded border border-linha bg-fundo hover:bg-linha/50 text-xs font-medium text-tinta cursor-pointer"
                          >
                            + Gerar PDF de exemplo
                          </button>
                        )}
                        <label
                          htmlFor={`file-${item.id}`}
                          className="px-3 py-1.5 rounded bg-tinta hover:bg-tinta/90 text-white text-xs font-semibold cursor-pointer"
                        >
                          Selecionar arquivo(s)
                        </label>
                        <input
                          id={`file-${item.id}`}
                          type="file"
                          multiple
                          accept=".pdf,.png,.jpg,.jpeg,.xlsx,.xls,.csv,.docx"
                          onChange={(e) => {
                            adicionarArquivos(item.id, e.target.files);
                            e.target.value = '';
                          }}
                          className="sr-only"
                        />
                      </div>
                    </div>

                    {arqs.length === 0 ? (
                      <p className="text-xs text-carmim">
                        Nenhum arquivo anexado para o item {item.sigla}. Anexe ao menos 1 arquivo
                        comprobatório.
                      </p>
                    ) : (
                      <ul className="divide-y divide-linha border border-linha rounded-md">
                        {arqs.map((arq, iArq) => (
                          <li
                            key={`${arq.name}-${iArq}`}
                            className="px-3 py-2 flex items-center justify-between gap-3 text-xs"
                          >
                            <div className="min-w-0">
                              <p className="font-semibold text-tinta truncate">{arq.name}</p>
                              <p className="text-suave tabular-nums">
                                {formatarBytes(arq.size)} · {arq.type || 'documento'}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => removerArquivo(item.id, iArq)}
                              className="text-carmim hover:underline font-medium shrink-0 cursor-pointer"
                              aria-label={`Remover arquivo ${arq.name}`}
                            >
                              Remover
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Secao>

      {/* 4. IMPUGNAÇÃO DA LISTA DE SERVIDORES VINCULADOS */}
      <Secao
        numero="4"
        titulo="Lista de servidores vinculados"
      >
        <label className="flex items-start gap-2.5 text-sm cursor-pointer select-none">
          <input
            type="checkbox"
            checked={impugnaLista}
            onChange={(e) => setImpugnaLista(e.target.checked)}
            className="mt-0.5 h-4 w-4 rounded border-linha text-carmim focus:ring-carmim"
          />
          <span className="font-semibold text-tinta">
            Contestar a lista preliminar de servidores vinculados
          </span>
        </label>

        {impugnaLista && (
          <div className="space-y-1.5 pt-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label
                htmlFor="impugna-lista-texto"
                className="text-xs sm:text-sm font-semibold text-tinta"
              >
                Fundamentação sobre a lista
                <span className="text-carmim ml-1">*</span>
              </label>
              <span className="text-xs text-suave tabular-nums">
                {textoLista.trim().length} / {config.limites.maxTexto} caracteres (mín.{' '}
                {config.limites.minTexto})
              </span>
            </div>
            <p id="impugna-lista-ajuda" className="max-w-prose text-sm text-suave">
              Informe nome, matrícula, período de lotação (mínimo de seis meses antes de
              30/11/2026) e número do registro oficial (art. 6º).
            </p>
            <textarea
              id="impugna-lista-texto"
              aria-describedby="impugna-lista-ajuda"
              rows={4}
              value={textoLista}
              onChange={(e) => setTextoLista(e.target.value)}
              maxLength={config.limites.maxTexto}
              className={CLASSE_INPUT}
            />
          </div>
        )}
      </Secao>

      {/* 5. DECLARAÇÃO DE VERACIDADE E SUBMISSÃO */}
      <Secao
        numero="5"
        titulo="Declaração e envio"
      >
        <label className="flex items-start gap-3 text-xs sm:text-sm cursor-pointer select-none bg-fundo border border-linha rounded-md p-4 leading-relaxed">
          <input
            type="checkbox"
            checked={declaracao}
            onChange={(e) => setDeclaracao(e.target.checked)}
            className="mt-1 h-4 w-4 rounded border-linha text-carmim focus:ring-carmim shrink-0"
          />
          <span className="text-tinta">
            Declaro, para os devidos fins, que as informações prestadas e os documentos anexados
            são fidedignos e refletem os registros oficiais até a data de corte de{' '}
            <strong>30 de novembro de 2026 (23h59min59s)</strong>, estando ciente de que a ausência
            das evidências obrigatórias do Anexo III, item 3, implica o{' '}
            <strong>não conhecimento</strong> do recurso (art. 13, <em>caput</em>) e de que a
            análise poderá ensejar acréscimo ou decréscimo da pontuação preliminarmente conferida
            (art. 13, § 2º, da Portaria PRESI/TJAC nº 1961/2026).
          </span>
        </label>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <div className="text-xs text-suave">
            {enviando ? (
              <span className="text-carmim font-semibold">{etapaEnvio}</span>
            ) : (
              <span>
                Ao enviar, será gerado o protocolo único <code className="text-tinta">RTQ-2026-XXXXX</code>{' '}
                para impressão e arquivamento.
              </span>
            )}
          </div>

          <button
            type="submit"
            disabled={enviando || !config.prazo.aberto}
            className="px-6 py-3 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-50"
          >
            {enviando ? 'Transmitindo recurso…' : 'Protocolar Recurso no TJAC'}
          </button>
        </div>
      </Secao>
    </form>
  );
}
