import React, { useEffect, useRef, useState } from 'react';
import { API_URL, GOOGLE_CLIENT_ID, MODO_DEMO } from '../config';
import { criarTokenDemo } from '../services/auth';
import { LogoTJAC } from './LogoTJAC';
import { Aviso } from './ui';

interface PaginaInicialProps {
  perfil: 'unidade' | 'admin' | null;
  onEscolher: (perfil: 'unidade' | 'admin' | null) => void;
  onToken: (token: string, perfil: 'unidade' | 'admin') => void;
  mensagem: string;
  onInstrucoes: () => void;
}

export function PaginaInicial({ perfil, onEscolher, onToken, mensagem, onInstrucoes }: PaginaInicialProps) {
  const botao = useRef<HTMLDivElement>(null);
  const [falhaGoogle, setFalhaGoogle] = useState(false);
  const configurado = !MODO_DEMO && Boolean(GOOGLE_CLIENT_ID && API_URL);

  useEffect(() => {
    if (!perfil || !configurado || !botao.current) return;
    const elemento = botao.current;
    let tentativas = 0;
    let timer: ReturnType<typeof setTimeout>;
    function carregar() {
      const google = window.google?.accounts?.id;
      if (!google) {
        if (++tentativas < 25) timer = setTimeout(carregar, 200);
        else setFalhaGoogle(true);
        return;
      }
      try {
        google.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: ({ credential }) => { if (credential && perfil) onToken(credential, perfil); },
        });
        google.renderButton(elemento, {
          theme: 'outline',
          size: 'large',
          text: 'signin_with',
          shape: 'rectangular',
          width: 250,
          locale: 'pt-BR',
        });
      } catch {
        setFalhaGoogle(true);
      }
    }
    carregar();
    return () => { clearTimeout(timer); elemento.replaceChildren(); };
  }, [configurado, onToken, perfil]);

  return (
    <main className="min-h-screen grid bg-white text-tinta md:grid-cols-[3fr_2fr]">
      <section className="flex flex-col gap-8 bg-carmimEscuro px-6 pb-10 pt-8 text-white sm:px-12 md:px-[10%]">
        <LogoTJAC variante="branco" mostrarSubtituloPortal={false} className="h-10 w-auto sm:h-14" />
        <div className="flex max-w-xl flex-1 flex-col justify-center">
          <h1 className="text-balance text-3xl font-bold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
            Formulário e Gestão de Recursos ao Resultado Preliminar
          </h1>
          <p className="mt-4 max-w-md text-base leading-relaxed text-white/90 sm:text-lg">
            Envie e acompanhe seu recurso ao resultado preliminar.
          </p>
        </div>
      </section>
      <section className="flex flex-col justify-center px-6 py-10 sm:px-12 md:px-[12%]" aria-labelledby="titulo-acesso">
        <div className="mx-auto w-full max-w-sm">
          <h2 id="titulo-acesso" className="text-2xl font-bold tracking-tight">{perfil === 'admin' ? 'Entrar na administração' : perfil === 'unidade' ? 'Entrar como Unidade Judiciária' : 'Acessar o portal'}</h2>
          <p className="mt-2 text-sm leading-relaxed text-suave">
            {perfil === 'admin' ? 'Use uma conta Google autorizada para administração.' :
              perfil === 'unidade' ? <>Use sua conta institucional <strong>@tjac.jus.br</strong>.</> :
              'Escolha a área que deseja acessar.'}
          </p>
          <div className="mt-6 space-y-3">
            {mensagem && <Aviso tipo="erro">{mensagem}</Aviso>}
            {!perfil ? (
              <div className="grid gap-3">
                <button type="button" onClick={() => onEscolher('unidade')} className="min-h-[52px] rounded-md border border-carmim bg-carmim px-4 text-left text-sm font-semibold text-white hover:bg-carmimEscuro focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-carmim">Unidade Judiciária</button>
                <button type="button" onClick={() => onEscolher('admin')} className="min-h-[52px] rounded-md border border-linha bg-white px-4 text-left text-sm font-semibold text-carmim hover:bg-fundo focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-carmim">Administração</button>
              </div>
            ) : MODO_DEMO ? (
              <>
                <p className="text-sm text-suave">Google desativado na demonstração. Use apenas dados fictícios.</p>
                <button type="button" onClick={() => onToken(criarTokenDemo(perfil === 'admin' ? {
                  nome: 'Administrador de demonstração', email: 'josue.silva@tjac.jus.br',
                } : undefined), perfil)} className="block min-h-[44px] rounded-md bg-carmim px-4 text-sm font-semibold text-white">
                  Entrar na demonstração
                </button>
              </>
            ) : configurado ? (
              <>
                <div ref={botao} className="min-h-[40px]" />
                {falhaGoogle && <Aviso tipo="erro">Não foi possível carregar o Google. Recarregue a página para tentar novamente.</Aviso>}
              </>
            ) : (
              <>
                <p className="text-sm text-suave">O login Google ainda precisa ser configurado neste ambiente.</p>
              </>
            )}
          </div>
          {perfil && (
            <button type="button" onClick={() => onEscolher(null)} className="mt-4 block min-h-[44px] text-sm font-semibold text-carmim hover:underline">
              Voltar à escolha de acesso
            </button>
          )}
          <button type="button" onClick={onInstrucoes} className="mt-5 min-h-[44px] text-sm font-semibold text-carmim underline-offset-4 hover:underline">
            Ver instruções e regras do recurso
          </button>
        </div>
      </section>
    </main>
  );
}
