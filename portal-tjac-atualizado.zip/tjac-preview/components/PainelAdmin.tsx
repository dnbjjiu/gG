import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { TIPOS_IMPUGNACAO_INFO, TIPOS_UNIDADE_INFO } from '../catalogo';
import {
  PASTA_PROTOCOLO_DRIVE_URL,
  PASTA_RAIZ_DRIVE_URL,
  PROTOCOLO_FOLDER_ID,
  ROOT_FOLDER_ID,
} from '../config';
import {
  ApiError,
  api,
  obterPlanilhaMestraUrl,
  salvarPlanilhaMestraUrl,
} from '../services/api';
import type {
  AtualizarItemAdminPayload,
  DadosAdminResposta,
  ItemRecursoAdmin,
  RecursoAdmin,
  StatusAnalise,
  Usuario,
} from '../types';
import { ROTULO_ESTADO_TRAMITACAO } from '../services/analiseLogica';
import {
  DRIVE_ROOT_FOLDER_ID,
  construirArvoreEvidenciasDeRecursos,
} from '../src/services/drive';
import { formatarBytes, formatarCpf, formatarDataHora } from '../utils';
import { IntegracaoWorkspace } from './IntegracaoWorkspace';
import { Aviso, CLASSE_INPUT, SeloStatus } from './ui';

interface PainelAdminProps {
  idToken: string;
  usuario: Usuario;
  onAbrirAnalise?: (protocolo: string) => void;
}

type SubVisao = 'protocolos' | 'indicadores' | 'drive' | 'workspace';

const OPCOES_STATUS_ANALISE: { valor: StatusAnalise; rotulo: string }[] = [
  { valor: 'PENDENTE', rotulo: 'Pendente de análise' },
  { valor: 'EM_ANALISE', rotulo: 'Em análise pela Comissão' },
  { valor: 'PROVIDO', rotulo: 'Provido (Deferido)' },
  { valor: 'PARCIALMENTE_PROVIDO', rotulo: 'Parcialmente provido' },
  { valor: 'IMPROVIDO', rotulo: 'Improvido (Indeferido)' },
  { valor: 'NAO_CONHECIDO', rotulo: 'Não conhecido (Art. 13)' },
];

export function PainelAdmin({ idToken, usuario, onAbrirAnalise }: PainelAdminProps) {
  const [dados, setDados] = useState<DadosAdminResposta | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [subVisao, setSubVisao] = useState<SubVisao>('protocolos');

  // Filtros
  const [busca, setBusca] = useState('');
  const [filtroGrau, setFiltroGrau] = useState<string>('TODOS');
  const [filtroTipoUnidade, setFiltroTipoUnidade] = useState<string>('TODOS');
  const [filtroIndicador, setFiltroIndicador] = useState<string>('TODOS');
  const [filtroStatusAnalise, setFiltroStatusAnalise] = useState<string>('TODOS');

  // Expansão de protocolos
  const [abertos, setAbertos] = useState<Record<string, boolean>>({});

  // Edição inline de parecer/decisão de item
  const [itemEditando, setItemEditando] = useState<string | null>(null); // `${protocolo}:${itemN}`
  const [formAnalise, setFormAnalise] = useState<{
    statusAnalise: StatusAnalise;
    relator: string;
    pontuacaoFinal: string;
    decisao: string;
    parecer: string;
  }>({
    statusAnalise: 'EM_ANALISE',
    relator: '',
    pontuacaoFinal: '',
    decisao: '',
    parecer: '',
  });
  const [salvandoAnalise, setSalvandoAnalise] = useState(false);
  const [msgSucesso, setMsgSucesso] = useState('');

  // Configuração da Planilha Mestra (Google Sheets)
  const [planilhaMestraUrl, setPlanilhaMestraUrl] = useState<string>(() =>
    obterPlanilhaMestraUrl()
  );
  const [editandoPlanilhaUrl, setEditandoPlanilhaUrl] = useState(false);
  const [inputPlanilhaUrl, setInputPlanilhaUrl] = useState('');

  const carregar = useCallback(() => {
    setCarregando(true);
    setErro('');
    api
      .adminList(idToken)
      .then((res) => {
        setDados(res);
        if (res.planilhaUrl) {
          setPlanilhaMestraUrl(res.planilhaUrl);
        }
        if (res.recursos.length > 0) {
          setAbertos((prev) =>
            Object.keys(prev).length > 0 ? prev : { [res.recursos[0].protocolo]: true }
          );
        }
      })
      .catch((e) => {
        setErro(
          e instanceof ApiError || e instanceof Error
            ? e.message
            : 'Falha ao carregar os dados consolidados dos recursos.'
        );
      })
      .finally(() => setCarregando(false));
  }, [idToken]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  const recursos = dados?.recursos || [];

  // Indicadores únicos presentes nos recursos cadastrados
  const indicadoresPresentes = useMemo(() => {
    const mapa = new Map<string, string>();
    for (const r of recursos) {
      for (const it of r.itens) {
        if (!mapa.has(it.sigla)) mapa.set(it.sigla, it.indicador);
      }
    }
    return Array.from(mapa.entries()).map(([sigla, indicador]) => ({ sigla, indicador }));
  }, [recursos]);

  // Estatísticas consolidadas
  const kpis = useMemo(() => {
    let totalItens = 0;
    let totalArquivos = 0;
    let totalBytes = 0;
    let pendentesOuAnalise = 0;
    let providosOuParciais = 0;
    let improvidosOuNaoConhecidos = 0;
    let impugnacoesServidores = 0;

    for (const r of recursos) {
      if (r.impugnaListaServidores) impugnacoesServidores += 1;
      for (const it of r.itens) {
        totalItens += 1;
        totalArquivos += it.arquivos.length;
        for (const a of it.arquivos) totalBytes += a.bytes || 0;
        if (it.statusAnalise === 'PENDENTE' || it.statusAnalise === 'EM_ANALISE') {
          pendentesOuAnalise += 1;
        } else if (
          it.statusAnalise === 'PROVIDO' ||
          it.statusAnalise === 'PARCIALMENTE_PROVIDO'
        ) {
          providosOuParciais += 1;
        } else {
          improvidosOuNaoConhecidos += 1;
        }
      }
    }

    return {
      totalProtocolos: recursos.length,
      totalItens,
      totalArquivos,
      totalBytes,
      pendentesOuAnalise,
      providosOuParciais,
      improvidosOuNaoConhecidos,
      impugnacoesServidores,
    };
  }, [recursos]);

  // Recursos filtrados
  const recursosFiltrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    return recursos.filter((r) => {
      if (filtroGrau !== 'TODOS' && r.unidade.grau !== filtroGrau) return false;
      if (filtroTipoUnidade !== 'TODOS' && r.unidade.tipo !== filtroTipoUnidade) return false;
      if (
        filtroIndicador !== 'TODOS' &&
        !r.itens.some((it) => it.sigla === filtroIndicador)
      ) {
        return false;
      }
      if (
        filtroStatusAnalise !== 'TODOS' &&
        !r.itens.some((it) => it.statusAnalise === filtroStatusAnalise)
      ) {
        return false;
      }
      if (!q) return true;
      const textoBase = [
        r.protocolo,
        r.unidade.nome,
        r.unidade.codigo,
        r.unidade.comarca,
        r.responsavel.nome,
        r.emailGoogle,
        r.responsavel.cpf,
        r.impugnacaoListaTexto,
        ...r.itens.flatMap((it) => [
          it.sigla,
          it.indicador,
          it.subitem,
          it.fundamentacao,
          it.relator,
          it.decisao,
          ...it.arquivos.map((a) => a.nome),
        ]),
      ]
        .join(' ')
        .toLowerCase();
      return textoBase.includes(q);
    });
  }, [recursos, busca, filtroGrau, filtroTipoUnidade, filtroIndicador, filtroStatusAnalise]);

  // Agrupamento por Indicador para a aba "Por Indicador"
  const agrupadoPorIndicador = useMemo(() => {
    const mapa = new Map<
      string,
      {
        sigla: string;
        indicador: string;
        grupo: string;
        ocorrencias: { recurso: RecursoAdmin; item: ItemRecursoAdmin }[];
      }
    >();
    for (const r of recursosFiltrados) {
      for (const it of r.itens) {
        if (filtroIndicador !== 'TODOS' && it.sigla !== filtroIndicador) continue;
        if (filtroStatusAnalise !== 'TODOS' && it.statusAnalise !== filtroStatusAnalise) continue;
        const atual = mapa.get(it.sigla) || {
          sigla: it.sigla,
          indicador: it.indicador,
          grupo: it.grupo,
          ocorrencias: [],
        };
        atual.ocorrencias.push({ recurso: r, item: it });
        mapa.set(it.sigla, atual);
      }
    }
    return Array.from(mapa.values()).sort(
      (a, b) => b.ocorrencias.length - a.ocorrencias.length
    );
  }, [recursosFiltrados, filtroIndicador, filtroStatusAnalise]);

  // Árvore organizada de pastas e evidências na Pasta Raiz (1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv)
  const arvoreDriveOrganizada = useMemo(
    () => construirArvoreEvidenciasDeRecursos(recursosFiltrados, DRIVE_ROOT_FOLDER_ID),
    [recursosFiltrados]
  );

  const abrirEdicaoItem = (it: ItemRecursoAdmin) => {
    const chave = `${it.protocolo}:${it.itemN}`;
    setItemEditando(chave);
    setFormAnalise({
      statusAnalise: it.statusAnalise || 'EM_ANALISE',
      relator: it.relator || `${usuario.nome} (${usuario.email})`,
      pontuacaoFinal: it.pontuacaoFinal === '' ? '' : String(it.pontuacaoFinal),
      decisao: it.decisao || '',
      parecer: it.parecer || '',
    });
    setMsgSucesso('');
  };

  const salvarAnaliseItem = async (protocolo: string, itemN: number) => {
    setSalvandoAnalise(true);
    setErro('');
    setMsgSucesso('');
    try {
      const payload: AtualizarItemAdminPayload = {
        protocolo,
        itemN,
        statusAnalise: formAnalise.statusAnalise,
        relator: formAnalise.relator.trim(),
        parecer: formAnalise.parecer.trim(),
        decisao: formAnalise.decisao.trim(),
        pontuacaoFinal:
          formAnalise.pontuacaoFinal.trim() === ''
            ? ''
            : Number(formAnalise.pontuacaoFinal.replace(',', '.')),
      };
      await api.adminUpdateItem(idToken, payload);
      setItemEditando(null);
      setMsgSucesso(`Decisão e parecer do item #${itemN} (${protocolo}) salvos com sucesso.`);
      carregar();
    } catch (e) {
      setErro(
        e instanceof ApiError || e instanceof Error
          ? e.message
          : 'Erro ao salvar parecer/decisão do item.'
      );
    } finally {
      setSalvandoAnalise(false);
    }
  };

  const exportarCsvConsolidado = () => {
    const cabecalho = [
      'PROTOCOLO',
      'STATUS_PROTOCOLO',
      'ENVIADO_EM',
      'GRAU',
      'TIPO_UNIDADE',
      'COD_UNIDADE',
      'UNIDADE',
      'COMARCA',
      'RESPONSAVEL_NOME',
      'RESPONSAVEL_CPF',
      'RESPONSAVEL_CARGO',
      'EMAIL_GOOGLE',
      'TELEFONE',
      'PASTA_DRIVE_PROTOCOLO',
      'IMPUGNA_LISTA_SERVIDORES',
      'ITEM_N',
      'SIGLA_INDICADOR',
      'NOME_INDICADOR',
      'SUBITEM',
      'NATUREZA_IMPUGNACAO',
      'PONTUACAO_PRELIMINAR',
      'PONTUACAO_PLEITEADA',
      'STATUS_ANALISE',
      'PONTUACAO_FINAL',
      'RELATOR',
      'DECISAO_RESUMO',
      'PASTA_DRIVE_ITEM',
      'QTD_ARQUIVOS_EVIDENCIA',
      'LINKS_ARQUIVOS_DRIVE',
      'FUNDAMENTACAO',
    ];

    const escCsv = (val: unknown) => {
      const s = String(val ?? '').replace(/\r?\n/g, ' ');
      return `"${s.replace(/"/g, '""')}"`;
    };

    const linhas: string[] = [cabecalho.map(escCsv).join(';')];

    for (const r of recursosFiltrados) {
      if (r.itens.length === 0) {
        linhas.push(
          [
            r.protocolo,
            r.status,
            r.enviadoEm,
            r.unidade.grau,
            r.unidade.tipo,
            r.unidade.codigo,
            r.unidade.nome,
            r.unidade.comarca,
            r.responsavel.nome,
            formatarCpf(r.responsavel.cpf),
            r.responsavel.cargo,
            r.emailGoogle,
            r.responsavel.telefone,
            r.pastaUrl,
            r.impugnaListaServidores ? 'SIM' : 'NAO',
            '',
            'LISTA_SERVIDORES',
            'Impugnação da Lista de Servidores Vinculados',
            '',
            '',
            '',
            '',
            'PENDENTE',
            '',
            '',
            '',
            r.pastaUrl,
            0,
            '',
            r.impugnacaoListaTexto,
          ]
            .map(escCsv)
            .join(';')
        );
      } else {
        for (const it of r.itens) {
          linhas.push(
            [
              r.protocolo,
              r.status,
              r.enviadoEm,
              r.unidade.grau,
              r.unidade.tipo,
              r.unidade.codigo,
              r.unidade.nome,
              r.unidade.comarca,
              r.responsavel.nome,
              formatarCpf(r.responsavel.cpf),
              r.responsavel.cargo,
              r.emailGoogle,
              r.responsavel.telefone,
              r.pastaUrl,
              r.impugnaListaServidores ? 'SIM' : 'NAO',
              it.itemN,
              it.sigla,
              it.indicador,
              it.subitem,
              it.tipoImpugnacao,
              it.pontuacaoPreliminar,
              it.pontuacaoPleiteada,
              it.statusAnalise,
              it.pontuacaoFinal,
              it.relator,
              it.decisao,
              it.pastaItemUrl,
              it.arquivos.length,
              it.arquivos.map((a) => `${a.nome}: ${a.url}`).join(' | '),
              it.fundamentacao,
            ]
              .map(escCsv)
              .join(';')
          );
        }
      }
    }

    const blob = new Blob(['\uFEFF' + linhas.join('\r\n')], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recursos-premio-tjac-2026-consolidado.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const expandirOuRecolherTodos = (expandir: boolean) => {
    const novo: Record<string, boolean> = {};
    if (expandir) {
      for (const r of recursosFiltrados) novo[r.protocolo] = true;
    }
    setAbertos(novo);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho Institucional do Modo Administrador */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-linha pb-4">
          <h2 className="text-lg font-bold text-tinta">Recursos recebidos</h2>
          <div className="flex flex-wrap items-center gap-2">
            {planilhaMestraUrl ? (
              <div className="inline-flex items-center gap-1">
                <a
                  href={planilhaMestraUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-linha bg-fundo hover:bg-linha/50 text-tinta text-xs font-semibold transition-colors"
                >
                  <svg className="w-4 h-4 text-verde" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" />
                    <path d="M3 9h18M9 21V9" />
                  </svg>
                  Planilha Mestra (Sheets)
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setInputPlanilhaUrl(planilhaMestraUrl);
                    setEditandoPlanilhaUrl((v) => !v);
                  }}
                  className="px-2 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-suave hover:text-tinta text-xs font-semibold cursor-pointer"
                  title="Alterar URL da Planilha Mestra"
                >
                  ✎
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setInputPlanilhaUrl('');
                  setEditandoPlanilhaUrl((v) => !v);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-ouro bg-ouro/10 hover:bg-ouro/20 text-tinta text-xs font-semibold transition-colors cursor-pointer"
              >
                <svg className="w-4 h-4 text-verde" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <path d="M3 9h18M9 21V9" />
                </svg>
                Vincular / Criar Planilha Mestra (Sheets)
              </button>
            )}
            <button
              type="button"
              onClick={exportarCsvConsolidado}
              disabled={recursosFiltrados.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-tinta text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              <svg className="w-4 h-4 text-carmim" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />
              </svg>
              Exportar CSV Consolidado
            </button>
            <button
              type="button"
              onClick={carregar}
              className="px-3 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-tinta cursor-pointer"
            >
              Atualizar
            </button>
          </div>
        </div>

        {/* Barra de vínculos rápidos: Pasta Raiz, Pasta do Protocolo e Planilha Mestra */}
        {editandoPlanilhaUrl && (
          <div className="bg-fundo border border-linha rounded-md p-3.5 flex flex-wrap items-end gap-3">
            <div className="flex-1 min-w-[260px]">
              <label className="block text-[11px] font-bold uppercase text-suave mb-1">
                URL ou ID da Planilha Mestra no Google Sheets (deixe em branco ou gere automaticamente na aba 4)
              </label>
              <input
                type="url"
                value={inputPlanilhaUrl}
                onChange={(e) => setInputPlanilhaUrl(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/.../edit"
                className={CLASSE_INPUT}
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const val = inputPlanilhaUrl.trim();
                  const normalizada =
                    val && !val.startsWith('http')
                      ? `https://docs.google.com/spreadsheets/d/${val}/edit`
                      : val;
                  salvarPlanilhaMestraUrl(normalizada);
                  setPlanilhaMestraUrl(normalizada);
                  setEditandoPlanilhaUrl(false);
                  setMsgSucesso(
                    normalizada
                      ? 'URL da Planilha Mestra vinculada com sucesso.'
                      : 'Vínculo da Planilha Mestra removido.'
                  );
                }}
                className="px-3.5 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer"
              >
                Salvar Planilha Mestra
              </button>
              <button
                type="button"
                onClick={() => {
                  setEditandoPlanilhaUrl(false);
                  setSubVisao('workspace');
                }}
                className="px-3.5 py-2 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold cursor-pointer"
              >
                Gerar Nova Planilha Mestra via Google Sheets API →
              </button>
              <button
                type="button"
                onClick={() => setEditandoPlanilhaUrl(false)}
                className="px-3 py-2 rounded-md border border-linha bg-white text-xs font-semibold text-suave hover:text-tinta cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        )}

        {/* Cartões de Resumo (KPIs) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-fundo/70 border border-linha rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-suave font-semibold">Protocolos</p>
            <p className="text-xl font-bold text-tinta tabular-nums mt-0.5">{kpis.totalProtocolos}</p>
            <p className="text-[11px] text-suave">Unidades recorrentes</p>
          </div>
          <div className="bg-fundo/70 border border-linha rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-suave font-semibold">Itens Impugnados</p>
            <p className="text-xl font-bold text-carmim tabular-nums mt-0.5">{kpis.totalItens}</p>
            <p className="text-[11px] text-suave">Indicadores/subitens</p>
          </div>
          <div className="bg-fundo/70 border border-linha rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-suave font-semibold">Evidências Drive</p>
            <p className="text-xl font-bold text-tinta tabular-nums mt-0.5">{kpis.totalArquivos}</p>
            <p className="text-[11px] text-suave tabular-nums">{formatarBytes(kpis.totalBytes)} anexados</p>
          </div>
          <div className="bg-amber-50/70 border border-amber-200 rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-amber-900 font-semibold">Pendentes / Análise</p>
            <p className="text-xl font-bold text-amber-900 tabular-nums mt-0.5">{kpis.pendentesOuAnalise}</p>
            <p className="text-[11px] text-amber-800">Aguardando decisão</p>
          </div>
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-emerald-900 font-semibold">Providos / Parciais</p>
            <p className="text-xl font-bold text-emerald-800 tabular-nums mt-0.5">{kpis.providosOuParciais}</p>
            <p className="text-[11px] text-emerald-800">Com ajuste de pontos</p>
          </div>
          <div className="bg-fundo/70 border border-linha rounded-md p-3">
            <p className="text-[11px] uppercase tracking-wider text-suave font-semibold">Lista de Servidores</p>
            <p className="text-xl font-bold text-tinta tabular-nums mt-0.5">{kpis.impugnacoesServidores}</p>
            <p className="text-[11px] text-suave">Art. 5º, III, &ldquo;b&rdquo;</p>
          </div>
        </div>

        {/* Sub-navegação de visões organizadas */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="inline-flex flex-wrap bg-fundo border border-linha rounded-lg p-1 text-xs sm:text-sm">
            <button
              type="button"
              onClick={() => setSubVisao('protocolos')}
              className={`px-3.5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                subVisao === 'protocolos'
                  ? 'bg-carmim text-white'
                  : 'text-suave hover:text-tinta'
              }`}
            >
              1. Recursos por Protocolo ({recursosFiltrados.length})
            </button>
            <button
              type="button"
              onClick={() => setSubVisao('indicadores')}
              className={`px-3.5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                subVisao === 'indicadores'
                  ? 'bg-carmim text-white'
                  : 'text-suave hover:text-tinta'
              }`}
            >
              2. Agrupado por Indicador ({agrupadoPorIndicador.length})
            </button>
            <button
              type="button"
              onClick={() => setSubVisao('drive')}
              className={`px-3.5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                subVisao === 'drive'
                  ? 'bg-carmim text-white'
                  : 'text-suave hover:text-tinta'
              }`}
            >
              3. Evidências no Google Drive ({kpis.totalArquivos})
            </button>
            <button
              type="button"
              onClick={() => setSubVisao('workspace')}
              className={`px-3.5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                subVisao === 'workspace'
                  ? 'bg-carmim text-white'
                  : 'text-suave hover:text-tinta'
              }`}
            >
              4. Sincronização Workspace (Drive, Sheets e Forms)
            </button>
          </div>

          {subVisao === 'protocolos' && recursosFiltrados.length > 0 && (
            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => expandirOuRecolherTodos(true)}
                className="text-carmim hover:underline font-medium cursor-pointer"
              >
                Expandir todos
              </button>
              <span className="text-linha">|</span>
              <button
                type="button"
                onClick={() => expandirOuRecolherTodos(false)}
                className="text-suave hover:text-tinta hover:underline font-medium cursor-pointer"
              >
                Recolher todos
              </button>
            </div>
          )}
        </div>

        {/* Barra de Filtros */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2 border-t border-linha">
          <div className="lg:col-span-2">
            <label htmlFor="admin-busca" className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Buscar por Protocolo, Unidade, Magistrado(a), Sigla ou Arquivo
            </label>
            <input
              id="admin-busca"
              type="search"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Ex.: RTQ-2026-00001, 1ª Vara Cível, IAD-C, SEEU..."
              className={CLASSE_INPUT}
            />
          </div>

          <div>
            <label htmlFor="admin-grau" className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Grau de Jurisdição
            </label>
            <select
              id="admin-grau"
              value={filtroGrau}
              onChange={(e) => setFiltroGrau(e.target.value)}
              className={CLASSE_INPUT}
            >
              <option value="TODOS">Todos (1º e 2º Grau)</option>
              <option value="1G">1º Grau</option>
              <option value="2G">2º Grau / Órgãos</option>
            </select>
          </div>

          <div>
            <label htmlFor="admin-indicador" className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Indicador Impugnado
            </label>
            <select
              id="admin-indicador"
              value={filtroIndicador}
              onChange={(e) => setFiltroIndicador(e.target.value)}
              className={CLASSE_INPUT}
            >
              <option value="TODOS">Todos os indicadores</option>
              {indicadoresPresentes.map((ind) => (
                <option key={ind.sigla} value={ind.sigla}>
                  {ind.sigla} — {ind.indicador}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="admin-status" className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Status de Julgamento
            </label>
            <select
              id="admin-status"
              value={filtroStatusAnalise}
              onChange={(e) => setFiltroStatusAnalise(e.target.value)}
              className={CLASSE_INPUT}
            >
              <option value="TODOS">Todos os status</option>
              {OPCOES_STATUS_ANALISE.map((st) => (
                <option key={st.valor} value={st.valor}>
                  {st.rotulo}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {erro && <Aviso tipo="erro">{erro}</Aviso>}
      {msgSucesso && <Aviso tipo="sucesso">{msgSucesso}</Aviso>}

      {carregando && (
        <div className="bg-white border border-linha rounded-lg p-6 text-sm text-suave">
          Carregando recursos e estrutura de pastas do Google Drive…
        </div>
      )}

      {!carregando && recursosFiltrados.length === 0 && (
        <div className="bg-white border border-linha rounded-lg p-6 text-sm text-suave">
          Nenhum recurso encontrado com os filtros selecionados.
        </div>
      )}

      {/* =====================================================================
       * VISÃO 1: RECURSOS ORGANIZADOS POR PROTOCOLO
       * =================================================================== */}
      {!carregando && subVisao === 'protocolos' && recursosFiltrados.length > 0 && (
        <div className="space-y-4">
          {recursosFiltrados.map((r) => {
            const aberto = !!abertos[r.protocolo];
            return (
              <article
                key={r.protocolo}
                className="bg-white border border-linha rounded-lg overflow-hidden shadow-2xs"
              >
                {/* Cabeçalho do Protocolo */}
                <div className="p-4 sm:p-5 bg-fundo/50 border-b border-linha flex flex-wrap items-center justify-between gap-4">
                  <div className="min-w-0">
                    <h3 className="break-words text-sm font-semibold text-tinta">{r.responsavel.nome}</h3>
                    <p className="text-sm text-suave">{r.unidade.comarca || 'Comarca não informada'}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {onAbrirAnalise && (
                      <button
                        type="button"
                        onClick={() => onAbrirAnalise(r.protocolo)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold transition-colors cursor-pointer"
                        title="Abrir aba Análise do Recurso (Parecer Técnico da SUMAE e Decisão Final da Comissão Revisora)"
                      >
                        Analisar recurso
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() =>
                        setAbertos((prev) => ({ ...prev, [r.protocolo]: !prev[r.protocolo] }))
                      }
                      className="px-3 py-1.5 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-tinta cursor-pointer"
                    >
                      {aberto ? 'Ocultar detalhes' : 'Ver detalhes'}
                    </button>
                  </div>
                </div>

                {/* Corpo expandido do Protocolo */}
                {aberto && (
                  <div className="p-4 sm:p-6 space-y-5">
                    {/* Dados completos do signatário */}
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-fundo/40 border border-linha rounded-md p-3.5 text-xs">
                      <div>
                        <span className="text-suave block">Magistrado(a) / Responsável</span>
                        <strong className="text-tinta">{r.responsavel.nome}</strong>
                      </div>
                      <div>
                        <span className="text-suave block">Cargo / Função</span>
                        <strong className="text-tinta">{r.responsavel.cargo}</strong>
                      </div>
                      <div>
                        <span className="text-suave block">CPF e Telefone</span>
                        <strong className="text-tinta tabular-nums">
                          {formatarCpf(r.responsavel.cpf)} · {r.responsavel.telefone || '—'}
                        </strong>
                      </div>
                      <div>
                        <span className="text-suave block">Conta Google Autenticada</span>
                        <strong className="text-tinta font-mono break-all">{r.emailGoogle}</strong>
                      </div>
                    </div>

                    {/* Impugnação da Lista de Servidores Vinculados, se houver */}
                    {r.impugnaListaServidores && (
                      <div className="border border-amber-300 bg-amber-50/50 rounded-md p-4 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs sm:text-sm font-bold text-amber-950">
                            Impugnação da Lista de Servidores Vinculados (Art. 5º, III, &ldquo;b&rdquo; e Art. 6º)
                          </h4>
                          <span className="text-[11px] font-semibold text-amber-900">
                            Elegibilidade / Lotação no Período
                          </span>
                        </div>
                        <p className="text-xs text-tinta whitespace-pre-wrap leading-relaxed bg-white border border-amber-200 rounded p-3">
                          {r.impugnacaoListaTexto}
                        </p>
                      </div>
                    )}

                    {/* Lista de Itens Impugnados */}
                    <div className="space-y-4">
                      <h4 className="text-xs uppercase tracking-wider font-bold text-suave">
                        Indicadores Impugnados neste Protocolo ({r.itens.length})
                      </h4>

                      {r.itens.map((it) => {
                        const chaveEdicao = `${r.protocolo}:${it.itemN}`;
                        const editandoEste = itemEditando === chaveEdicao;
                        const rotuloImpugnacao =
                          TIPOS_IMPUGNACAO_INFO.find((t) => t.codigo === it.tipoImpugnacao)
                            ?.rotulo || it.tipoImpugnacao;

                        return (
                          <div
                            key={chaveEdicao}
                            className="border border-linha rounded-lg p-4 sm:p-5 space-y-4 bg-white"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-linha pb-3">
                              <div className="space-y-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className="px-2 py-0.5 rounded bg-carmim text-white font-mono text-xs font-bold">
                                    Item #{it.itemN} · {it.sigla}
                                  </span>
                                  <span className="text-xs font-semibold text-suave">
                                    {it.grupo}
                                  </span>
                                  <SeloStatus status={it.statusAnalise} />
                                </div>
                                <h5 className="text-sm sm:text-base font-bold text-tinta">
                                  {it.indicador}
                                </h5>
                                <p className="text-xs text-suave">
                                  <strong className="text-tinta">Recorte / Subitem:</strong>{' '}
                                  {it.subitem} ·{' '}
                                  <strong className="text-tinta">Natureza do pedido:</strong>{' '}
                                  {rotuloImpugnacao}
                                </p>
                              </div>

                              <div className="flex flex-col sm:items-end gap-1.5">
                                <div className="inline-flex items-center gap-2 bg-fundo border border-linha rounded px-3 py-1.5 text-xs tabular-nums">
                                  <span>
                                    Preliminar:{' '}
                                    <strong className="text-tinta">
                                      {it.pontuacaoPreliminar !== ''
                                        ? `${it.pontuacaoPreliminar} pts`
                                        : '—'}
                                    </strong>
                                  </span>
                                  <span className="text-suave">→</span>
                                  <span>
                                    Pleiteada:{' '}
                                    <strong className="text-carmim">
                                      {it.pontuacaoPleiteada !== ''
                                        ? `${it.pontuacaoPleiteada} pts`
                                        : 'Exclusão (N/A)'}
                                    </strong>
                                  </span>
                                  {it.pontuacaoFinal !== '' && (
                                    <>
                                      <span className="text-suave">→</span>
                                      <span>
                                        Final:{' '}
                                        <strong className="text-verde">
                                          {it.pontuacaoFinal} pts
                                        </strong>
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Fundamentação Técnica */}
                            <div className="space-y-1.5">
                              <p className="text-xs font-bold text-tinta">
                                Fundamentação Técnica e Memória de Cálculo Apresentada (Art. 13):
                              </p>
                              <div className="bg-fundo/60 border border-linha rounded-md p-3.5 text-xs text-tinta whitespace-pre-wrap leading-relaxed">
                                {it.fundamentacao}
                              </div>
                            </div>

                            {/* Checklist de Evidências Obrigatórias (Anexo III, item 3) */}
                            <div className="flex flex-wrap items-center gap-2 text-[11px]">
                              <span className="font-semibold text-suave">
                                Requisitos Anexo III, item 3:
                              </span>
                              {[
                                { k: 'a', rot: '(a) Painel/Relatório' },
                                { k: 'b', rot: '(b) Filtros Aplicados' },
                                { k: 'c', rot: '(c) Período 01/01 a 30/11/2026' },
                                { k: 'd', rot: '(d) Memória de Cálculo' },
                                { k: 'e', rot: '(e) NPU e Qtd. Processos' },
                              ].map(({ k, rot }) => {
                                const ok = it.evidencias[k as keyof typeof it.evidencias];
                                return (
                                  <span
                                    key={k}
                                    className={`px-2 py-0.5 rounded border font-medium ${
                                      ok
                                        ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                                        : 'bg-red-50 border-red-200 text-red-900'
                                    }`}
                                  >
                                    {ok ? '✓ ' : '✗ '}
                                    {rot}
                                  </span>
                                );
                              })}
                            </div>

                            {/* Arquivos de Evidência no Google Drive */}
                            <div className="space-y-2 pt-1">
                              <div className="flex items-center justify-between">
                                <p className="text-xs font-bold text-tinta">
                                  Evidências Anexadas no Google Drive ({it.arquivos.length}):
                                </p>
                              </div>

                              {it.arquivos.length === 0 ? (
                                <p className="text-xs text-carmim">
                                  Nenhum arquivo de evidência localizado para este item.
                                </p>
                              ) : (
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                  {it.arquivos.map((arq, idxArq) => (
                                    <div
                                      key={`${arq.fileId}-${idxArq}`}
                                      className="flex items-start justify-between gap-3 p-3 rounded-md border border-linha bg-fundo/40 hover:bg-fundo transition-colors"
                                    >
                                      <div className="space-y-0.5 min-w-0">
                                        <p className="text-xs font-semibold text-tinta truncate" title={arq.nome}>
                                          {arq.nome}
                                        </p>
                                        <p className="text-[11px] text-suave tabular-nums">
                                          {formatarBytes(arq.bytes)} · {arq.mime.split('/').pop()?.toUpperCase()}
                                        </p>
                                        <p className="text-[10px] font-mono text-suave truncate" title={`SHA-256: ${arq.sha256}`}>
                                          SHA-256: {arq.sha256.slice(0, 20)}…
                                        </p>
                                      </div>

                                      <a
                                        href={arq.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 rounded bg-white hover:bg-carmim hover:text-white border border-linha text-carmim text-xs font-semibold transition-colors"
                                      >
                                        Abrir no Drive ↗
                                      </a>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Parecer / Decisão da Comissão Revisora */}
                            <div className="pt-3 border-t border-linha">
                              {!editandoEste ? (
                                <div className="flex flex-wrap items-center justify-between gap-3">
                                  <div className="text-xs space-y-0.5">
                                    {it.decisao || it.parecer || it.relator ? (
                                      <>
                                        <p className="text-tinta">
                                          <strong>Relator(a):</strong> {it.relator || '—'} ·{' '}
                                          <strong>Decisão:</strong> {it.decisao || '—'}
                                          {it.dataDecisao && (
                                            <span className="text-suave">
                                              {' '}
                                              ({formatarDataHora(it.dataDecisao)})
                                            </span>
                                          )}
                                        </p>
                                        {it.parecer && (
                                          <p className="text-suave whitespace-pre-wrap">
                                            <strong>Parecer Técnico:</strong> {it.parecer}
                                          </p>
                                        )}
                                      </>
                                    ) : (
                                      <p className="text-suave italic">
                                        Sem parecer/decisão lançados na planilha até o momento.
                                      </p>
                                    )}
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => abrirEdicaoItem(it)}
                                    className="px-3 py-1.5 rounded-md border border-carmim text-carmim hover:bg-carmim hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                                  >
                                    Registrar / Editar Parecer da Comissão
                                  </button>
                                </div>
                              ) : (
                                <div className="bg-fundo border border-linha rounded-md p-4 space-y-3">
                                  <h6 className="text-xs font-bold uppercase tracking-wider text-carmim">
                                    Deliberação da Comissão Avaliadora — {r.protocolo} · Item #{it.itemN} ({it.sigla})
                                  </h6>

                                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <div>
                                      <label className="block text-xs font-semibold text-tinta mb-1">
                                        Status da Análise
                                      </label>
                                      <select
                                        value={formAnalise.statusAnalise}
                                        onChange={(e) =>
                                          setFormAnalise((prev) => ({
                                            ...prev,
                                            statusAnalise: e.target.value as StatusAnalise,
                                          }))
                                        }
                                        className={CLASSE_INPUT}
                                      >
                                        {OPCOES_STATUS_ANALISE.map((op) => (
                                          <option key={op.valor} value={op.valor}>
                                            {op.rotulo}
                                          </option>
                                        ))}
                                      </select>
                                    </div>

                                    <div>
                                      <label className="block text-xs font-semibold text-tinta mb-1">
                                        Relator(a) / Analista DIGED
                                      </label>
                                      <input
                                        type="text"
                                        value={formAnalise.relator}
                                        onChange={(e) =>
                                          setFormAnalise((prev) => ({
                                            ...prev,
                                            relator: e.target.value,
                                          }))
                                        }
                                        className={CLASSE_INPUT}
                                        placeholder="Nome do relator"
                                      />
                                    </div>

                                    <div>
                                      <label className="block text-xs font-semibold text-tinta mb-1">
                                        Pontuação Final Pós-Recurso
                                      </label>
                                      <input
                                        type="number"
                                        step="any"
                                        min="0"
                                        max="1000"
                                        value={formAnalise.pontuacaoFinal}
                                        onChange={(e) =>
                                          setFormAnalise((prev) => ({
                                            ...prev,
                                            pontuacaoFinal: e.target.value,
                                          }))
                                        }
                                        className={CLASSE_INPUT}
                                        placeholder="Ex.: 120"
                                      />
                                    </div>
                                  </div>

                                  <div>
                                    <label className="block text-xs font-semibold text-tinta mb-1">
                                      Síntese da Decisão (exibida à unidade recorrente em &ldquo;Meus recursos&rdquo;)
                                    </label>
                                    <input
                                      type="text"
                                      value={formAnalise.decisao}
                                      onChange={(e) =>
                                        setFormAnalise((prev) => ({
                                          ...prev,
                                          decisao: e.target.value,
                                        }))
                                      }
                                      className={CLASSE_INPUT}
                                      placeholder="Ex.: Recurso provido para ajustar o IAD-C para 102,4% (120 pontos)."
                                    />
                                  </div>

                                  <div>
                                    <label className="block text-xs font-semibold text-tinta mb-1">
                                      Parecer Técnico Fundamentado (Art. 13 e Art. 14)
                                    </label>
                                    <textarea
                                      rows={3}
                                      value={formAnalise.parecer}
                                      onChange={(e) =>
                                        setFormAnalise((prev) => ({
                                          ...prev,
                                          parecer: e.target.value,
                                        }))
                                      }
                                      className={CLASSE_INPUT}
                                      placeholder="Fundamentação técnica da DIGED/SUMAE e deliberação da Comissão..."
                                    />
                                  </div>

                                  <div className="flex items-center justify-end gap-2">
                                    <button
                                      type="button"
                                      onClick={() => setItemEditando(null)}
                                      className="px-3 py-1.5 rounded-md border border-linha bg-white text-xs font-semibold text-suave hover:text-tinta cursor-pointer"
                                    >
                                      Cancelar
                                    </button>
                                    <button
                                      type="button"
                                      disabled={salvandoAnalise}
                                      onClick={() => salvarAnaliseItem(r.protocolo, it.itemN)}
                                      className="px-4 py-1.5 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                                    >
                                      {salvandoAnalise ? 'Salvando…' : 'Salvar Parecer na Planilha'}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      {/* =====================================================================
       * VISÃO 2: AGRUPADO POR INDICADOR DO ANEXO II
       * =================================================================== */}
      {!carregando && subVisao === 'indicadores' && (
        <div className="space-y-4">
          {agrupadoPorIndicador.map((grupo) => (
            <section
              key={grupo.sigla}
              className="bg-white border border-linha rounded-lg p-5 space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-linha pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-carmim text-white font-mono text-xs font-bold">
                      {grupo.sigla}
                    </span>
                    <span className="text-xs text-suave font-semibold">{grupo.grupo}</span>
                  </div>
                  <h3 className="text-base font-bold text-tinta mt-1">{grupo.indicador}</h3>
                </div>
                <span className="px-3 py-1 rounded-md bg-fundo border border-linha text-xs font-bold text-tinta">
                  {grupo.ocorrencias.length} impugnação(ões)
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-linha text-suave uppercase text-[11px]">
                      <th className="py-2 pr-3">Protocolo</th>
                      <th className="py-2 pr-3">Unidade Judiciária</th>
                      <th className="py-2 pr-3">Subitem / Recorte</th>
                      <th className="py-2 pr-3">Pontos (Prelim → Pleit)</th>
                      <th className="py-2 pr-3">Status</th>
                      <th className="py-2 text-right">Evidências no Drive</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-linha">
                    {grupo.ocorrencias.map(({ recurso, item }) => (
                      <tr key={`${recurso.protocolo}-${item.itemN}`} className="hover:bg-fundo/50">
                        <td className="py-2.5 pr-3 font-mono font-bold text-carmim whitespace-nowrap">
                          {recurso.protocolo}
                        </td>
                        <td className="py-2.5 pr-3 font-medium text-tinta">
                          {recurso.unidade.nome}
                          <span className="block text-[11px] text-suave">{recurso.responsavel.nome}</span>
                        </td>
                        <td className="py-2.5 pr-3 text-suave">{item.subitem}</td>
                        <td className="py-2.5 pr-3 tabular-nums whitespace-nowrap">
                          {item.pontuacaoPreliminar !== '' ? `${item.pontuacaoPreliminar}` : '—'} →{' '}
                          <strong className="text-tinta">
                            {item.pontuacaoPleiteada !== '' ? `${item.pontuacaoPleiteada}` : 'N/A'}
                          </strong>
                        </td>
                        <td className="py-2.5 pr-3">
                          <SeloStatus status={item.statusAnalise} />
                        </td>
                        <td className="py-2.5 text-right whitespace-nowrap">
                          {item.pastaItemUrl && (
                            <a
                              href={item.pastaItemUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-verde/10 text-verde hover:bg-verde/20 font-semibold"
                            >
                              Pasta Drive ({item.arquivos.length} arq.) ↗
                            </a>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          ))}
        </div>
      )}

      {/* =====================================================================
       * VISÃO 3: REPOSITÓRIO DE EVIDÊNCIAS NO GOOGLE DRIVE
       * =================================================================== */}
      {!carregando && subVisao === 'drive' && (
        <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-linha pb-4">
            <div>
              <h3 className="text-base font-bold text-tinta">
                Índice Completo e Organização de Pastas na Pasta Raiz do Google Drive
              </h3>
              <p className="text-xs text-suave">
                ID da Pasta Raiz:{' '}
                <code className="text-tinta bg-fundo px-1.5 py-0.5 rounded font-mono">
                  {DRIVE_ROOT_FOLDER_ID}
                </code>{' '}
                · Hierarquia:{' '}
                <code className="text-tinta bg-fundo px-1.5 py-0.5 rounded">
                  [Unidade] / [Protocolo] / [01_SIGLA] / arquivos
                </code>
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <a
                href={dados?.pastaRaizUrl || PASTA_RAIZ_DRIVE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md bg-verde text-white text-xs font-semibold hover:bg-verde/90"
              >
                Pasta Raiz de Evidências ({DRIVE_ROOT_FOLDER_ID.slice(0, 8)}…) ↗
              </a>
              <a
                href={PASTA_PROTOCOLO_DRIVE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md border border-verde/30 bg-verde/10 text-verde text-xs font-semibold hover:bg-verde/20"
              >
                Pasta do Protocolo no Drive ({PROTOCOLO_FOLDER_ID.slice(0, 8)}…) ↗
              </a>
            </div>
          </div>

          {/* Árvore Hierárquica Organizada por Unidade -> Protocolo -> Indicador */}
          <div className="bg-fundo/50 border border-linha rounded-lg p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-carmim">
                Estrutura Organizada por Unidade, Protocolo e Indicador ({arvoreDriveOrganizada.totalUnidades} unidade[s] · {arvoreDriveOrganizada.totalProtocolos} protocolo[s] · {arvoreDriveOrganizada.totalArquivos} arquivo[s])
              </h4>
              <span className="text-xs text-suave tabular-nums">
                Volume total: <strong className="text-tinta">{formatarBytes(arvoreDriveOrganizada.totalBytes)}</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {arvoreDriveOrganizada.unidades.map((unid) => (
                <div
                  key={unid.pastaId}
                  className="bg-white border border-linha rounded-md p-3.5 space-y-2.5 text-xs"
                >
                  <div className="flex items-start justify-between gap-2 border-b border-linha pb-2">
                    <div>
                      <span className="font-mono font-bold text-carmim">{unid.codigoUnidade}</span>
                      <p className="font-bold text-tinta">{unid.nomeUnidade}</p>
                    </div>
                    <a
                      href={unid.webViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="shrink-0 text-[11px] font-semibold text-verde hover:underline"
                    >
                      Pasta Unidade ↗
                    </a>
                  </div>

                  {unid.protocolos.map((prot) => (
                    <div key={prot.protocolo} className="pl-2 border-l-2 border-carmim/30 space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-bold text-tinta">
                          📁 {prot.protocolo} ({prot.totalArquivos} arq.)
                        </span>
                        <a
                          href={prot.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-verde font-semibold hover:underline"
                        >
                          Abrir protocolo ↗
                        </a>
                      </div>
                      <div className="space-y-1 pl-3">
                        {prot.indicadores.map((ind) => (
                          <div
                            key={ind.pastaId}
                            className="flex flex-wrap items-center justify-between gap-2 bg-fundo/60 rounded px-2.5 py-1"
                          >
                            <span className="font-mono text-[11px] text-tinta">
                              📂 {ind.nomePasta} ({ind.arquivos.length} arq. · {formatarBytes(ind.totalBytes)})
                            </span>
                            <a
                              href={ind.webViewLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] text-carmim font-semibold hover:underline"
                            >
                              Ver subpasta ↗
                            </a>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-linha text-suave uppercase text-[11px]">
                  <th className="py-2.5 pr-3">Protocolo / Pasta</th>
                  <th className="py-2.5 pr-3">Unidade</th>
                  <th className="py-2.5 pr-3">Indicador</th>
                  <th className="py-2.5 pr-3">Arquivo de Evidência</th>
                  <th className="py-2.5 pr-3">Tamanho / Hash SHA-256</th>
                  <th className="py-2.5 text-right">Acesso no Google Drive</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-linha">
                {recursosFiltrados.flatMap((r) =>
                  r.itens.flatMap((it) =>
                    it.arquivos.map((arq, idx) => (
                      <tr key={`${r.protocolo}-${it.itemN}-${idx}`} className="hover:bg-fundo/50">
                        <td className="py-2.5 pr-3 whitespace-nowrap">
                          <span className="font-mono font-bold text-carmim block">
                            {r.protocolo}
                          </span>
                          {r.pastaUrl && (
                            <a
                              href={r.pastaUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] text-verde hover:underline"
                            >
                              Pasta do protocolo ↗
                            </a>
                          )}
                        </td>
                        <td className="py-2.5 pr-3 text-tinta font-medium">
                          {r.unidade.nome}
                          <span className="block text-[11px] text-suave">{r.unidade.comarca}</span>
                        </td>
                        <td className="py-2.5 pr-3 whitespace-nowrap">
                          <span className="font-mono font-bold text-tinta">{it.sigla}</span>
                          {it.pastaItemUrl && (
                            <a
                              href={it.pastaItemUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="block text-[11px] text-verde hover:underline"
                            >
                              Subpasta 0{it.itemN}_{it.sigla} ↗
                            </a>
                          )}
                        </td>
                        <td className="py-2.5 pr-3 font-medium text-tinta">
                          {arq.nome}
                          <span className="block text-[11px] text-suave">
                            Enviado em {formatarDataHora(arq.enviadoEm)}
                          </span>
                        </td>
                        <td className="py-2.5 pr-3 tabular-nums text-suave">
                          <strong className="text-tinta">{formatarBytes(arq.bytes)}</strong>
                          <span className="block font-mono text-[10px]">
                            SHA-256: {arq.sha256.slice(0, 16)}…
                          </span>
                        </td>
                        <td className="py-2.5 text-right whitespace-nowrap">
                          <a
                            href={arq.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-linha bg-white hover:bg-carmim hover:text-white text-carmim font-semibold transition-colors"
                          >
                            Abrir Arquivo ↗
                          </a>
                        </td>
                      </tr>
                    ))
                  )
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* =====================================================================
       * VISÃO 4: INTEGRAÇÃO DIRETA GOOGLE WORKSPACE (DRIVE, SHEETS E FORMS)
       * =================================================================== */}
      {!carregando && subVisao === 'workspace' && (
        <IntegracaoWorkspace
          recursos={recursosFiltrados}
          onPlanilhaMestraAtualizada={(url) => setPlanilhaMestraUrl(url)}
        />
      )}
    </div>
  );
}
