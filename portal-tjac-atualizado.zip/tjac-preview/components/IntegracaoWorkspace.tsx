import { MODO_DEMO } from '../config';
import React, { useEffect, useState } from 'react';
import { firebaseConfig } from '../firebase';
import { enviarEvidenciaFirebaseStorage } from '../services/storage';
import {
  consultarFormularioGoogle,
  criarFormularioGoogleRecursos,
  criarPlanilhaConsolidadaSheets,
  getAccessToken,
  googleSignIn,
  initAuth,
  lerAbaPlanilha,
  listarArquivosDrive,
  logoutWorkspace,
  obterMetadadosPlanilha,
  sincronizarEstruturaPastasDrive,
  type DadosFormularioGoogle,
  type DriveFileItem,
  type MetadadosPlanilha,
} from '../services/workspace';
import type { RecursoAdmin } from '../types';
import { formatarBytes, formatarDataHora } from '../utils';
import { Aviso, CLASSE_INPUT } from './ui';

import {
  PASTA_PROTOCOLO_DRIVE_URL,
  PASTA_RAIZ_DRIVE_URL,
  PROTOCOLO_FOLDER_ID,
  ROOT_FOLDER_ID,
} from '../config';
import { salvarPlanilhaMestraUrl } from '../services/api';

interface IntegracaoWorkspaceProps {
  recursos: RecursoAdmin[];
  onPlanilhaMestraAtualizada?: (url: string) => void;
}

interface ConfirmacaoPendente {
  titulo: string;
  descricao: string;
  detalhes: string[];
  rotuloConfirmar: string;
  acao: () => Promise<void>;
}

export function BotaoGoogleOficial({
  onClick,
  carregando,
  rotulo = 'Conectar com o Google (Drive, Sheets e Forms)',
}: {
  onClick: () => void;
  carregando?: boolean;
  rotulo?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={carregando}
      className="gsi-material-button inline-flex items-center gap-3 px-4 py-2.5 rounded-md border border-linha bg-white hover:bg-fundo text-tinta text-xs sm:text-sm font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-50"
    >
      <div className="w-5 h-5 shrink-0">
        <svg
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 48 48"
          className="block w-full h-full"
        >
          <path
            fill="#EA4335"
            d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
          />
          <path
            fill="#4285F4"
            d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
          />
          <path
            fill="#FBBC05"
            d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
          />
          <path
            fill="#34A853"
            d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
          />
          <path fill="none" d="M0 0h48v48H0z" />
        </svg>
      </div>
      <span>{carregando ? 'Autenticando no Google…' : rotulo}</span>
    </button>
  );
}

export function IntegracaoWorkspace({
  recursos,
  onPlanilhaMestraAtualizada,
}: IntegracaoWorkspaceProps) {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [emailConectado, setEmailConectado] = useState<string>('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  // Modal de confirmação obrigatória para operações de escrita/criação no Workspace
  const [confirmacao, setConfirmacao] = useState<ConfirmacaoPendente | null>(null);
  const [executandoAcao, setExecutandoAcao] = useState(false);

  // Estado Google Drive
  const [buscaDrive, setBuscaDrive] = useState('');
  const [arquivosDrive, setArquivosDrive] = useState<DriveFileItem[]>([]);
  const [carregandoDrive, setCarregandoDrive] = useState(false);
  const [pastaSincronizadaUrl, setPastaSincronizadaUrl] = useState('');

  // Estado Google Sheets
  const [sheetIdInput, setSheetIdInput] = useState('');
  const [metaPlanilha, setMetaPlanilha] = useState<MetadadosPlanilha | null>(null);
  const [abaSelecionada, setAbaSelecionada] = useState('');
  const [linhasAba, setLinhasAba] = useState<string[][]>([]);
  const [carregandoSheets, setCarregandoSheets] = useState(false);

  // Estado Google Forms
  const [formIdInput, setFormIdInput] = useState('');
  const [dadosForm, setDadosForm] = useState<DadosFormularioGoogle | null>(null);
  const [carregandoForms, setCarregandoForms] = useState(false);

  // Estado Firebase Cloud Storage (getStorage / ref / uploadBytes / getDownloadURL)
  const [arqStorage, setArqStorage] = useState<File | null>(null);
  const [protocoloStorage, setProtocoloStorage] = useState(
    recursos[0]?.protocolo || 'RTQ-2026-00001'
  );
  const [siglaStorage, setSiglaStorage] = useState(
    recursos[0]?.itens[0]?.sigla || 'IAD-C'
  );
  const [ultimoUploadStorage, setUltimoUploadStorage] = useState<{
    storagePath: string;
    downloadUrl: string;
    nome: string;
  } | null>(null);

  const solicitarUploadFirebaseStorage = () => {
    if (!arqStorage) return;
    setConfirmacao({
      titulo: 'Enviar arquivo de evidência para o Firebase Cloud Storage?',
      descricao: `O arquivo "${arqStorage.name}" será enviado ao bucket ${firebaseConfig.storageBucket} vinculado ao protocolo ${protocoloStorage}.`,
      detalhes: [
        `Bucket: ${firebaseConfig.storageBucket}`,
        `Protocolo / Indicador: ${protocoloStorage} · ${siglaStorage}`,
        `Arquivo: ${arqStorage.name} (${formatarBytes(arqStorage.size)})`,
      ],
      rotuloConfirmar: 'Confirmar envio ao Firebase Storage',
      acao: async () => {
        const res = await enviarEvidenciaFirebaseStorage({
          protocolo: protocoloStorage,
          codUnidade: 'TJAC',
          itemN: 1,
          sigla: siglaStorage,
          nomeArquivo: arqStorage.name,
          mime: arqStorage.type || 'application/pdf',
          arquivo: arqStorage,
          emailGoogle: emailConectado || 'arturgemeos06@gmail.com',
        });
        setUltimoUploadStorage({
          storagePath: res.storagePath,
          downloadUrl: res.downloadUrl,
          nome: arqStorage.name,
        });
        setArqStorage(null);
        setSucesso(
          `Evidência enviada ao Firebase Storage com sucesso (${res.storagePath}).`
        );
      },
    });
  };

  useEffect(() => {
    const unsub = initAuth(
      (user, accessToken) => {
        setToken(accessToken);
        setEmailConectado(user.email || '');
        setNeedsAuth(false);
      },
      () => {
        setToken(null);
        setEmailConectado('');
        setNeedsAuth(true);
      }
    );
    return () => unsub();
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setErro('');
    try {
      const result = await googleSignIn();
      if (result) {
        setToken(result.accessToken);
        setEmailConectado(result.user.email || '');
        setNeedsAuth(false);
        const arqs = await listarArquivosDrive(result.accessToken, '');
        setArquivosDrive(arqs);
      }
    } catch (e) {
      setErro(
        e instanceof Error
          ? e.message
          : 'Não foi possível concluir a autenticação com o Google Workspace.'
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await logoutWorkspace();
    setToken(null);
    setEmailConectado('');
    setNeedsAuth(true);
    setArquivosDrive([]);
    setMetaPlanilha(null);
    setDadosForm(null);
  };

  const consultarDrive = async () => {
    const tk = token || (await getAccessToken());
    if (!tk) {
      setNeedsAuth(true);
      return;
    }
    setCarregandoDrive(true);
    setErro('');
    try {
      const lista = await listarArquivosDrive(tk, buscaDrive);
      setArquivosDrive(lista);
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Erro ao listar arquivos do Google Drive.');
    } finally {
      setCarregandoDrive(false);
    }
  };

  const solicitarCriacaoPastasDrive = () => {
    const totalPastasItens = recursos.reduce((acc, r) => acc + r.itens.length, 0);
    setConfirmacao({
      titulo: 'Criar estrutura de pastas de evidências no Google Drive?',
      descricao:
        'Esta operação criará uma pasta raiz e subpastas organizadas por unidade, protocolo e indicador no seu Google Drive.',
      detalhes: [
        'Pasta raiz: "Prêmio TJAC 2026 — Recursos (EVIDÊNCIAS)"',
        `${recursos.length} pasta(s) de Unidades Judiciárias e Protocolos (${recursos.map((r) => r.protocolo).join(', ')})`,
        `${totalPastasItens} subpasta(s) de itens impugnados`,
      ],
      rotuloConfirmar: 'Confirmar criação no Google Drive',
      acao: async () => {
        const tk = token || (await getAccessToken());
        if (!tk) {
          setNeedsAuth(true);
          return;
        }
        const res = await sincronizarEstruturaPastasDrive(tk, recursos);
        setPastaSincronizadaUrl(res.pastaRaizUrl);
        setSucesso(
          `Estrutura criada no Google Drive com sucesso (${res.pastasCriadas} pastas provisionadas).`
        );
        const lista = await listarArquivosDrive(tk, buscaDrive);
        setArquivosDrive(lista);
      },
    });
  };

  const solicitarExportacaoPlanilhaSheets = () => {
    const totalItens = recursos.reduce((acc, r) => acc + r.itens.length, 0);
    const totalArqs = recursos.reduce(
      (acc, r) => acc + r.itens.reduce((s, i) => s + i.arquivos.length, 0),
      0
    );
    setConfirmacao({
      titulo: 'Criar planilha consolidada no Google Sheets?',
      descricao:
        'Esta operação criará uma nova planilha Google Sheets na sua conta contendo todas as abas oficiais e os recursos registrados.',
      detalhes: [
        'Título: "Prêmio TJAC 2026 — Recursos Consolidados (DIGED/SUMAE)"',
        `Aba RECURSOS: ${recursos.length} protocolo(s) cadastrado(s)`,
        `Aba ITENS: ${totalItens} indicador(es) impugnado(s) com fundamentação e pareceres`,
        `Aba ARQUIVOS: ${totalArqs} registro(s) de evidências com links e hash SHA-256`,
      ],
      rotuloConfirmar: 'Confirmar criação no Google Sheets',
      acao: async () => {
        const tk = token || (await getAccessToken());
        if (!tk) {
          setNeedsAuth(true);
          return;
        }
        const res = await criarPlanilhaConsolidadaSheets(tk, recursos);
        setSheetIdInput(res.spreadsheetId);
        if (onPlanilhaMestraAtualizada) {
          onPlanilhaMestraAtualizada(res.spreadsheetUrl);
        }
        const meta = await obterMetadadosPlanilha(tk, res.spreadsheetId);
        setMetaPlanilha(meta);
        if (meta.abas.length > 0) {
          setAbaSelecionada(meta.abas[0].title);
          const valores = await lerAbaPlanilha(tk, res.spreadsheetId, meta.abas[0].title);
          setLinhasAba(valores);
        }
        setSucesso('Planilha Mestra consolidada criada, vinculada ao painel e preenchida no Google Sheets com sucesso.');
      },
    });
  };

  const carregarPlanilhaExistente = async () => {
    if (!sheetIdInput.trim()) return;
    const tk = token || (await getAccessToken());
    if (!tk) {
      setNeedsAuth(true);
      return;
    }
    setCarregandoSheets(true);
    setErro('');
    try {
      const meta = await obterMetadadosPlanilha(tk, sheetIdInput);
      setMetaPlanilha(meta);
      salvarPlanilhaMestraUrl(meta.spreadsheetUrl);
      if (onPlanilhaMestraAtualizada) {
        onPlanilhaMestraAtualizada(meta.spreadsheetUrl);
      }
      if (meta.abas.length > 0) {
        const primeiraAba = meta.abas[0].title;
        setAbaSelecionada(primeiraAba);
        const valores = await lerAbaPlanilha(tk, meta.spreadsheetId, primeiraAba);
        setLinhasAba(valores);
      }
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Falha ao ler planilha no Google Sheets.');
    } finally {
      setCarregandoSheets(false);
    }
  };

  const trocarAbaPlanilha = async (tituloAba: string) => {
    setAbaSelecionada(tituloAba);
    if (!metaPlanilha) return;
    const tk = token || (await getAccessToken());
    if (!tk) {
      setNeedsAuth(true);
      return;
    }
    setCarregandoSheets(true);
    try {
      const valores = await lerAbaPlanilha(tk, metaPlanilha.spreadsheetId, tituloAba);
      setLinhasAba(valores);
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Erro ao carregar dados da aba.');
    } finally {
      setCarregandoSheets(false);
    }
  };

  const solicitarCriacaoFormularioForms = () => {
    setConfirmacao({
      titulo: 'Criar formulário espelho no Google Forms?',
      descricao:
        'Esta operação criará um novo formulário no Google Forms com os campos de Unidade Judiciária, Indicador Impugnado e Fundamentação Técnica (Portaria PRESI nº 1961/2026).',
      detalhes: [
        'Título: "Prêmio TJAC de Qualidade 2026 — Formulário de Recursos (Espelho Google Forms)"',
        '3 questões estruturadas obrigatórias (Unidade, Indicador e Fundamentação/Links)',
      ],
      rotuloConfirmar: 'Confirmar criação no Google Forms',
      acao: async () => {
        const tk = token || (await getAccessToken());
        if (!tk) {
          setNeedsAuth(true);
          return;
        }
        const form = await criarFormularioGoogleRecursos(tk);
        setFormIdInput(form.formId);
        setDadosForm(form);
        setSucesso('Formulário criado no Google Forms com sucesso.');
      },
    });
  };

  const carregarFormularioExistente = async () => {
    if (!formIdInput.trim()) return;
    const tk = token || (await getAccessToken());
    if (!tk) {
      setNeedsAuth(true);
      return;
    }
    setCarregandoForms(true);
    setErro('');
    try {
      const d = await consultarFormularioGoogle(tk, formIdInput);
      setDadosForm(d);
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Falha ao consultar formulário no Google Forms.');
    } finally {
      setCarregandoForms(false);
    }
  };

  const confirmarExecucaoModal = async () => {
    if (!confirmacao) return;
    setExecutandoAcao(true);
    setErro('');
    setSucesso('');
    try {
      await confirmacao.acao();
      setConfirmacao(null);
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Falha ao executar operação no Google Workspace.');
      setConfirmacao(null);
    } finally {
      setExecutandoAcao(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Modal de confirmação explícita antes de criar/modificar dados no Google Workspace */}
      {confirmacao && (
        <div
          className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white border border-linha rounded-lg max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="space-y-1">
              <p className="text-[11px] uppercase tracking-wider font-bold text-carmim">
                Confirmação de Operação no Google Workspace
              </p>
              <h3 className="text-base sm:text-lg font-bold text-tinta">{confirmacao.titulo}</h3>
            </div>
            <p className="text-xs sm:text-sm text-suave leading-relaxed">
              {confirmacao.descricao}
            </p>
            <ul className="bg-fundo border border-linha rounded-md p-3 space-y-1 text-xs text-tinta list-disc pl-5">
              {confirmacao.detalhes.map((d, i) => (
                <li key={i}>{d}</li>
              ))}
            </ul>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={executandoAcao}
                onClick={() => setConfirmacao(null)}
                className="px-3.5 py-2 rounded-md border border-linha bg-white hover:bg-fundo text-xs font-semibold text-suave hover:text-tinta cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={executandoAcao}
                onClick={confirmarExecucaoModal}
                className="px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
              >
                {executandoAcao ? 'Processando…' : confirmacao.rotuloConfirmar}
              </button>
            </div>
          </div>
        </div>
      )}

      {erro && <Aviso tipo="erro">{erro}</Aviso>}
      {sucesso && <Aviso tipo="sucesso">{sucesso}</Aviso>}

      {/* Bloco de Autenticação OAuth Google Workspace */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-tinta">
              Conexão Direta com Google Drive, Google Sheets e Google Forms
            </h3>
            <p className="text-xs text-suave leading-relaxed max-w-2xl">
              Autentique-se com sua conta Google (<code className="text-tinta">josue.silva@tjac.jus.br</code>{' '}
              ou <code className="text-tinta">arturgemeos06@gmail.com</code>) para sincronizar pastas de
              evidências no <strong>Google Drive</strong>, gerar ou ler a planilha mestre no{' '}
              <strong>Google Sheets</strong> e gerenciar formulários no <strong>Google Forms</strong>.
            </p>
          </div>

          {needsAuth || !token ? (
            MODO_DEMO ? (
              <p className="text-sm text-suave">Conexão com o Google desativada na demonstração.</p>
            ) : (
              <BotaoGoogleOficial onClick={handleLogin} carregando={isLoggingIn} />
            )
          ) : (
            <div className="flex flex-wrap items-center gap-3 bg-emerald-50 border border-emerald-200 rounded-md px-3.5 py-2">
              <div className="text-xs">
                <span className="font-bold text-emerald-900 block">
                  ● Google Workspace Conectado
                </span>
                <span className="font-mono text-emerald-800">{emailConectado}</span>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                className="px-2.5 py-1 rounded border border-emerald-300 bg-white hover:bg-emerald-100 text-emerald-900 text-xs font-semibold cursor-pointer"
              >
                Desconectar
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Bloco Firebase Cloud Storage (getStorage / ref / uploadBytes / getDownloadURL) */}
      <section className="bg-white border border-linha rounded-lg p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-linha pb-3">
          <div>
            <h3 className="text-base font-bold text-tinta">
              Armazenamento de Evidências no Firebase Cloud Storage
            </h3>
            <p className="text-xs text-suave">
              Bucket configurado:{' '}
              <code className="text-tinta bg-fundo px-1.5 py-0.5 rounded font-mono">
                {firebaseConfig.storageBucket}
              </code>{' '}
              (via <code className="text-tinta">getStorage</code>, <code className="text-tinta">ref</code>,{' '}
              <code className="text-tinta">uploadBytes</code> e{' '}
              <code className="text-tinta">getDownloadURL</code>)
            </p>
          </div>
          <span className="px-2.5 py-1 rounded text-xs font-bold bg-ouro/15 text-tinta border border-ouro/40">
            firebase/storage ativo
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
          <div>
            <label className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Protocolo Vinculado
            </label>
            <input
              type="text"
              value={protocoloStorage}
              onChange={(e) => setProtocoloStorage(e.target.value)}
              className={CLASSE_INPUT}
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Sigla do Indicador
            </label>
            <input
              type="text"
              value={siglaStorage}
              onChange={(e) => setSiglaStorage(e.target.value)}
              className={CLASSE_INPUT}
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-suave uppercase mb-1">
              Arquivo de Evidência
            </label>
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.xlsx,.xls,.csv,.docx"
              onChange={(e) => setArqStorage(e.target.files?.[0] || null)}
              className="block w-full text-xs text-suave file:mr-2 file:py-1.5 file:px-3 file:rounded file:border file:border-linha file:text-xs file:font-semibold file:bg-fundo file:text-tinta hover:file:bg-linha/60 cursor-pointer"
            />
          </div>
          <div>
            <button
              type="button"
              disabled={!arqStorage}
              onClick={solicitarUploadFirebaseStorage}
              className="w-full px-4 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              Enviar ao Firebase Storage
            </button>
          </div>
        </div>

        {ultimoUploadStorage && (
          <div className="p-3.5 rounded-md bg-emerald-50 border border-emerald-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <p className="font-bold text-emerald-950">
                Arquivo armazenado: {ultimoUploadStorage.nome}
              </p>
              <p className="font-mono text-[11px] text-emerald-900">
                Ref: {ultimoUploadStorage.storagePath}
              </p>
            </div>
            <a
              href={ultimoUploadStorage.downloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded bg-verde text-white font-semibold hover:bg-verde/90"
            >
              Abrir Download URL ↗
            </a>
          </div>
        )}
      </section>

      {!needsAuth && token && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 1. GOOGLE DRIVE */}
          <section className="bg-white border border-linha rounded-lg p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 border-b border-linha pb-2.5">
                <h4 className="text-sm font-bold text-tinta">1. Google Drive (Evidências)</h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-verde/10 text-verde">
                  Drive API v3
                </span>
              </div>
              <p className="text-xs text-suave leading-relaxed">
                Pastas oficiais vinculadas:{' '}
                <a
                  href={PASTA_RAIZ_DRIVE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-verde font-semibold hover:underline"
                >
                  Pasta Raiz ({ROOT_FOLDER_ID.slice(0, 8)}…) ↗
                </a>{' '}
                e{' '}
                <a
                  href={PASTA_PROTOCOLO_DRIVE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-verde font-semibold hover:underline"
                >
                  Pasta do Protocolo ({PROTOCOLO_FOLDER_ID.slice(0, 8)}…) ↗
                </a>
                .
              </p>

              <button
                type="button"
                onClick={solicitarCriacaoPastasDrive}
                className="w-full px-3.5 py-2 rounded-md bg-verde hover:bg-verde/90 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Provisionar Subpastas na Pasta Raiz do Drive
              </button>

              {pastaSincronizadaUrl && (
                <a
                  href={pastaSincronizadaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-center px-3 py-1.5 rounded border border-verde bg-emerald-50 text-verde text-xs font-semibold hover:underline"
                >
                  Abrir Pasta Raiz Criada no Google Drive ↗
                </a>
              )}

              <div className="pt-2 border-t border-linha space-y-2">
                <label className="block text-[11px] font-semibold text-suave uppercase">
                  Pesquisar arquivos/pastas no seu Drive
                </label>
                <div className="flex gap-2">
                  <input
                    type="search"
                    value={buscaDrive}
                    onChange={(e) => setBuscaDrive(e.target.value)}
                    placeholder="Nome do arquivo ou pasta..."
                    className={CLASSE_INPUT}
                  />
                  <button
                    type="button"
                    onClick={consultarDrive}
                    disabled={carregandoDrive}
                    className="px-3 py-2 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
                  >
                    {carregandoDrive ? '...' : 'Buscar'}
                  </button>
                </div>

                <div className="max-h-56 overflow-y-auto divide-y divide-linha border border-linha rounded-md bg-fundo/30">
                  {arquivosDrive.length === 0 ? (
                    <p className="p-3 text-xs text-suave">
                      Clique em &ldquo;Buscar&rdquo; para listar seus arquivos recentes do Drive.
                    </p>
                  ) : (
                    arquivosDrive.map((f) => (
                      <div
                        key={f.id}
                        className="p-2.5 text-xs flex items-center justify-between gap-2 hover:bg-white"
                      >
                        <div className="min-w-0">
                          <p className="font-semibold text-tinta truncate" title={f.name}>
                            {f.name}
                          </p>
                          <p className="text-[10px] text-suave">
                            {f.size ? formatarBytes(Number(f.size)) : 'Pasta / Documento Google'} ·{' '}
                            {f.modifiedTime ? formatarDataHora(f.modifiedTime) : ''}
                          </p>
                        </div>
                        {f.webViewLink && (
                          <a
                            href={f.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="shrink-0 text-carmim font-semibold hover:underline"
                          >
                            Abrir ↗
                          </a>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </section>

          {/* 2. GOOGLE SHEETS */}
          <section className="bg-white border border-linha rounded-lg p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 border-b border-linha pb-2.5">
                <h4 className="text-sm font-bold text-tinta">2. Google Sheets (Planilha Base)</h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-900">
                  Sheets API v4
                </span>
              </div>
              <p className="text-xs text-suave leading-relaxed">
                Gere uma planilha consolidada no Google Sheets com as abas{' '}
                <code className="text-tinta">RECURSOS</code>, <code className="text-tinta">ITENS</code> e{' '}
                <code className="text-tinta">ARQUIVOS</code> ou inspecione qualquer planilha existente.
              </p>

              <button
                type="button"
                onClick={solicitarExportacaoPlanilhaSheets}
                className="w-full px-3.5 py-2 rounded-md bg-carmim hover:bg-carmimEscuro text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Exportar Recursos para Nova Planilha Google Sheets
              </button>

              <div className="pt-2 border-t border-linha space-y-2">
                <label className="block text-[11px] font-semibold text-suave uppercase">
                  Ou inspecionar Planilha por ID (Spreadsheet ID)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={sheetIdInput}
                    onChange={(e) => setSheetIdInput(e.target.value)}
                    placeholder="ID da planilha Google Sheets..."
                    className={CLASSE_INPUT}
                  />
                  <button
                    type="button"
                    onClick={carregarPlanilhaExistente}
                    disabled={carregandoSheets}
                    className="px-3 py-2 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
                  >
                    {carregandoSheets ? '...' : 'Ler'}
                  </button>
                </div>

                {metaPlanilha && (
                  <div className="p-3 rounded-md border border-linha bg-fundo/50 space-y-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <strong className="text-tinta truncate">{metaPlanilha.titulo}</strong>
                      <a
                        href={metaPlanilha.spreadsheetUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="shrink-0 text-verde font-semibold hover:underline"
                      >
                        Abrir Sheets ↗
                      </a>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {metaPlanilha.abas.map((ab) => (
                        <button
                          key={ab.sheetId}
                          type="button"
                          onClick={() => trocarAbaPlanilha(ab.title)}
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer ${
                            abaSelecionada === ab.title
                              ? 'bg-carmim text-white'
                              : 'bg-white border border-linha text-suave'
                          }`}
                        >
                          {ab.title}
                        </button>
                      ))}
                    </div>
                    <p className="text-[11px] text-suave">
                      Linhas lidas na aba <strong>{abaSelecionada}</strong>: {linhasAba.length}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* 3. GOOGLE FORMS */}
          <section className="bg-white border border-linha rounded-lg p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 border-b border-linha pb-2.5">
                <h4 className="text-sm font-bold text-tinta">3. Google Forms (Formulários)</h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900">
                  Forms API v1
                </span>
              </div>
              <p className="text-xs text-suave leading-relaxed">
                Crie um formulário espelho no Google Forms para o Prêmio TJAC de Qualidade 2026 ou
                consulte respostas de um formulário existente pelo ID.
              </p>

              <button
                type="button"
                onClick={solicitarCriacaoFormularioForms}
                className="w-full px-3.5 py-2 rounded-md border border-carmim text-carmim hover:bg-carmim hover:text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Criar Formulário Espelho no Google Forms
              </button>

              <div className="pt-2 border-t border-linha space-y-2">
                <label className="block text-[11px] font-semibold text-suave uppercase">
                  Consultar Formulário Google por ID (Form ID)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formIdInput}
                    onChange={(e) => setFormIdInput(e.target.value)}
                    placeholder="ID do Google Form..."
                    className={CLASSE_INPUT}
                  />
                  <button
                    type="button"
                    onClick={carregarFormularioExistente}
                    disabled={carregandoForms}
                    className="px-3 py-2 rounded-md border border-linha bg-fundo hover:bg-linha/60 text-xs font-semibold text-tinta cursor-pointer"
                  >
                    {carregandoForms ? '...' : 'Consultar'}
                  </button>
                </div>

                {dadosForm && (
                  <div className="p-3 rounded-md border border-linha bg-fundo/50 space-y-1.5 text-xs">
                    <p className="font-bold text-tinta">{dadosForm.titulo}</p>
                    <p className="text-suave">
                      Questões: <strong>{dadosForm.qtdQuestoes}</strong> · Respostas recebidas:{' '}
                      <strong>{dadosForm.qtdRespostas}</strong>
                    </p>
                    <a
                      href={dadosForm.responderUri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block text-carmim font-semibold hover:underline"
                    >
                      Abrir Formulário no Google Forms ↗
                    </a>
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
