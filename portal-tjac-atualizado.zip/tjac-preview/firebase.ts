import { initializeApp, getApps } from 'firebase/app';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import firebaseConfig from './firebase-applet-config.json';

export const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
export const storage = getStorage(app);

export { firebaseConfig, ref, uploadBytes, getDownloadURL };
