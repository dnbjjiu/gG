import {
  PASTA_PROTOCOLO_DRIVE_URL,
  PASTA_RAIZ_DRIVE_URL,
  PROTOCOLO_FOLDER_ID,
  ROOT_FOLDER_ID,
} from '../../config';
import type { RecursoAdmin } from '../../types';

/**
 * ID oficial da Pasta Raiz de Evidências no Google Drive
 * https://drive.google.com/drive/folders/1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv?usp=sharing
 */
export const DRIVE_ROOT_FOLDER_ID = ROOT_FOLDER_ID; // '1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv'
export const DRIVE_PROTOCOLO_FOLDER_ID = PROTOCOLO_FOLDER_ID; // '1GUF4-048uLdkuZIdSTIwO7OyMxQX8bsB'
export const DRIVE_FOLDER_MIME = 'application/vnd.google-apps.folder';

export interface DriveEvidenciaItem {
  id: string;
  name: string;
  mimeType: string;
  size?: number;
  webViewLink: string;
  webContentLink?: string;
  parents?: string[];
  createdTime?: string;
  modifiedTime?: string;
  md5Checksum?: string;
  sha256Checksum?: string;
}

export interface PastaIndicadorOrganizada {
  pastaId: string;
  nomePasta: string;
  itemN: number;
  sigla: string;
  webViewLink: string;
  arquivos: DriveEvidenciaItem[];
  totalBytes: number;
}

export interface PastaProtocoloOrganizada {
  pastaId: string;
  protocolo: string;
  webViewLink: string;
  indicadores: PastaIndicadorOrganizada[];
  arquivosSoltos: DriveEvidenciaItem[];
  totalArquivos: number;
  totalBytes: number;
}

export interface PastaUnidadeOrganizada {
  pastaId: string;
  codigoUnidade: string;
  nomeUnidade: string;
  webViewLink: string;
  protocolos: PastaProtocoloOrganizada[];
  totalArquivos: number;
  totalBytes: number;
}

export interface ArvoreEvidenciasDrive {
  rootFolderId: string;
  rootFolderUrl: string;
  sincronizadoEm: string;
  unidades: PastaUnidadeOrganizada[];
  arquivosRaiz: DriveEvidenciaItem[];
  totalUnidades: number;
  totalProtocolos: number;
  totalArquivos: number;
  totalBytes: number;
}

interface DriveApiRawFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string | number;
  webViewLink?: string;
  webContentLink?: string;
  parents?: string[];
  createdTime?: string;
  modifiedTime?: string;
  md5Checksum?: string;
  sha256Checksum?: string;
}

/**
 * Extrai código e nome da unidade a partir do padrão de pasta "[CODIGO] - [NOME DA UNIDADE]"
 */
export function extrairCodigoENomeUnidade(nomePasta: string): {
  codigoUnidade: string;
  nomeUnidade: string;
} {
  const limpo = String(nomePasta || '').trim();
  const idx = limpo.indexOf(' - ');
  if (idx > 0) {
    return {
      codigoUnidade: limpo.slice(0, idx).trim(),
      nomeUnidade: limpo.slice(idx + 3).trim(),
    };
  }
  return {
    codigoUnidade: 'UNID',
    nomeUnidade: limpo || 'Unidade Judiciária',
  };
}

/**
 * Extrai o número do item e a sigla do indicador a partir do padrão de subpasta "01_IAD-C"
 */
export function extrairItemNSiglaIndicador(nomePasta: string): {
  itemN: number;
  sigla: string;
} {
  const limpo = String(nomePasta || '').trim();
  const match = limpo.match(/^0*(\d+)[_-](.+)$/);
  if (match) {
    return {
      itemN: Number(match[1]) || 1,
      sigla: match[2].trim(),
    };
  }
  return {
    itemN: 1,
    sigla: limpo || 'INDICADOR',
  };
}

/**
 * Constrói a query `q` da API do Google Drive v3 vinculada a uma pasta (por padrão, 1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv)
 */
export function construirQueryFilhosPasta(
  folderId: string = DRIVE_ROOT_FOLDER_ID,
  opcoes?: {
    apenasPastas?: boolean;
    apenasArquivos?: boolean;
    termoBusca?: string;
  }
): string {
  const safeFolderId = (folderId || DRIVE_ROOT_FOLDER_ID).trim().replace(/['\\]/g, '');
  const partes: string[] = [`'${safeFolderId}' in parents`, 'trashed = false'];

  if (opcoes?.apenasPastas) {
    partes.push(`mimeType = '${DRIVE_FOLDER_MIME}'`);
  } else if (opcoes?.apenasArquivos) {
    partes.push(`mimeType != '${DRIVE_FOLDER_MIME}'`);
  }

  if (opcoes?.termoBusca && opcoes.termoBusca.trim()) {
    const termoSeguro = opcoes.termoBusca.trim().replace(/['\\]/g, '');
    partes.push(`name contains '${termoSeguro}'`);
  }

  return partes.join(' and ');
}

function normalizarItemDrive(raw: DriveApiRawFile): DriveEvidenciaItem {
  const ehPasta = raw.mimeType === DRIVE_FOLDER_MIME;
  const fallbackUrl = ehPasta
    ? `https://drive.google.com/drive/folders/${raw.id}`
    : `https://drive.google.com/file/d/${raw.id}/view`;
  return {
    id: raw.id,
    name: raw.name,
    mimeType: raw.mimeType,
    size: raw.size !== undefined ? Number(raw.size) : undefined,
    webViewLink: raw.webViewLink || fallbackUrl,
    webContentLink: raw.webContentLink,
    parents: raw.parents,
    createdTime: raw.createdTime,
    modifiedTime: raw.modifiedTime,
    md5Checksum: raw.md5Checksum,
    sha256Checksum: raw.sha256Checksum,
  };
}

/**
 * Lista arquivos e/ou subpastas diretamente filhos de uma pasta no Google Drive
 * (usa por padrão o ID da pasta raiz 1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv).
 */
export async function listarFilhosPastaDrive(
  accessToken: string,
  folderId: string = DRIVE_ROOT_FOLDER_ID,
  opcoes?: {
    apenasPastas?: boolean;
    apenasArquivos?: boolean;
    termoBusca?: string;
    pageSize?: number;
  }
): Promise<DriveEvidenciaItem[]> {
  const q = encodeURIComponent(construirQueryFilhosPasta(folderId, opcoes));
  const pageSize = opcoes?.pageSize || 100;
  const fields = encodeURIComponent(
    'files(id,name,mimeType,size,webViewLink,webContentLink,parents,createdTime,modifiedTime,md5Checksum,sha256Checksum)'
  );
  const url = `https://www.googleapis.com/drive/v3/files?q=${q}&pageSize=${pageSize}&orderBy=folder,name&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${fields}`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(
      `Erro ao consultar pasta ${folderId} no Google Drive (${res.status}): ${errText.slice(0, 180)}`
    );
  }

  const data = await res.json();
  const files: DriveApiRawFile[] = Array.isArray(data.files) ? data.files : [];
  return files.map(normalizarItemDrive);
}

/**
 * Lista arquivos de evidências na Pasta Raiz (1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv)
 * ou pesquisa arquivos por nome no Drive.
 */
export async function listarEvidenciasPastaRaiz(
  accessToken: string,
  termoBusca = '',
  folderId: string = DRIVE_ROOT_FOLDER_ID
): Promise<DriveEvidenciaItem[]> {
  const filhosRaiz = await listarFilhosPastaDrive(accessToken, folderId, {
    termoBusca,
    pageSize: 100,
  });
  if (filhosRaiz.length > 0 || !termoBusca.trim()) {
    return filhosRaiz;
  }

  // Fallback de busca ampla quando o arquivo está dentro de subpasta de protocolo/indicador
  const seguro = termoBusca.trim().replace(/['\\]/g, '');
  const q = encodeURIComponent(`trashed = false and name contains '${seguro}'`);
  const fields = encodeURIComponent(
    'files(id,name,mimeType,size,webViewLink,webContentLink,parents,createdTime,modifiedTime,md5Checksum,sha256Checksum)'
  );
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&pageSize=50&orderBy=modifiedTime desc&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${fields}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Erro ao pesquisar no Google Drive (${res.status}): ${errText.slice(0, 180)}`);
  }
  const data = await res.json();
  const files: DriveApiRawFile[] = Array.isArray(data.files) ? data.files : [];
  return files.map(normalizarItemDrive);
}

/**
 * Organiza uma lista de itens (pastas e arquivos com `parents`) na árvore institucional:
 * Pasta Raiz (1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv) -> Unidade -> Protocolo -> Indicador -> Evidências
 */
export function organizarItensDrivePorEstrutura(
  itens: DriveEvidenciaItem[],
  rootFolderId: string = DRIVE_ROOT_FOLDER_ID
): ArvoreEvidenciasDrive {
  const pastasPorId = new Map<string, DriveEvidenciaItem>();
  const filhosPorParent = new Map<string, DriveEvidenciaItem[]>();

  for (const item of itens) {
    if (item.mimeType === DRIVE_FOLDER_MIME) {
      pastasPorId.set(item.id, item);
    }
    const parents = item.parents && item.parents.length > 0 ? item.parents : [rootFolderId];
    for (const pid of parents) {
      const lista = filhosPorParent.get(pid) || [];
      lista.push(item);
      filhosPorParent.set(pid, lista);
    }
  }

  const filhosRaiz = filhosPorParent.get(rootFolderId) || [];
  const pastasNivel1 = filhosRaiz.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);
  const arquivosRaiz = filhosRaiz.filter((i) => i.mimeType !== DRIVE_FOLDER_MIME);

  const unidades: PastaUnidadeOrganizada[] = [];
  let totalProtocolos = 0;
  let totalArquivos = arquivosRaiz.length;
  let totalBytes = arquivosRaiz.reduce((acc, a) => acc + (a.size || 0), 0);

  for (const pUnid of pastasNivel1) {
    const { codigoUnidade, nomeUnidade } = extrairCodigoENomeUnidade(pUnid.name);
    const filhosUnid = filhosPorParent.get(pUnid.id) || [];
    const pastasProt = filhosUnid.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);

    const protocolos: PastaProtocoloOrganizada[] = [];
    let arqUnid = 0;
    let bytesUnid = 0;

    for (const pProt of pastasProt) {
      const filhosProt = filhosPorParent.get(pProt.id) || [];
      const pastasInd = filhosProt.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);
      const arquivosSoltos = filhosProt.filter((i) => i.mimeType !== DRIVE_FOLDER_MIME);

      const indicadores: PastaIndicadorOrganizada[] = pastasInd.map((pInd) => {
        const { itemN, sigla } = extrairItemNSiglaIndicador(pInd.name);
        const arquivos = (filhosPorParent.get(pInd.id) || []).filter(
          (i) => i.mimeType !== DRIVE_FOLDER_MIME
        );
        const bytesInd = arquivos.reduce((acc, a) => acc + (a.size || 0), 0);
        return {
          pastaId: pInd.id,
          nomePasta: pInd.name,
          itemN,
          sigla,
          webViewLink: pInd.webViewLink,
          arquivos,
          totalBytes: bytesInd,
        };
      });

      indicadores.sort((a, b) => a.itemN - b.itemN);

      const qtdArqsProt =
        arquivosSoltos.length + indicadores.reduce((acc, ind) => acc + ind.arquivos.length, 0);
      const bytesProt =
        arquivosSoltos.reduce((acc, a) => acc + (a.size || 0), 0) +
        indicadores.reduce((acc, ind) => acc + ind.totalBytes, 0);

      protocolos.push({
        pastaId: pProt.id,
        protocolo: pProt.name,
        webViewLink: pProt.webViewLink,
        indicadores,
        arquivosSoltos,
        totalArquivos: qtdArqsProt,
        totalBytes: bytesProt,
      });

      totalProtocolos += 1;
      arqUnid += qtdArqsProt;
      bytesUnid += bytesProt;
    }

    unidades.push({
      pastaId: pUnid.id,
      codigoUnidade,
      nomeUnidade,
      webViewLink: pUnid.webViewLink,
      protocolos,
      totalArquivos: arqUnid,
      totalBytes: bytesUnid,
    });

    totalArquivos += arqUnid;
    totalBytes += bytesUnid;
  }

  return {
    rootFolderId,
    rootFolderUrl:
      rootFolderId === DRIVE_ROOT_FOLDER_ID
        ? PASTA_RAIZ_DRIVE_URL
        : `https://drive.google.com/drive/folders/${rootFolderId}`,
    sincronizadoEm: new Date().toISOString(),
    unidades,
    arquivosRaiz,
    totalUnidades: unidades.length,
    totalProtocolos,
    totalArquivos,
    totalBytes,
  };
}

/**
 * Constrói a árvore organizada de evidências no padrão do Google Drive a partir dos
 * protocolos cadastrados no sistema (vinculados à Pasta Raiz 1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv).
 */
export function construirArvoreEvidenciasDeRecursos(
  recursos: RecursoAdmin[],
  rootFolderId: string = DRIVE_ROOT_FOLDER_ID
): ArvoreEvidenciasDrive {
  const mapaUnidades = new Map<string, PastaUnidadeOrganizada>();
  let totalProtocolos = 0;
  let totalArquivos = 0;
  let totalBytes = 0;

  for (const r of recursos) {
    const cod = r.unidade.codigo || 'UNID';
    const chaveUnidade = `${cod} - ${r.unidade.nome}`;
    let unid = mapaUnidades.get(chaveUnidade);
    if (!unid) {
      unid = {
        pastaId: `folder-unid-${cod}`,
        codigoUnidade: cod,
        nomeUnidade: r.unidade.nome,
        webViewLink: r.pastaUrl || PASTA_RAIZ_DRIVE_URL,
        protocolos: [],
        totalArquivos: 0,
        totalBytes: 0,
      };
      mapaUnidades.set(chaveUnidade, unid);
    }

    const indicadores: PastaIndicadorOrganizada[] = r.itens.map((it) => {
      const nomePasta = `${('0' + it.itemN).slice(-2)}_${it.sigla}`;
      const arquivos: DriveEvidenciaItem[] = it.arquivos.map((a) => ({
        id: a.fileId,
        name: a.nome,
        mimeType: a.mime,
        size: a.bytes,
        webViewLink: a.url || PASTA_PROTOCOLO_DRIVE_URL,
        modifiedTime: a.enviadoEm,
        sha256Checksum: a.sha256,
      }));
      const bytesInd = arquivos.reduce((acc, a) => acc + (a.size || 0), 0);
      return {
        pastaId: `folder-${r.protocolo}-${nomePasta}`,
        nomePasta,
        itemN: it.itemN,
        sigla: it.sigla,
        webViewLink: it.pastaItemUrl || r.pastaUrl || PASTA_PROTOCOLO_DRIVE_URL,
        arquivos,
        totalBytes: bytesInd,
      };
    });

    const arqsProt = indicadores.reduce((acc, i) => acc + i.arquivos.length, 0);
    const bytesProt = indicadores.reduce((acc, i) => acc + i.totalBytes, 0);

    unid.protocolos.push({
      pastaId: r.pastaId || DRIVE_PROTOCOLO_FOLDER_ID,
      protocolo: r.protocolo,
      webViewLink: r.pastaUrl || PASTA_PROTOCOLO_DRIVE_URL,
      indicadores,
      arquivosSoltos: [],
      totalArquivos: arqsProt,
      totalBytes: bytesProt,
    });

    unid.totalArquivos += arqsProt;
    unid.totalBytes += bytesProt;
    totalProtocolos += 1;
    totalArquivos += arqsProt;
    totalBytes += bytesProt;
  }

  const unidades = Array.from(mapaUnidades.values());
  return {
    rootFolderId,
    rootFolderUrl:
      rootFolderId === DRIVE_ROOT_FOLDER_ID
        ? PASTA_RAIZ_DRIVE_URL
        : `https://drive.google.com/drive/folders/${rootFolderId}`,
    sincronizadoEm: new Date().toISOString(),
    unidades,
    arquivosRaiz: [],
    totalUnidades: unidades.length,
    totalProtocolos,
    totalArquivos,
    totalBytes,
  };
}

/**
 * Busca uma subpasta pelo nome dentro de `parentId` ou a cria caso ainda não exista,
 * evitando duplicação de pastas ao organizar as evidências no Google Drive.
 */
export async function obterOuCriarSubpastaDrive(
  accessToken: string,
  nome: string,
  parentId: string = DRIVE_ROOT_FOLDER_ID
): Promise<{ id: string; name: string; webViewLink: string }> {
  const nomeLimpo = nome.trim();
  const safeParent = parentId.trim().replace(/['\\]/g, '');
  const safeName = nomeLimpo.replace(/['\\]/g, '');
  const q = encodeURIComponent(
    `'${safeParent}' in parents and mimeType = '${DRIVE_FOLDER_MIME}' and name = '${safeName}' and trashed = false`
  );
  const fields = encodeURIComponent('files(id,name,webViewLink)');

  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&pageSize=1&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${fields}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (searchRes.ok) {
    const searchData = await searchRes.json();
    if (Array.isArray(searchData.files) && searchData.files.length > 0) {
      const existente = searchData.files[0];
      return {
        id: existente.id,
        name: existente.name,
        webViewLink:
          existente.webViewLink || `https://drive.google.com/drive/folders/${existente.id}`,
      };
    }
  }

  const createRes = await fetch(
    'https://www.googleapis.com/drive/v3/files?supportsAllDrives=true&fields=id,name,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: nomeLimpo,
        mimeType: DRIVE_FOLDER_MIME,
        parents: [parentId],
      }),
    }
  );

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(
      `Falha ao criar subpasta "${nomeLimpo}" no Google Drive (${createRes.status}): ${errText.slice(0, 180)}`
    );
  }

  const created = await createRes.json();
  return {
    id: created.id,
    name: created.name || nomeLimpo,
    webViewLink: created.webViewLink || `https://drive.google.com/drive/folders/${created.id}`,
  };
}

/**
 * Percorre a Pasta Raiz (1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv) na API do Google Drive
 * e retorna a árvore completa de pastas e arquivos de evidências organizados.
 */
export async function carregarArvoreEvidenciasDrive(
  accessToken: string,
  rootFolderId: string = DRIVE_ROOT_FOLDER_ID
): Promise<ArvoreEvidenciasDrive> {
  const todosItens: DriveEvidenciaItem[] = [];
  const nivel1 = await listarFilhosPastaDrive(accessToken, rootFolderId);
  todosItens.push(...nivel1);

  const pastasUnidade = nivel1.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);
  for (const pUnid of pastasUnidade) {
    const nivel2 = await listarFilhosPastaDrive(accessToken, pUnid.id);
    todosItens.push(...nivel2);

    const pastasProtocolo = nivel2.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);
    for (const pProt of pastasProtocolo) {
      const nivel3 = await listarFilhosPastaDrive(accessToken, pProt.id);
      todosItens.push(...nivel3);

      const pastasIndicador = nivel3.filter((i) => i.mimeType === DRIVE_FOLDER_MIME);
      for (const pInd of pastasIndicador) {
        const nivel4 = await listarFilhosPastaDrive(accessToken, pInd.id);
        todosItens.push(...nivel4);
      }
    }
  }

  return organizarItensDrivePorEstrutura(todosItens, rootFolderId);
}

/**
 * Garante e organiza a hierarquia completa de pastas de evidências dentro da Pasta Raiz
 * (`1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv`) para todos os recursos informados:
 * `[Pasta Raiz] / [Código - Unidade] / [Protocolo] / [01_SIGLA]`
 */
export async function organizarEvidenciasNoDrive(
  accessToken: string,
  recursos: RecursoAdmin[],
  rootFolderId: string = DRIVE_ROOT_FOLDER_ID
): Promise<{
  rootFolderId: string;
  rootFolderUrl: string;
  pastasVerificadasOuCriadas: number;
  arvore: ArvoreEvidenciasDrive;
}> {
  let pastasVerificadasOuCriadas = 0;

  for (const r of recursos) {
    const nomeUnidade = `${r.unidade.codigo || 'UNID'} - ${r.unidade.nome}`;
    const pastaUnidade = await obterOuCriarSubpastaDrive(accessToken, nomeUnidade, rootFolderId);
    const pastaProtocolo = await obterOuCriarSubpastaDrive(
      accessToken,
      r.protocolo,
      pastaUnidade.id
    );
    pastasVerificadasOuCriadas += 2;

    for (const it of r.itens) {
      const subNome = `${('0' + it.itemN).slice(-2)}_${it.sigla.replace(/[\\/:*?"<>|]/g, '_')}`;
      await obterOuCriarSubpastaDrive(accessToken, subNome, pastaProtocolo.id);
      pastasVerificadasOuCriadas += 1;
    }
  }

  const arvore = await carregarArvoreEvidenciasDrive(accessToken, rootFolderId);
  return {
    rootFolderId,
    rootFolderUrl: arvore.rootFolderUrl,
    pastasVerificadasOuCriadas,
    arvore,
  };
}
