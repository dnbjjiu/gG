import test from 'node:test';
import assert from 'node:assert/strict';
import { INDICADORES_CATALOGO, TIPOS_IMPUGNACAO_INFO, TIPOS_UNIDADE_INFO, indicadoresParaUnidade } from './catalogo';
import { LIMITES_PADRAO, ehAdmin, podeAtuarComoComissao, podeAtuarComoSumae } from './config';
import {
  gerarPdfDecisaoComissaoSei,
  gerarPdfParecerTecnicoSei,
  resolverVinculoSeiProtocolo,
  validarEmissaoDecisaoComissao,
  validarEmissaoParecerSumae,
} from './services/analiseLogica';
import { api } from './services/api';
import { criarTokenDemo, lerToken, tokenValido } from './services/auth';
import { cpfValido, formatarCpf, formatarTelefone, validarPayloadRecurso } from './utils';
import {
  DRIVE_ROOT_FOLDER_ID,
  construirArvoreEvidenciasDeRecursos,
  construirQueryFilhosPasta,
  extrairCodigoENomeUnidade,
  extrairItemNSiglaIndicador,
  organizarItensDrivePorEstrutura,
} from './src/services/drive';

const TIPOS_UNIDADE_CODE_GS = [
  'CIVEL', 'FAMILIA', 'FAZENDA', 'EXEC_FISCAL', 'CRIMINAL', 'JURI', 'ROUBO', 'VIOL_DOM',
  'INFANCIA', 'VEP', 'JEC', 'JECRIM', 'JEFAZ', 'TURMA_RECURSAL', 'VARA_UNICA', 'GARANTIAS',
  'GAB_CIVEL', 'GAB_CRIMINAL', 'VICE_PRESIDENCIA', 'SEJUD',
];

const TIPOS_IMPUGNACAO_CODE_GS = [
  'APURACAO', 'APLICABILIDADE', 'FAIXA_ARREDONDAMENTO', 'FONTE_DADOS', 'OUTRO',
];

test('CPF validation and formatting match Code.gs rules', () => {
  assert.equal(cpfValido('52998224725'), true);
  assert.equal(cpfValido('529.982.247-25'), true);
  assert.equal(cpfValido('111.111.111-11'), false);
  assert.equal(cpfValido('123.456.789-00'), false);
  assert.equal(formatarCpf('52998224725'), '529.982.247-25');
  assert.equal(formatarTelefone('6832128200'), '(68) 3212-8200');
});

test('All catalog siglas and unit/impugnation types strictly match Code.gs validation rules', () => {
  for (const ind of INDICADORES_CATALOGO) {
    assert.match(ind.sigla, /^[A-Za-z0-9/\-]{2,30}$/, `Invalid sigla for Code.gs: ${ind.sigla}`);
  }
  assert.deepEqual(
    TIPOS_UNIDADE_INFO.map((t) => t.codigo),
    TIPOS_UNIDADE_CODE_GS
  );
  assert.deepEqual(
    TIPOS_IMPUGNACAO_INFO.map((t) => t.codigo),
    TIPOS_IMPUGNACAO_CODE_GS
  );
});

test('Indicator filtering separates 1G, 2G Gabinetes, Vice-Presidência, and SEJUD properly', () => {
  const ind1G = indicadoresParaUnidade('1G', 'CIVEL').map((i) => i.sigla);
  assert.ok(ind1G.includes('IAD-C'));
  assert.ok(!ind1G.includes('ISJ'));
  assert.ok(!ind1G.includes('IAD-VPRES'));

  const indVpres = indicadoresParaUnidade('2G', 'VICE_PRESIDENCIA').map((i) => i.sigla);
  assert.deepEqual(indVpres, ['IAD-VPRES', 'TPL-VPRES', 'TPL-Saude-VPRES', 'ISU-VPRES']);

  const indSejud = indicadoresParaUnidade('2G', 'SEJUD').map((i) => i.sigla);
  assert.deepEqual(indSejud, ['ISJ']);
});

test('Demo JWT token creation and decoding round-trip', () => {
  const tok = criarTokenDemo({ nome: 'Juiz Teste', email: 'juiz@tjac.jus.br' });
  const u = lerToken(tok);
  assert.equal(u.email, 'juiz@tjac.jus.br');
  assert.equal(u.nome, 'Juiz Teste');
  assert.equal(tokenValido(u), true);
});

test('Administrator recognition and adminList / adminUpdateItem work for josue.silva@tjac.jus.br and josuemdr@gmail.com', async () => {
  assert.equal(ehAdmin('josue.silva@tjac.jus.br'), true);
  assert.equal(ehAdmin('JOSUE.SILVA@TJAC.JUS.BR'), true);
  assert.equal(ehAdmin('josuemdr@gmail.com'), true);
  assert.equal(ehAdmin('unidade.recurso@tjac.jus.br'), false);

  const tokenAdmin1 = criarTokenDemo({ nome: 'Josué Silva', email: 'josue.silva@tjac.jus.br' });
  const tokenAdmin2 = criarTokenDemo({ nome: 'Josué Silva', email: 'josuemdr@gmail.com' });
  const tokenComum = criarTokenDemo({ nome: 'Unidade', email: 'unidade@tjac.jus.br' });

  const list1 = await api.adminList(tokenAdmin1);
  assert.ok(list1.recursos.length >= 4);
  assert.equal(
    list1.pastaRaizUrl,
    'https://drive.google.com/drive/folders/1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv?usp=sharing'
  );
  assert.equal(
    list1.recursos[0].pastaUrl,
    'https://drive.google.com/drive/folders/1GUF4-048uLdkuZIdSTIwO7OyMxQX8bsB?usp=sharing'
  );
  assert.ok(list1.recursos[0].itens[0].arquivos.length >= 1);

  const list2 = await api.adminList(tokenAdmin2);
  assert.equal(list2.recursos.length, list1.recursos.length);

  await assert.rejects(() => api.adminList(tokenComum), /Acesso restrito aos administradores/);

  const upd = await api.adminUpdateItem(tokenAdmin1, {
    protocolo: 'RTQ-2026-00001',
    itemN: 1,
    statusAnalise: 'PROVIDO',
    relator: 'Josué Silva (DIGED)',
    parecer: 'Conferido no DataJud e BI PJAC.',
    decisao: 'Recurso provido integralmente.',
    pontuacaoFinal: 120,
  });
  assert.equal(upd.ok, true);
});

test('Appeal payload validation catches missing evidences, short justification, and accepts valid appeal', () => {
  const basePayload = {
    clientRequestId: 'req-1234567890',
    declaracao: true,
    responsavel: {
      nome: 'Dra. Helena Albuquerque',
      cpf: '52998224725',
      cargo: 'Juíza de Direito Titular',
      telefone: '(68) 3212-8200',
    },
    unidade: {
      grau: '1G' as const,
      tipo: 'CIVEL' as const,
      codigo: 'RB-1CIV',
      nome: '1ª Vara Cível da Comarca de Rio Branco',
      comarca: 'Rio Branco',
    },
    listaServidores: {
      impugna: false,
      texto: '',
    },
    itens: [
      {
        grupo: '1º Grau — Indicadores Gerais',
        sigla: 'IAD-C',
        indicador: 'Índice de Atendimento à Demanda — Critério Conjugado',
        subitem: 'Apuração Geral do IAD-C',
        tipoImpugnacao: 'APURACAO' as const,
        pontuacaoPreliminar: 60,
        pontuacaoPleiteada: 120,
        fundamentacao:
          'Conforme extrato do Painel de BI do PJAC na data de corte de 30/11/2026, a unidade obteve IAD de 102,4% com 1.500 processos baixados para 1.464 casos novos.',
        evidencias: { a: true, b: true, c: true, d: true, e: true },
      },
    ],
  };

  assert.deepEqual(validarPayloadRecurso(basePayload, LIMITES_PADRAO), []);

  const invalido = {
    ...basePayload,
    itens: [
      {
        ...basePayload.itens[0],
        fundamentacao: 'Texto muito curto',
        evidencias: { a: true, b: true, c: true, d: false, e: true },
      },
    ],
  };
  const erros = validarPayloadRecurso(invalido, LIMITES_PADRAO);
  assert.equal(erros.length, 2);
});

test('Firebase Storage instance and evidence path builder work as expected', async () => {
  const { storage } = await import('./firebase');
  const { construirCaminhoStorageEvidencia } = await import('./services/storage');
  assert.ok(storage);
  const path = construirCaminhoStorageEvidencia({
    protocolo: 'RTQ-2026-00001',
    codUnidade: 'RB-1CIV',
    itemN: 1,
    sigla: 'IAD-C',
    nomeArquivo: 'Evidencia Painel BI.pdf',
  });
  assert.equal(
    path,
    'recursos-premio-tjac-2026/RB-1CIV/RTQ-2026-00001/01_IAD-C/Evidencia Painel BI.pdf'
  );
});

test('Análise do Recurso: SEI process linkage reuses existing SEI number and enforces permissions', async () => {
  const tokenSumae = criarTokenDemo({
    nome: 'Analista SUMAE',
    email: 'sumae.analise@tjac.jus.br',
  });
  const tokenComissao = criarTokenDemo({
    nome: 'Membro Comissão',
    email: 'comissao.revisora@tjac.jus.br',
  });
  const tokenUnidade = criarTokenDemo({
    nome: 'Unidade Recorrente',
    email: 'unidade.recurso@tjac.jus.br',
  });

  assert.equal(podeAtuarComoSumae('sumae.analise@tjac.jus.br'), true);
  assert.equal(podeAtuarComoComissao('sumae.analise@tjac.jus.br'), false);
  assert.equal(podeAtuarComoComissao('comissao.revisora@tjac.jus.br'), true);
  assert.equal(podeAtuarComoSumae('comissao.revisora@tjac.jus.br'), false);

  const r1 = resolverVinculoSeiProtocolo(
    'RTQ-2026-00004',
    '0013175-86.2026.8.01.0000',
    '0099999-00.2026.8.01.0000'
  );
  assert.equal(r1.reutilizado, true);
  assert.equal(r1.processoSei, '0013175-86.2026.8.01.0000');

  const vinc1 = await api.vincularProcessoSei(tokenSumae, {
    protocolo: 'RTQ-2026-00004',
    processoSei: '0013175-86.2026.8.01.0000',
  });
  assert.equal(vinc1.reutilizado, true);
  assert.equal(vinc1.processoSei, '0013175-86.2026.8.01.0000');

  await assert.rejects(
    () =>
      api.vincularProcessoSei(tokenUnidade, {
        protocolo: 'RTQ-2026-00004',
        processoSei: '0013175-86.2026.8.01.0000',
      }),
    /Apenas integrantes da SUMAE ou da Comissão Revisora/
  );

  // Confirm Commission cannot save SUMAE Parecer, and SUMAE cannot save Commission Decision
  const { analise } = await api.obterAnaliseRecurso(tokenSumae, 'RTQ-2026-00002');

  await assert.rejects(
    () =>
      api.salvarParecerSumae(tokenComissao, {
        protocolo: 'RTQ-2026-00002',
        processoSei: analise.processoSei,
        papelAtivo: 'SUMAE',
        acao: 'SALVAR_RASCUNHO',
        emissionRequestId: 'test-unauth-sumae',
        parecer: analise.parecerSumae,
      }),
    /restritas ao perfil SUMAE/
  );

  await assert.rejects(
    () =>
      api.salvarDecisaoComissao(tokenSumae, {
        protocolo: 'RTQ-2026-00002',
        processoSei: analise.processoSei,
        papelAtivo: 'COMISSAO',
        acao: 'SALVAR_RASCUNHO',
        emissionRequestId: 'test-unauth-comissao',
        decisao: analise.decisaoComissao,
      }),
    /restritas ao perfil Comissão Revisora/
  );
});

test('Análise do Recurso: Parecer Técnico da SUMAE emission, idempotency, rectification versioning, and SEI PDF generation', async () => {
  const tokenSumae = criarTokenDemo({
    nome: 'Analista SUMAE',
    email: 'sumae.analise@tjac.jus.br',
  });

  const { recurso, analise } = await api.obterAnaliseRecurso(tokenSumae, 'RTQ-2026-00002');

  // 1. Emitir v1 e encaminhar à Comissão
  const res1 = await api.salvarParecerSumae(tokenSumae, {
    protocolo: 'RTQ-2026-00002',
    processoSei: analise.processoSei,
    papelAtivo: 'SUMAE',
    acao: 'EMITIR_ENCAMINHAR',
    emissionRequestId: 'emit-sumae-rtq2-v1',
    parecer: {
      ...analise.parecerSumae,
      responsavelNome: 'Analista SUMAE',
      responsavelCargo: 'Assessor(a) Técnico(a) SUMAE',
    },
  });
  assert.equal(res1.reaproveitado, false);
  assert.equal(res1.analise.parecerSumae.versao, 1);
  assert.equal(res1.analise.parecerSumae.statusDocumento, 'EMITIDO');
  assert.equal(res1.analise.estadoTramitacao, 'ENCAMINHADO_COMISSAO');

  // 2. Idempotency: repetir mesmo emissionRequestId não duplica versão
  const resDup = await api.salvarParecerSumae(tokenSumae, {
    protocolo: 'RTQ-2026-00002',
    processoSei: analise.processoSei,
    papelAtivo: 'SUMAE',
    acao: 'EMITIR_ENCAMINHAR',
    emissionRequestId: 'emit-sumae-rtq2-v1',
    parecer: res1.analise.parecerSumae,
  });
  assert.equal(resDup.reaproveitado, true);
  assert.equal(resDup.analise.parecerSumae.versao, 1);

  // 3. Retificação (v2) sem justificativa deve falhar
  await assert.rejects(
    () =>
      api.salvarParecerSumae(tokenSumae, {
        protocolo: 'RTQ-2026-00002',
        processoSei: analise.processoSei,
        papelAtivo: 'SUMAE',
        acao: 'EMITIR_ENCAMINHAR',
        emissionRequestId: 'emit-sumae-rtq2-v2-sem-just',
        parecer: {
          ...res1.analise.parecerSumae,
          justificativaRetificacao: '',
        },
      }),
    /é obrigatório informar a justificativa da retificação/
  );

  // 4. Retificação (v2) com justificativa incrementa versão e preserva histórico
  const res2 = await api.salvarParecerSumae(tokenSumae, {
    protocolo: 'RTQ-2026-00002',
    processoSei: analise.processoSei,
    papelAtivo: 'SUMAE',
    acao: 'EMITIR_ENCAMINHAR',
    emissionRequestId: 'emit-sumae-rtq2-v2-ok',
    parecer: {
      ...res1.analise.parecerSumae,
      justificativaRetificacao: 'Complementação da conferência da listagem do SEEU com acréscimo de nota técnica.',
    },
  });
  assert.equal(res2.analise.parecerSumae.versao, 2);
  assert.equal(
    res2.analise.historicoDocumentos.filter((d) => d.tipo === 'PARECER_SUMAE').length,
    2
  );

  // 5. Gerar PDF fixo para juntada ao SEI
  const pdfBytes = gerarPdfParecerTecnicoSei(recurso, res2.analise);
  const cabecalhoPdf = new TextDecoder('latin1').decode(pdfBytes.slice(0, 8));
  const rodapePdf = new TextDecoder('latin1').decode(pdfBytes.slice(pdfBytes.length - 16));
  assert.ok(cabecalhoPdf.startsWith('%PDF-1.4'));
  assert.ok(rodapePdf.includes('%%EOF'));
});

test('Análise do Recurso: Decisão Final da Comissão enforces Não Conhecido when mandatory evidence is missing and allows full merit decision when known', async () => {
  const tokenComissao = criarTokenDemo({
    nome: 'Desembargador(a) Presidente da Comissão Revisora',
    email: 'comissao.revisora@tjac.jus.br',
  });

  // Caso 1: RTQ-2026-00004 (Vara Única da Comarca de Bujari) possui falta de evidência obrigatória (e)
  const { recurso: recBujari, analise: analiseBujari } = await api.obterAnaliseRecurso(
    tokenComissao,
    'RTQ-2026-00004'
  );
  assert.equal(analiseBujari.parecerSumae.possuiFaltaEvidenciaObrigatoria, true);
  assert.equal(analiseBujari.decisaoComissao.faltaEvidenciaObrigatoria, true);
  assert.equal(analiseBujari.decisaoComissao.resultadoGeral, 'NAO_CONHECIDO');

  // Tentar emitir como PROVIDO quando falta evidência obrigatória deve ser bloqueado pela validação
  const errosInvalido = validarEmissaoDecisaoComissao(
    recBujari,
    analiseBujari.parecerSumae,
    {
      ...analiseBujari.decisaoComissao,
      faltaEvidenciaObrigatoria: true,
      conhecido: true,
      resultadoGeral: 'PROVIDO',
    },
    0
  );
  assert.ok(
    errosInvalido.some((e) =>
      e.includes('resultado geral deve ser obrigatoriamente registrado como “Não conhecido”')
    )
  );

  // Emitir decisão final como NÃO CONHECIDO no RTQ-2026-00004
  const resBujari = await api.salvarDecisaoComissao(tokenComissao, {
    protocolo: 'RTQ-2026-00004',
    processoSei: analiseBujari.processoSei,
    papelAtivo: 'COMISSAO',
    acao: 'EMITIR_DECISAO',
    emissionRequestId: 'emit-decisao-bujari-v1',
    decisao: analiseBujari.decisaoComissao,
  });
  assert.equal(resBujari.analise.estadoTramitacao, 'DECIDIDO');
  assert.equal(resBujari.analise.decisaoComissao.resultadoGeral, 'NAO_CONHECIDO');
  assert.equal(resBujari.analise.decisaoComissao.conhecido, false);
  assert.equal(
    resBujari.analise.decisaoComissao.itensDecididos[0].resultadoItem,
    'NAO_CONHECIDO'
  );
  assert.equal(resBujari.analise.divulgacao.divulgado, false);

  // Gerar PDF da Decisão Final para juntada ao SEI
  const pdfDecisao = gerarPdfDecisaoComissaoSei(recBujari, resBujari.analise);
  const cabecalhoPdf = new TextDecoder('latin1').decode(pdfDecisao.slice(0, 8));
  assert.ok(cabecalhoPdf.startsWith('%PDF-1.4'));

  // Caso 2: RTQ-2026-00002 (VEP de Rio Branco) tem parecer emitido e todas as evidências — emitir decisão de mérito PROVIDO
  const { analise: analiseVep } = await api.obterAnaliseRecurso(tokenComissao, 'RTQ-2026-00002');
  const resVep = await api.salvarDecisaoComissao(tokenComissao, {
    protocolo: 'RTQ-2026-00002',
    processoSei: analiseVep.processoSei,
    papelAtivo: 'COMISSAO',
    acao: 'EMITIR_DECISAO',
    emissionRequestId: 'emit-decisao-vep-v1',
    decisao: {
      ...analiseVep.decisaoComissao,
      conhecido: true,
      faltaEvidenciaObrigatoria: false,
      resultadoGeral: 'PROVIDO',
    },
  });
  assert.equal(resVep.analise.estadoTramitacao, 'DECIDIDO');
  assert.equal(resVep.analise.decisaoComissao.conhecido, true);
  assert.equal(resVep.analise.decisaoComissao.resultadoGeral, 'PROVIDO');
});

test('src/services/drive.ts uses root folder ID 1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv and organizes evidence hierarchy accurately', async () => {
  assert.equal(DRIVE_ROOT_FOLDER_ID, '1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv');
  assert.equal(
    construirQueryFilhosPasta(DRIVE_ROOT_FOLDER_ID, { apenasPastas: true }),
    `'1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv' in parents and trashed = false and mimeType = 'application/vnd.google-apps.folder'`
  );

  assert.deepEqual(
    extrairCodigoENomeUnidade('RB-1CIV - 1ª Vara Cível da Comarca de Rio Branco'),
    { codigoUnidade: 'RB-1CIV', nomeUnidade: '1ª Vara Cível da Comarca de Rio Branco' }
  );
  assert.deepEqual(extrairItemNSiglaIndicador('01_IAD-C'), { itemN: 1, sigla: 'IAD-C' });

  const tokenAdmin = criarTokenDemo({ nome: 'Josué Silva', email: 'josue.silva@tjac.jus.br' });
  const { recursos } = await api.adminList(tokenAdmin);
  const arvore = construirArvoreEvidenciasDeRecursos(recursos);

  assert.equal(arvore.rootFolderId, '1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv');
  assert.ok(arvore.unidades.length >= 4);
  assert.ok(arvore.totalArquivos >= 6);
  assert.ok(arvore.unidades.some((u) => u.codigoUnidade === 'RB-1CIV'));

  const arvoreDrive = organizarItensDrivePorEstrutura(
    [
      {
        id: 'folder-u1',
        name: 'RB-1CIV - 1ª Vara Cível da Comarca de Rio Branco',
        mimeType: 'application/vnd.google-apps.folder',
        webViewLink: 'https://drive.google.com/drive/folders/folder-u1',
        parents: [DRIVE_ROOT_FOLDER_ID],
      },
      {
        id: 'folder-p1',
        name: 'RTQ-2026-00001',
        mimeType: 'application/vnd.google-apps.folder',
        webViewLink: 'https://drive.google.com/drive/folders/folder-p1',
        parents: ['folder-u1'],
      },
      {
        id: 'folder-i1',
        name: '01_IAD-C',
        mimeType: 'application/vnd.google-apps.folder',
        webViewLink: 'https://drive.google.com/drive/folders/folder-i1',
        parents: ['folder-p1'],
      },
      {
        id: 'file-ev1',
        name: 'Extrato_Painel_BI_IAD_1VaraCivel_RB.pdf',
        mimeType: 'application/pdf',
        size: 428190,
        webViewLink: 'https://drive.google.com/file/d/file-ev1/view',
        parents: ['folder-i1'],
      },
    ],
    DRIVE_ROOT_FOLDER_ID
  );

  assert.equal(arvoreDrive.unidades.length, 1);
  assert.equal(arvoreDrive.unidades[0].codigoUnidade, 'RB-1CIV');
  assert.equal(arvoreDrive.unidades[0].protocolos[0].protocolo, 'RTQ-2026-00001');
  assert.equal(arvoreDrive.unidades[0].protocolos[0].indicadores[0].sigla, 'IAD-C');
  assert.equal(arvoreDrive.unidades[0].protocolos[0].indicadores[0].arquivos.length, 1);
  assert.equal(arvoreDrive.totalArquivos, 1);
});


