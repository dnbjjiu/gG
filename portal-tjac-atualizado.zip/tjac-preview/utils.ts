import type { ConfigServidor, CriarRecursoPayload } from './types';

export function formatarDataHora(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  try {
    return (
      new Intl.DateTimeFormat('pt-BR', {
        timeZone: 'America/Rio_Branco',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }).format(d) + ' (horário do Acre)'
    );
  } catch {
    return d.toLocaleString('pt-BR');
  }
}

export function apenasDigitos(v: string): string {
  return String(v || '').replace(/\D/g, '');
}

export function formatarCpf(v: string): string {
  const d = apenasDigitos(v).slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return `${d.slice(0, 3)}.${d.slice(3)}`;
  if (d.length <= 9) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6)}`;
  return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9, 11)}`;
}

export function formatarTelefone(v: string): string {
  const d = apenasDigitos(v).slice(0, 11);
  if (!d) return '';
  if (d.length <= 2) return `(${d}`;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7, 11)}`;
}

export function cpfValido(cpf: string): boolean {
  const c = apenasDigitos(cpf);
  if (!/^\d{11}$/.test(c) || /^(\d)\1{10}$/.test(c)) return false;
  const dv = (base: string) => {
    let s = 0;
    for (let i = 0; i < base.length; i++) {
      s += Number(base[i]) * (base.length + 1 - i);
    }
    const r = (s * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return dv(c.slice(0, 9)) === Number(c[9]) && dv(c.slice(0, 10)) === Number(c[10]);
}

export function formatarBytes(bytes: number): string {
  if (!isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1).replace('.', ',')} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2).replace('.', ',')} MB`;
}

export function gerarIdRequisicao(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
  } catch {
    /* fallback abaixo */
  }
  const rand = Math.random().toString(36).slice(2, 10);
  return `req-${Date.now().toString(36)}-${rand}`;
}

export function numeroOuVazio(v: string | number | null | undefined): number | '' {
  if (v === '' || v == null) return '';
  const limpo = String(v).trim().replace(',', '.');
  if (!limpo) return '';
  const n = Number(limpo);
  return isFinite(n) && n >= 0 && n <= 1000 ? Number(n.toFixed(2)) : '';
}

export function arquivoParaBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result || '');
      const idx = res.indexOf(',');
      resolve(idx >= 0 ? res.slice(idx + 1) : res);
    };
    reader.onerror = () => reject(new Error(`Falha ao ler o arquivo "${file.name}".`));
    reader.readAsDataURL(file);
  });
}

export async function calcularSha256Arquivo(file: File): Promise<string> {
  try {
    const buf = await file.arrayBuffer();
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const digest = await crypto.subtle.digest('SHA-256', buf);
      return Array.from(new Uint8Array(digest))
        .map((b) => ('0' + b.toString(16)).slice(-2))
        .join('');
    }
  } catch {
    /* fallback determinístico */
  }
  let h1 = 0xdeadbeef ^ file.size;
  let h2 = 0x41c6ce57 ^ file.name.length;
  const s = `${file.name}:${file.size}:${file.lastModified}`;
  for (let i = 0; i < s.length; i++) {
    const ch = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  return (
    (h1 >>> 0).toString(16).padStart(8, '0') +
    (h2 >>> 0).toString(16).padStart(8, '0') +
    ((h1 ^ h2) >>> 0).toString(16).padStart(8, '0') +
    file.size.toString(16).padStart(8, '0')
  );
}

export function validarPayloadRecurso(
  p: CriarRecursoPayload,
  limites: Pick<ConfigServidor['limites'], 'minTexto' | 'maxTexto'>
): string[] {
  const erros: string[] = [];
  if (!/^[\w-]{8,64}$/.test(p.clientRequestId || '')) {
    erros.push('Identificador de requisição inválido.');
  }
  if (p.responsavel.nome.trim().length < 5) {
    erros.push('Informe o nome completo do(a) responsável (mínimo de 5 caracteres).');
  }
  if (!cpfValido(p.responsavel.cpf)) {
    erros.push('Informe um CPF válido do(a) responsável.');
  }
  if (p.responsavel.cargo.trim().length < 3) {
    erros.push('Informe o cargo ou função do(a) responsável.');
  }
  if (!['1G', '2G'].includes(p.unidade.grau)) {
    erros.push('Selecione o grau de jurisdição (1º Grau ou 2º Grau).');
  }
  if (!p.unidade.tipo) {
    erros.push('Selecione o tipo de unidade ou órgão avaliado.');
  }
  if (p.unidade.nome.trim().length < 3) {
    erros.push('Informe ou selecione a unidade judiciária / órgão.');
  }
  if (p.listaServidores.impugna && p.listaServidores.texto.trim().length < limites.minTexto) {
    erros.push(
      `A fundamentação da impugnação da lista de servidores vinculados deve ter no mínimo ${limites.minTexto} caracteres.`
    );
  }
  if (!p.itens.length && !p.listaServidores.impugna) {
    erros.push('Adicione ao menos um indicador impugnado ou marque a impugnação da lista de servidores vinculados.');
  }
  if (p.itens.length > 40) {
    erros.push('Máximo de 40 itens impugnados por protocolo.');
  }

  const chaves = new Set<string>();
  p.itens.forEach((it, idx) => {
    const rot = `Item ${idx + 1} (${it.sigla || 'sem sigla'})`;
    if (!/^[A-Za-z0-9/\-]{2,30}$/.test(it.sigla)) {
      erros.push(`${rot}: selecione um indicador válido.`);
    }
    if (!it.tipoImpugnacao) {
      erros.push(`${rot}: selecione o tipo de impugnação.`);
    }
    const tam = it.fundamentacao.trim().length;
    if (tam < limites.minTexto) {
      erros.push(`${rot}: a fundamentação técnica deve conter ao menos ${limites.minTexto} caracteres (atual: ${tam}).`);
    }
    if (tam > limites.maxTexto) {
      erros.push(`${rot}: a fundamentação excede o limite de ${limites.maxTexto} caracteres.`);
    }
    const ev = it.evidencias;
    if (!(ev.a && ev.b && ev.c && ev.d && ev.e)) {
      erros.push(`${rot}: confirme todas as 5 evidências obrigatórias previstas no Anexo III, item 3.`);
    }
    const k = `${it.sigla}|${it.subitem}`;
    if (chaves.has(k)) {
      erros.push(`${rot}: indicador e subitem duplicados no mesmo protocolo (${it.sigla}${it.subitem ? ' — ' + it.subitem : ''}).`);
    }
    chaves.add(k);
  });

  if (!p.declaracao) {
    erros.push('É obrigatório marcar a declaração de veracidade e conformidade com a Portaria PRESI nº 1961/2026.');
  }

  return erros;
}
