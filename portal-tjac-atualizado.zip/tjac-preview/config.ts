// Use the same OAuth web client ID on the frontend and in Apps Script.
export const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';
export const API_URL = import.meta.env.VITE_API_URL || '';
export const MODO_DEMO = import.meta.env.DEV && import.meta.env.VITE_MODO_DEMO === 'true';

/** Pastas oficiais do Google Drive informadas pela administração */
export const ROOT_FOLDER_ID = '1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv';
export const PASTA_RAIZ_DRIVE_URL =
  'https://drive.google.com/drive/folders/1eQDLRybKfB5sBJapsHjj4ZYtPbQkLGHv?usp=sharing';

export const PROTOCOLO_FOLDER_ID = '1GUF4-048uLdkuZIdSTIwO7OyMxQX8bsB';
export const PASTA_PROTOCOLO_DRIVE_URL =
  'https://drive.google.com/drive/folders/1GUF4-048uLdkuZIdSTIwO7OyMxQX8bsB?usp=sharing';

/**
 * URL da Planilha Mestra no Google Sheets (se já criada, cole abaixo;
 * também pode ser vinculada ou gerada diretamente no Painel Administrador).
 */
export const PLANILHA_MESTRA_URL = '';

export const EMAILS_ADMIN: readonly string[] = [
  'josue.silva@tjac.jus.br',
  'arturgemeos06@gmail.com',
];

export function ehAdmin(email?: string | null): boolean {
  return EMAILS_ADMIN.includes(email?.trim().toLowerCase() || '');
}

export const podeAtuarComoSumae = ehAdmin;
export const podeAtuarComoComissao = ehAdmin;

export function papelPadraoUsuario(email?: string | null): 'SUMAE' | 'COMISSAO' | 'UNIDADE' {
  return ehAdmin(email) ? 'SUMAE' : 'UNIDADE';
}

export const PRAZO_PADRAO = {
  inicio: '2026-12-04T00:00:00-05:00',
  fim: '2026-12-07T23:59:59-05:00',
  aberto: true,
};

export const LIMITES_PADRAO = {
  maxTexto: 4000,
  minTexto: 50,
  maxArqPorItem: 5,
  maxBytesArq: 10 * 1024 * 1024, // 10 MB
  mimes: [
    'application/pdf',
    'image/png',
    'image/jpeg',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel',
    'text/csv',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ],
};
