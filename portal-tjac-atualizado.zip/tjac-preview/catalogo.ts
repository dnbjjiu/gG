import type { Grau, TipoImpugnacao, TipoUnidade, UnidadeCatalogo } from './types';

export const PORTARIA =
  'Portaria PRESI/TJAC nº 1961/2026 (alterada pela Portaria PRESI nº 4335/2026)';

export interface TipoUnidadeInfo {
  codigo: TipoUnidade;
  rotulo: string;
  grau: Grau;
  descricao: string;
}

export const TIPOS_UNIDADE_INFO: TipoUnidadeInfo[] = [
  // 1º Grau
  { codigo: 'CIVEL', rotulo: 'Vara Cível', grau: '1G', descricao: 'Unidade cível comum de 1º grau' },
  { codigo: 'FAMILIA', rotulo: 'Vara de Família, Órfãos e Sucessões', grau: '1G', descricao: 'Competência de família e sucessões' },
  { codigo: 'FAZENDA', rotulo: 'Vara de Fazenda Pública', grau: '1G', descricao: 'Fazenda Pública Estadual e Municipal' },
  { codigo: 'EXEC_FISCAL', rotulo: 'Vara de Execuções Fiscais', grau: '1G', descricao: 'Execução fiscal e dívida ativa' },
  { codigo: 'CRIMINAL', rotulo: 'Vara Criminal', grau: '1G', descricao: 'Competência criminal comum / residual' },
  { codigo: 'JURI', rotulo: 'Vara do Tribunal do Júri e Auditoria Militar', grau: '1G', descricao: 'Crimes dolosos contra a vida e auditoria militar' },
  { codigo: 'ROUBO', rotulo: 'Vara de Delitos de Roubo e Extorsão / ORCRIM', grau: '1G', descricao: 'Delitos patrimoniais graves e organizações criminosas' },
  { codigo: 'VIOL_DOM', rotulo: 'Vara de Proteção à Mulher (Violência Doméstica)', grau: '1G', descricao: 'Lei Maria da Penha, feminicídio e medidas protetivas' },
  { codigo: 'INFANCIA', rotulo: 'Vara da Infância e da Juventude', grau: '1G', descricao: 'Cível infantojuvenil, SNA, atos infracionais e CNIUPS' },
  { codigo: 'VEP', rotulo: 'Vara de Execuções Penais e Medidas Alternativas', grau: '1G', descricao: 'Execução penal (SEEU) e inspeções CNIEP' },
  { codigo: 'JEC', rotulo: 'Juizado Especial Cível', grau: '1G', descricao: 'Sistema dos Juizados Especiais Cíveis' },
  { codigo: 'JECRIM', rotulo: 'Juizado Especial Criminal', grau: '1G', descricao: 'Infrações penais de menor potencial ofensivo' },
  { codigo: 'JEFAZ', rotulo: 'Juizado Especial da Fazenda Pública', grau: '1G', descricao: 'Causas cíveis de interesse da Fazenda até 60 salários mínimos' },
  { codigo: 'TURMA_RECURSAL', rotulo: 'Turma Recursal dos Juizados Especiais', grau: '1G', descricao: 'Gabinetes das Turmas Recursais do Sistema dos Juizados' },
  { codigo: 'VARA_UNICA', rotulo: 'Vara Única (Competência Plena / Cumulativa)', grau: '1G', descricao: 'Comarcas de entrância inicial com competência cumulativa' },
  { codigo: 'GARANTIAS', rotulo: 'Vara Estadual do Juiz das Garantias', grau: '1G', descricao: 'Controle da legalidade da investigação criminal' },
  // 2º Grau
  { codigo: 'GAB_CIVEL', rotulo: 'Gabinete de Desembargador — Câmara Cível', grau: '2G', descricao: '1ª e 2ª Câmaras Cíveis do TJAC' },
  { codigo: 'GAB_CRIMINAL', rotulo: 'Gabinete de Desembargador — Câmara Criminal', grau: '2G', descricao: 'Câmara Criminal do TJAC' },
  { codigo: 'VICE_PRESIDENCIA', rotulo: 'Vice-Presidência', grau: '2G', descricao: 'Admissibilidade de recursos constitucionais (art. 4º, I-A)' },
  { codigo: 'SEJUD', rotulo: 'Secretaria Judiciária (SEJUD)', grau: '2G', descricao: 'Órgão de apoio ao 2º grau avaliado pelo ISJ (art. 4º, III e § 2º)' },
];

export const TIPOS_IMPUGNACAO_INFO: { codigo: TipoImpugnacao; rotulo: string; ajuda: string }[] = [
  {
    codigo: 'APURACAO',
    rotulo: 'Divergência no quantitativo ou cálculo apurado no painel/relatório',
    ajuda: 'Diferença entre o índice ou quantitativo de processos apurado no Resultado Preliminar e os dados constantes nos painéis de BI do PJAC, DataJud, SEEU, SNA, CNIUPS ou CNIEP até 30/11/2026.',
  },
  {
    codigo: 'APLICABILIDADE',
    rotulo: 'Inaplicabilidade do indicador à unidade (exclusão da base de cálculo)',
    ajuda: 'Pedido de exclusão do indicador do denominador da fórmula (art. 7º, § 1º e Anexo II) por ausência de competência ratione materiae, insuficiência de acervo ou ausência de casos novos.',
  },
  {
    codigo: 'FAIXA_ARREDONDAMENTO',
    rotulo: 'Enquadramento em faixa de pontuação ou regra de compensação (Anexo IV)',
    ajuda: 'Questionamento sobre a faixa de pontos atribuída (ex.: compensação do IAD-C entre 90% e 99,99% com TCL < 25%, ponderação de Metas ou fração do ISU-2G).',
  },
  {
    codigo: 'FONTE_DADOS',
    rotulo: 'Indisponibilidade de painel de BI / aplicação de relatório oficial homologado',
    ajuda: 'Utilização de relatório oficial homologado pelas áreas gestoras antes do Resultado Preliminar (Anexo I, item I, "c" e Anexo III, item 2).',
  },
  {
    codigo: 'OUTRO',
    rotulo: 'Outra inconsistência técnica ou material na apuração preliminar',
    ajuda: 'Erro material de vinculação de classe, assunto, movimento, data de corte ou migração entre sistemas oficiais.',
  },
];

export const EVIDENCIAS_OBRIGATORIAS: {
  chave: 'a' | 'b' | 'c' | 'd' | 'e';
  alínea: string;
  titulo: string;
  detalhe: string;
}[] = [
  {
    chave: 'a',
    alínea: 'a)',
    titulo: 'Identificação do painel ou relatório utilizado como base',
    detalhe: 'Painel de BI do PJAC (intranet), DataJud, SEEU, SNA, CNIUPS, CNIEP ou relatório oficial homologado.',
  },
  {
    chave: 'b',
    alínea: 'b)',
    titulo: 'Filtros aplicados (período, unidade, classe processual)',
    detalhe: 'Demonstração visível dos parâmetros de filtragem aplicados na extração da evidência.',
  },
  {
    chave: 'c',
    alínea: 'c)',
    titulo: 'Período de referência utilizado (1º/01/2026 a 30/11/2026)',
    detalhe: 'Observada a data de corte de 30/11/2026 às 23h59min59s e os recortes históricos previstos na Portaria.',
  },
  {
    chave: 'd',
    alínea: 'd)',
    titulo: 'Memória de cálculo detalhada',
    detalhe: 'Explicitação do numerador, denominador e fórmula aplicada conforme os Anexos II e IV.',
  },
  {
    chave: 'e',
    alínea: 'e)',
    titulo: 'Número e quantidade exata dos processos impugnados',
    detalhe: 'Listagem nominal (numeração única CNJ) e quantitativo exato dos processos ou registros objetos do recurso.',
  },
];

export interface IndicadorCatalogo {
  sigla: string;
  nome: string;
  grupo: string;
  grau: Grau;
  pontosMax: number;
  fonte: string;
  faixasResumo: string;
  subitens: string[];
  tiposPermitidos?: TipoUnidade[]; // vazio/undefined = todos os tipos do respectivo grau (exceto VPRES/SEJUD que têm grupos próprios)
}

export const INDICADORES_CATALOGO: IndicadorCatalogo[] = [
  // ==========================================================================
  // A. 1º GRAU — INDICADORES GERAIS (até 540 pontos — Anexo I, item A)
  // ==========================================================================
  {
    sigla: 'IAD-C',
    nome: 'Índice de Atendimento à Demanda — Critério Conjugado',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 120,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'IAD ≥ 100%: 120 pts | IAD 95% a 99,99% c/ TCL < 25%: 80 pts | IAD 90% a 94,99% c/ TCL < 25%: 60 pts | IAD < 90%: 0 pt',
    subitens: [
      'Apuração Geral do IAD-C',
      'Condição de Compensação pela Taxa de Congestionamento Líquida (TCL < 25%)',
      'Casos Novos (Denominador)',
      'Processos Baixados / Julgados (Numerador)',
    ],
  },
  {
    sigla: 'TPL',
    nome: 'Tempo Médio de Duração dos Processos Pendentes Líquidos',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 60,
    fonte: 'Painel de BI do PJAC / DataJud (Natureza Conhecimento)',
    faixasResumo: '≤ 500 dias: 60 pts | 501 a 700 dias: 50 pts | 701 a 900 dias: 40 pts | > 900 dias: 0 pt',
    subitens: [
      'Tempo Médio Geral (dias corridos líquidos)',
      'Exclusão de processos suspensos, sobrestados ou em arquivo provisório',
    ],
  },
  {
    sigla: 'METAS',
    nome: 'Índice de Cumprimento das Metas Nacionais do CNJ',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 130,
    fonte: 'Painéis de BI do PJAC / Aferição Oficial das Metas Nacionais 2026',
    faixasResumo: 'Pontua por meta cumprida com ≥ 100% (Metas 1, 2.1, 2.2 e 3: 20 pts cada; Metas 4.1, 4.2, 5, 6, 7, 8.1, 8.2 e 10: 10 pts cada)',
    subitens: [
      'Conjunto das Metas Nacionais Aplicáveis à Unidade',
      'Meta 1 — Julgar mais processos que os distribuídos (20 pts)',
      'Meta 2.1 — Julgar 90% dos processos distribuídos até 31.12.2023 (20 pts)',
      'Meta 2.2 — Julgar 100% dos processos com mais de 15 anos (20 pts)',
      'Meta 3 — Estimular a conciliação (20 pts)',
      'Meta 4.1 — Improbidade administrativa e crimes contra a Administração Pública (10 pts)',
      'Meta 4.2 — Ações de improbidade administrativa distribuídas até 31.12.2022 (10 pts)',
      'Meta 5 — Reduzir a taxa de congestionamento (10 pts)',
      'Meta 6 — Priorizar o julgamento das ações coletivas (10 pts)',
      'Meta 7 — Priorizar processos de indígenas e comunidades quilombolas (10 pts)',
      'Meta 8.1 — Priorizar processos de violência doméstica e familiar (10 pts)',
      'Meta 8.2 — Priorizar processos de feminicídio (10 pts)',
      'Meta 10 — Processos ambientais e da infância e juventude (10 pts)',
    ],
  },
  {
    sigla: 'IREA',
    nome: 'Índice de Redução de Processos Antigos',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 40,
    fonte: 'Painel de BI do PJAC / DataJud (Processos ajuizados até 31.12.2023)',
    faixasResumo: 'Até 17% dos pendentes líquidos: 40 pts | De 17,01% a 22,00%: 20 pts | Acima de 22%: 0 pt',
    subitens: [
      'Proporção Geral de Processos Antigos Pendentes Líquidos',
      'Exclusão de processos já julgados, suspensos, sobrestados ou de execução',
    ],
  },
  {
    sigla: 'ISU',
    nome: 'Índice de Saneamento e/ou Consistência de Dados',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 70,
    fonte: 'Painel de Saneamento BI PJAC / Sistemas Processuais Oficiais',
    faixasResumo: 'Média ≥ 99%: 70 pts | ≥ 95% a < 99%: 55 pts | ≥ 90% a < 95%: 40 pts | ≥ 85% a < 90%: 20 pts | < 85%: 0 pt',
    subitens: [
      'Média Geral dos 4 Componentes (C1 a C4)',
      'C1 — Classe processual corretamente cadastrada',
      'C2 — Assunto principal cadastrado',
      'C3 — Partes identificadas corretamente (polos ativo e passivo)',
      'C4 — Movimentos processuais adequados',
    ],
  },
  {
    sigla: 'IRASP',
    nome: 'Índice de Alimentação e Correção de Sistemas Prioritários (SNA, CNIUPS e CNIEP)',
    grupo: '1º Grau — Indicadores Gerais',
    grau: '1G',
    pontosMax: 120,
    fonte: 'Registros oficiais do SNA (até 60 pts), CNIUPS (até 30 pts) e CNIEP (até 30 pts)',
    faixasResumo: 'Cumulativo conforme aplicabilidade: SNA até 60 pts + CNIUPS até 30 pts + CNIEP até 30 pts (total até 120 pts)',
    subitens: [
      'Inaplicabilidade Integral do IRASP à Unidade (Anexo II)',
      'SNA — a) Reavaliação de acolhimento em 90 dias (até 20 pts)',
      'SNA — b.1) Processos de adoção ≤ 240 dias (10 pts)',
      'SNA — b.2) Destituição do poder familiar ≤ 120 dias (10 pts)',
      'SNA — c) Cadastro de grupo étnico-racial > 90% (10 pts)',
      'SNA — d) Serviço de acolhimento em família acolhedora / GTI (até 10 pts)',
      'CNIUPS — a) Inspeções em estabelecimentos de meio fechado (até 20 pts)',
      'CNIUPS — b) Inspeções em programas de meio aberto (até 10 pts)',
      'CNIEP — Inspeções mensais em estabelecimentos penais (até 30 pts)',
    ],
  },

  // ==========================================================================
  // B. 1º GRAU — INDICADORES TEMÁTICOS (até 370 pontos — Anexo I, item B)
  // ==========================================================================
  {
    sigla: 'TPL-VDF',
    nome: 'Tempo Médio do Pendente Líquido — Violência Doméstica e Familiar contra a Mulher',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 30,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 400 dias: 30 pts | 401 a 600 dias: 20 pts | > 600 dias: 0 pt',
    subitens: ['Apuração Geral do TPL-VDF', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'TPL-FEM',
    nome: 'Tempo Médio do Pendente Líquido nos Processos de Feminicídio',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 30,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 400 dias: 30 pts | 401 a 600 dias: 20 pts | > 600 dias: 0 pt',
    subitens: ['Apuração Geral do TPL-FEM', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'TM-MPU',
    nome: 'Tempo Médio de Medidas Protetivas de Urgência',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 40,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'Apreciação ≤ 1 dia: 40 pts | > 1 e ≤ 2 dias: 20 pts | > 2 dias: 0 pt',
    subitens: ['Apuração Geral do TM-MPU', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'TPL-Saude',
    nome: 'Tempo Médio do Pendente Líquido nos Processos de Judicialização da Saúde',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 40,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 300 dias: 40 pts | 301 a 500 dias: 20 pts | > 500 dias: 0 pt',
    subitens: ['Apuração Geral do TPL-Saúde (1º Grau)', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'ICAP',
    nome: 'Índice de Celeridade Processual na Tramitação das Ações Penais',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 40,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 700 dias: 40 pts | 701 a 1.000 dias: 20 pts | > 1.000 dias: 0 pt',
    subitens: ['Apuração Geral do ICAP', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'IAD-Amb',
    nome: 'Índice de Atendimento à Demanda — Ambiental',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 30,
    fonte: 'Painel de BI do PJAC / DataJud (Classificação Ambiental)',
    faixasResumo: 'IAD Ambiental ≥ 100,00%: 30 pts | < 100,00%: 0 pt',
    subitens: ['Apuração Geral do IAD-Amb (1º Grau)', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'IJ-Amb',
    nome: 'Índice de Julgamento de Ações Ambientais Ingressadas até 31.12.2022',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 30,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'Julgar no mínimo 30,00% do acervo ambiental ingressado até 31.12.2022: 30 pts | < 30%: 0 pt',
    subitens: ['Apuração Geral do IJ-Amb (1º Grau)', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'IPV-PR/LC-SEEU',
    nome: 'Índice de Julgamento dos Incidentes de Progressão de Regime e Livramento Condicional Vencidos no SEEU',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 60,
    fonte: 'Sistema Eletrônico de Execução Unificado (SEEU)',
    faixasResumo: 'Índice até 1,0%: 60 pts | Acima de 1,0% até 2,0%: 30 pts | Acima de 2,0%: 0 pt',
    subitens: ['Apuração Geral no SEEU', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'IEP-TP',
    nome: 'Índice de Extinção da Pena no SEEU',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 30,
    fonte: 'Sistema Eletrônico de Execução Unificado (SEEU)',
    faixasResumo: 'Índice até 0,2%: 30 pts | Acima de 0,2% até 0,3%: 20 pts | Acima de 0,3%: 0 pt',
    subitens: ['Apuração Geral do IEP-TP no SEEU', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'I-ACS',
    nome: 'Índice de Realização de Audiências Concentradas Infracionais em 30.11.2026',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 20,
    fonte: 'Painel de BI do PJAC / CNIUPS / Relatório Oficial',
    faixasResumo: 'Percentual acima de 100%: 20 pts | De 90,00% a 100,00%: 10 pts | < 90%: 0 pt',
    subitens: ['Apuração Geral do I-ACS', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },
  {
    sigla: 'C-AI',
    nome: 'Celeridade Processual na Tramitação de Ato Infracional (até 180 dias)',
    grupo: '1º Grau — Indicadores Temáticos',
    grau: '1G',
    pontosMax: 20,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'Acima de 90,00% em até 180 dias: 20 pts | De 80,01% a 90,00%: 15 pts | De 70,00% a 80,00%: 10 pts',
    subitens: ['Apuração Geral do C-AI', 'Inaplicabilidade do indicador à unidade (art. 10, § 2º)'],
  },

  // ==========================================================================
  // C. 2º GRAU — INDICADORES GERAIS — GABINETES (até 430 pontos — Anexo I, item C)
  // ==========================================================================
  {
    sigla: 'IAD-C-2G',
    nome: 'Índice de Atendimento à Demanda — Critério Conjugado (2º Grau)',
    grupo: '2º Grau — Indicadores Gerais (Gabinetes)',
    grau: '2G',
    pontosMax: 120,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'IAD ≥ 100%: 120 pts | IAD 95% a 99,99% c/ TCL < 25%: 80 pts | IAD 90% a 94,99% c/ TCL < 25%: 60 pts | < 90%: 0 pt',
    subitens: [
      'Apuração Geral do IAD-C-2G',
      'Condição de Compensação pela TCL < 25%',
      'Casos Novos e Baixados/Julgados no Gabinete',
    ],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'TPL-2G',
    nome: 'Tempo Médio de Duração dos Processos Pendentes Líquidos (2º Grau)',
    grupo: '2º Grau — Indicadores Gerais (Gabinetes)',
    grau: '2G',
    pontosMax: 60,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 500 dias: 60 pts | 501 a 700 dias: 50 pts | 701 a 900 dias: 40 pts | > 900 dias: 0 pt',
    subitens: ['Tempo Médio Geral do Gabinete (TPL-2G)', 'Exclusão de processos suspensos ou sobrestados'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'METAS-2G',
    nome: 'Índice de Cumprimento das Metas Nacionais do CNJ (2º Grau)',
    grupo: '2º Grau — Indicadores Gerais (Gabinetes)',
    grau: '2G',
    pontosMax: 130,
    fonte: 'Painéis de BI do PJAC / Aferição Oficial das Metas Nacionais 2026',
    faixasResumo: 'Pontua por meta aplicável ao 2º Grau cumprida com ≥ 100% (até 130 pontos)',
    subitens: [
      'Conjunto das Metas Nacionais Aplicáveis ao Gabinete',
      'Meta 1 — Julgar mais processos que os distribuídos (20 pts)',
      'Meta 2.1 — Julgar processos antigos distribuídos até 31.12.2023 (20 pts)',
      'Meta 2.2 — Julgar 100% dos processos com mais de 15 anos (20 pts)',
      'Meta 3 — Conciliação no 2º Grau (20 pts)',
      'Meta 4.1 / 4.2 — Improbidade administrativa e crimes contra a Administração Pública',
      'Meta 5 — Redução da taxa de congestionamento (10 pts)',
      'Meta 6 — Ações coletivas (10 pts)',
      'Meta 7 — Processos de indígenas e quilombolas (10 pts)',
      'Meta 8.1 / 8.2 — Violência doméstica e feminicídio',
      'Meta 10 — Processos ambientais e infância/juventude (10 pts)',
    ],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'IREA-2G',
    nome: 'Índice de Redução de Processos Antigos (2º Grau)',
    grupo: '2º Grau — Indicadores Gerais (Gabinetes)',
    grau: '2G',
    pontosMax: 70,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'Até 17% dos casos pendentes líquidos: 70 pts | De 17,01% a 22,00%: 35 pts | Acima de 22%: 0 pt',
    subitens: ['Proporção Geral de Processos Antigos no Gabinete (IREA-2G)'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'ISU-2G',
    nome: 'Índice de Saneamento e/ou Consistência de Dados (2º Grau)',
    grupo: '2º Grau — Indicadores Gerais (Gabinetes)',
    grau: '2G',
    pontosMax: 50,
    fonte: 'Painel de Saneamento BI PJAC',
    faixasResumo: 'Média ≥ 99%: 50 pts | ≥ 95% a < 99%: 275/7 (~39,29 pts) | ≥ 90% a < 95%: 200/7 (~28,57 pts) | ≥ 85% a < 90%: 100/7 (~14,29 pts)',
    subitens: [
      'Média Geral dos 4 Componentes (C1 a C4)',
      'C1 — Classe corretamente cadastrada',
      'C2 — Assunto principal cadastrado',
      'C3 — Partes identificadas corretamente',
      'C4 — Movimentos processuais adequados',
    ],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },

  // ==========================================================================
  // D. 2º GRAU — INDICADORES TEMÁTICOS (até 70 pontos — Anexo I, item D)
  // ==========================================================================
  {
    sigla: 'TPL-Saude-2G',
    nome: 'Tempo Médio do Pendente Líquido nos Processos de Judicialização da Saúde (2º Grau)',
    grupo: '2º Grau — Indicadores Temáticos',
    grau: '2G',
    pontosMax: 20,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: '≤ 300 dias: 20 pts | 301 a 500 dias: 10 pts | > 500 dias: 0 pt',
    subitens: ['Apuração Geral do TPL-Saúde-2G', 'Inaplicabilidade do indicador ao Gabinete'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'IAD-Amb-2G',
    nome: 'Índice de Atendimento à Demanda Ambiental (2º Grau)',
    grupo: '2º Grau — Indicadores Temáticos',
    grau: '2G',
    pontosMax: 30,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'IAD Ambiental ≥ 100,00%: 30 pts | < 100,00%: 0 pt',
    subitens: ['Apuração Geral do IAD-Amb-2G', 'Inaplicabilidade do indicador ao Gabinete'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'IJ-Amb-2G',
    nome: 'Índice de Julgamento de Ações Ambientais Ingressadas até 31.12.2022 (2º Grau)',
    grupo: '2º Grau — Indicadores Temáticos',
    grau: '2G',
    pontosMax: 20,
    fonte: 'Painel de BI do PJAC / DataJud',
    faixasResumo: 'Julgar no mínimo 30,00% do acervo ambiental ingressado até 31.12.2022: 20 pts | < 30%: 0 pt',
    subitens: ['Apuração Geral do IJ-Amb-2G', 'Inaplicabilidade do indicador ao Gabinete'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },

  // ==========================================================================
  // E. 2º GRAU — PRECEDENTES QUALIFICADOS (até 70 pontos — Anexo I, item E)
  // ==========================================================================
  {
    sigla: 'IRDR/IAC-SUS',
    nome: 'IRDR/IAC Suscitado/Admitido no Período (10 pts por evento, até 2)',
    grupo: '2º Grau — Precedentes Qualificados',
    grau: '2G',
    pontosMax: 20,
    fonte: 'Painéis oficiais e registros processuais de IRDR/IAC',
    faixasResumo: '10 pontos por evento de suscitamento/admissão no período (1º/01 a 30/11/2026), limitado a 2 eventos (até 20 pts)',
    subitens: ['Contabilização de IRDR/IAC suscitado ou admitido pelo Gabinete'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },
  {
    sigla: 'IRDR/IAC-TESE',
    nome: 'IRDR/IAC Julgado com Tese Fixada no Período (25 pts por evento, até 2)',
    grupo: '2º Grau — Precedentes Qualificados',
    grau: '2G',
    pontosMax: 50,
    fonte: 'Painéis oficiais e registros processuais de IRDR/IAC',
    faixasResumo: '25 pontos por IRDR/IAC julgado com tese jurídica fixada no período, limitado a 2 eventos (até 50 pts)',
    subitens: ['Contabilização de IRDR/IAC julgado com tese fixada pelo Gabinete'],
    tiposPermitidos: ['GAB_CIVEL', 'GAB_CRIMINAL'],
  },

  // ==========================================================================
  // F. SECRETARIA JUDICIÁRIA — INDICADOR COMPOSTO (ISJ — até 650 pontos)
  // ==========================================================================
  {
    sigla: 'ISJ',
    nome: 'Índice de Desempenho da Secretaria Judiciária (ISJ)',
    grupo: '2º Grau — Secretaria Judiciária (SEJUD)',
    grau: '2G',
    pontosMax: 650,
    fonte: 'Exclusivamente Painéis de BI do PJAC (art. 4º, § 2º e Anexo II)',
    faixasResumo: 'ISJ = (Σ %Final_gabinete_i) ÷ n_válidos (excluídos Presidente, Vice-Presidente e Corregedor-Geral). Pontos = (ISJ ÷ 100) × 650',
    subitens: [
      'Cálculo da Média Aritmética Simples dos Gabinetes Elegíveis (ISJ)',
      'Composição de n_válidos (exclusões do art. 4º, § 3º)',
      'Conversão em pontos: (ISJ ÷ 100) × 650',
    ],
    tiposPermitidos: ['SEJUD'],
  },

  // ==========================================================================
  // G. VICE-PRESIDÊNCIA (até 350 pontos — Anexo I, item G, Portaria 4335/2026)
  // ==========================================================================
  {
    sigla: 'IAD-VPRES',
    nome: 'Índice de Atendimento à Demanda — Vice-Presidência (RCB ÷ RCD × 100)',
    grupo: '2º Grau — Vice-Presidência',
    grau: '2G',
    pontosMax: 120,
    fonte: 'Painéis de BI do PJAC e registros oficiais no sistema SAJ',
    faixasResumo: 'IAD ≥ 105%: 120 pts | 100% a 104,99%: 100 pts | 95% a 99,99% c/ TCL < 25%: 80 pts | 90% a 94,99% c/ TCL < 25%: 60 pts',
    subitens: [
      'Apuração Geral do IAD-VPRES (Recursos Constitucionais Baixados ÷ Distribuídos)',
      'Condição de Compensação pela TCL < 25%',
    ],
    tiposPermitidos: ['VICE_PRESIDENCIA'],
  },
  {
    sigla: 'TPL-VPRES',
    nome: 'Tempo Médio do Pendente Líquido — Vice-Presidência',
    grupo: '2º Grau — Vice-Presidência',
    grau: '2G',
    pontosMax: 120,
    fonte: 'Painéis de BI do PJAC e registros oficiais no sistema SAJ',
    faixasResumo: '≤ 200 dias: 120 pts | 201 a 300 dias: 80 pts | 301 a 400 dias: 60 pts | > 400 dias: 0 pt',
    subitens: ['Tempo médio entre remessa à Vice-Presidência e decisão de admissibilidade (SAJ)'],
    tiposPermitidos: ['VICE_PRESIDENCIA'],
  },
  {
    sigla: 'TPL-Saude-VPRES',
    nome: 'Tempo Médio do Pendente Líquido — Saúde — Vice-Presidência',
    grupo: '2º Grau — Vice-Presidência',
    grau: '2G',
    pontosMax: 40,
    fonte: 'Painéis de BI do PJAC e registros oficiais no sistema SAJ',
    faixasResumo: '≤ 100 dias: 40 pts | 101 a 200 dias: 20 pts | > 200 dias: 0 pt',
    subitens: ['Tempo médio nos processos de saúde remetidos à Vice-Presidência (SAJ)'],
    tiposPermitidos: ['VICE_PRESIDENCIA'],
  },
  {
    sigla: 'ISU-VPRES',
    nome: 'Índice de Saneamento e/ou Consistência de Dados — Vice-Presidência',
    grupo: '2º Grau — Vice-Presidência',
    grau: '2G',
    pontosMax: 70,
    fonte: 'Painéis de BI do PJAC e registros oficiais no sistema SAJ',
    faixasResumo: 'Média ≥ 99%: 70 pts | ≥ 95% a < 99%: 55 pts | ≥ 90% a < 95%: 40 pts | ≥ 85% a < 90%: 20 pts | < 85%: 0 pt',
    subitens: [
      'Média Geral dos 4 Componentes (C1 a C4 — SAJ)',
      'C1 — Classe corretamente cadastrada',
      'C2 — Assunto principal cadastrado',
      'C3 — Partes identificadas corretamente',
      'C4 — Movimentos processuais adequados',
    ],
    tiposPermitidos: ['VICE_PRESIDENCIA'],
  },
];

export function indicadoresParaUnidade(grau: Grau, tipo: TipoUnidade): IndicadorCatalogo[] {
  return INDICADORES_CATALOGO.filter((ind) => {
    if (ind.grau !== grau) return false;
    if (ind.tiposPermitidos && ind.tiposPermitidos.length > 0) {
      return ind.tiposPermitidos.includes(tipo);
    }
    return true;
  });
}

export const COMARCAS_ACRE = [
  'Rio Branco',
  'Cruzeiro do Sul',
  'Sena Madureira',
  'Tarauacá',
  'Feijó',
  'Brasiléia',
  'Epitaciolândia',
  'Senador Guiomard',
  'Plácido de Castro',
  'Xapuri',
  'Acrelândia',
  'Mâncio Lima',
  'Rodrigues Alves',
  'Bujari',
  'Capixaba',
  'Porto Acre',
  'Manoel Urbano',
  'Assis Brasil',
  'Jordão',
  'Marechal Thaumaturgo',
  'Porto Walter',
  'Santa Rosa do Purus',
];

export const UNIDADES_PADRAO: UnidadeCatalogo[] = [
  // Rio Branco — 1º Grau
  { codigo: 'RB-1CIV', nome: '1ª Vara Cível da Comarca de Rio Branco', tipo: 'CIVEL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2CIV', nome: '2ª Vara Cível da Comarca de Rio Branco', tipo: 'CIVEL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-3CIV', nome: '3ª Vara Cível da Comarca de Rio Branco', tipo: 'CIVEL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-4CIV', nome: '4ª Vara Cível da Comarca de Rio Branco', tipo: 'CIVEL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-5CIV', nome: '5ª Vara Cível da Comarca de Rio Branco', tipo: 'CIVEL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1FAM', nome: '1ª Vara de Família da Comarca de Rio Branco', tipo: 'FAMILIA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2FAM', nome: '2ª Vara de Família da Comarca de Rio Branco', tipo: 'FAMILIA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-3FAM', nome: '3ª Vara de Família e Sucessões da Comarca de Rio Branco', tipo: 'FAMILIA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1FAZ', nome: '1ª Vara de Fazenda Pública da Comarca de Rio Branco', tipo: 'FAZENDA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2FAZ', nome: '2ª Vara de Fazenda Pública da Comarca de Rio Branco', tipo: 'FAZENDA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-EFISC', nome: 'Vara de Execuções Fiscais da Comarca de Rio Branco', tipo: 'EXEC_FISCAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1CRI', nome: '1ª Vara Criminal da Comarca de Rio Branco', tipo: 'CRIMINAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2CRI', nome: '2ª Vara Criminal da Comarca de Rio Branco', tipo: 'CRIMINAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-3CRI', nome: '3ª Vara Criminal da Comarca de Rio Branco', tipo: 'CRIMINAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-4CRI', nome: '4ª Vara Criminal da Comarca de Rio Branco', tipo: 'CRIMINAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1JURI', nome: '1ª Vara do Tribunal do Júri da Comarca de Rio Branco', tipo: 'JURI', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2JURI', nome: '2ª Vara do Tribunal do Júri e Auditoria Militar de Rio Branco', tipo: 'JURI', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-ROUBO', nome: 'Vara de Delitos de Roubo e Extorsão da Comarca de Rio Branco', tipo: 'ROUBO', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1VDM', nome: '1ª Vara de Proteção à Mulher da Comarca de Rio Branco', tipo: 'VIOL_DOM', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2VDM', nome: '2ª Vara de Proteção à Mulher da Comarca de Rio Branco', tipo: 'VIOL_DOM', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1INF', nome: '1ª Vara da Infância e da Juventude da Comarca de Rio Branco', tipo: 'INFANCIA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2INF', nome: '2ª Vara da Infância e da Juventude da Comarca de Rio Branco', tipo: 'INFANCIA', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-VEP', nome: 'Vara de Execuções Penais e Medidas Alternativas de Rio Branco', tipo: 'VEP', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-GAR', nome: 'Vara Estadual do Juiz das Garantias da Comarca de Rio Branco', tipo: 'GARANTIAS', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1JEC', nome: '1º Juizado Especial Cível da Comarca de Rio Branco', tipo: 'JEC', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2JEC', nome: '2º Juizado Especial Cível da Comarca de Rio Branco', tipo: 'JEC', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-3JEC', nome: '3º Juizado Especial Cível da Comarca de Rio Branco', tipo: 'JEC', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-JECRIM', nome: 'Juizado Especial Criminal da Comarca de Rio Branco', tipo: 'JECRIM', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-JEFAZ', nome: 'Juizado Especial da Fazenda Pública da Comarca de Rio Branco', tipo: 'JEFAZ', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-1TR', nome: '1ª Turma Recursal dos Juizados Especiais — Rio Branco', tipo: 'TURMA_RECURSAL', grau: '1G', comarca: 'Rio Branco' },
  { codigo: 'RB-2TR', nome: '2ª Turma Recursal dos Juizados Especiais — Rio Branco', tipo: 'TURMA_RECURSAL', grau: '1G', comarca: 'Rio Branco' },

  // Cruzeiro do Sul — 1º Grau
  { codigo: 'CZS-1CIV', nome: '1ª Vara Cível da Comarca de Cruzeiro do Sul', tipo: 'CIVEL', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-2CIV', nome: '2ª Vara Cível da Comarca de Cruzeiro do Sul', tipo: 'CIVEL', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-FAM', nome: 'Vara de Família da Comarca de Cruzeiro do Sul', tipo: 'FAMILIA', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-FAZ', nome: 'Vara de Fazenda Pública da Comarca de Cruzeiro do Sul', tipo: 'FAZENDA', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-1CRI', nome: '1ª Vara Criminal da Comarca de Cruzeiro do Sul', tipo: 'CRIMINAL', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-2CRI', nome: '2ª Vara Criminal da Comarca de Cruzeiro do Sul', tipo: 'CRIMINAL', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-VDM', nome: 'Vara de Proteção à Mulher da Comarca de Cruzeiro do Sul', tipo: 'VIOL_DOM', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-INF', nome: 'Vara da Infância e da Juventude da Comarca de Cruzeiro do Sul', tipo: 'INFANCIA', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-VEP', nome: 'Vara de Execuções Penais da Comarca de Cruzeiro do Sul', tipo: 'VEP', grau: '1G', comarca: 'Cruzeiro do Sul' },
  { codigo: 'CZS-JEC', nome: 'Juizado Especial Cível e Criminal de Cruzeiro do Sul', tipo: 'JEC', grau: '1G', comarca: 'Cruzeiro do Sul' },

  // Demais Comarcas do Interior — 1º Grau
  { codigo: 'SM-CIV', nome: 'Vara Cível da Comarca de Sena Madureira', tipo: 'CIVEL', grau: '1G', comarca: 'Sena Madureira' },
  { codigo: 'SM-CRI', nome: 'Vara Criminal da Comarca de Sena Madureira', tipo: 'CRIMINAL', grau: '1G', comarca: 'Sena Madureira' },
  { codigo: 'TK-CIV', nome: 'Vara Cível da Comarca de Tarauacá', tipo: 'CIVEL', grau: '1G', comarca: 'Tarauacá' },
  { codigo: 'TK-CRI', nome: 'Vara Criminal da Comarca de Tarauacá', tipo: 'CRIMINAL', grau: '1G', comarca: 'Tarauacá' },
  { codigo: 'FJ-VU', nome: 'Vara Única da Comarca de Feijó', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Feijó' },
  { codigo: 'BR-CIV', nome: 'Vara Cível da Comarca de Brasiléia', tipo: 'CIVEL', grau: '1G', comarca: 'Brasiléia' },
  { codigo: 'BR-CRI', nome: 'Vara Criminal da Comarca de Brasiléia', tipo: 'CRIMINAL', grau: '1G', comarca: 'Brasiléia' },
  { codigo: 'EP-VU', nome: 'Vara Única da Comarca de Epitaciolândia', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Epitaciolândia' },
  { codigo: 'SG-VU', nome: 'Vara Única da Comarca de Senador Guiomard', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Senador Guiomard' },
  { codigo: 'PC-VU', nome: 'Vara Única da Comarca de Plácido de Castro', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Plácido de Castro' },
  { codigo: 'XP-VU', nome: 'Vara Única da Comarca de Xapuri', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Xapuri' },
  { codigo: 'AC-VU', nome: 'Vara Única da Comarca de Acrelândia', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Acrelândia' },
  { codigo: 'ML-VU', nome: 'Vara Única da Comarca de Mâncio Lima', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Mâncio Lima' },
  { codigo: 'RA-VU', nome: 'Vara Única da Comarca de Rodrigues Alves', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Rodrigues Alves' },
  { codigo: 'BJ-VU', nome: 'Vara Única da Comarca de Bujari', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Bujari' },
  { codigo: 'CP-VU', nome: 'Vara Única da Comarca de Capixaba', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Capixaba' },
  { codigo: 'PA-VU', nome: 'Vara Única da Comarca de Porto Acre', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Porto Acre' },
  { codigo: 'MU-VU', nome: 'Vara Única da Comarca de Manoel Urbano', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Manoel Urbano' },
  { codigo: 'AB-VU', nome: 'Vara Única da Comarca de Assis Brasil', tipo: 'VARA_UNICA', grau: '1G', comarca: 'Assis Brasil' },

  // 2º Grau — Gabinetes de Desembargadores, Vice-Presidência e SEJUD
  { codigo: '2G-1CC-G1', nome: 'Gabinete de Desembargador(a) — 1ª Câmara Cível (Gabinete 1)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-1CC-G2', nome: 'Gabinete de Desembargador(a) — 1ª Câmara Cível (Gabinete 2)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-1CC-G3', nome: 'Gabinete de Desembargador(a) — 1ª Câmara Cível (Gabinete 3)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-2CC-G1', nome: 'Gabinete de Desembargador(a) — 2ª Câmara Cível (Gabinete 1)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-2CC-G2', nome: 'Gabinete de Desembargador(a) — 2ª Câmara Cível (Gabinete 2)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-2CC-G3', nome: 'Gabinete de Desembargador(a) — 2ª Câmara Cível (Gabinete 3)', tipo: 'GAB_CIVEL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-CCR-G1', nome: 'Gabinete de Desembargador(a) — Câmara Criminal (Gabinete 1)', tipo: 'GAB_CRIMINAL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-CCR-G2', nome: 'Gabinete de Desembargador(a) — Câmara Criminal (Gabinete 2)', tipo: 'GAB_CRIMINAL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-CCR-G3', nome: 'Gabinete de Desembargador(a) — Câmara Criminal (Gabinete 3)', tipo: 'GAB_CRIMINAL', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-VPRES', nome: 'Vice-Presidência do Tribunal de Justiça do Estado do Acre', tipo: 'VICE_PRESIDENCIA', grau: '2G', comarca: 'Rio Branco' },
  { codigo: '2G-SEJUD', nome: 'Secretaria Judiciária do 2º Grau (SEJUD)', tipo: 'SEJUD', grau: '2G', comarca: 'Rio Branco' },
];
