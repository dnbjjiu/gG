# TJAC Appeals Portal — Development Brief and Implementation Prompt

Act as the lead engineer for the Prêmio TJAC de Qualidade 2026 appeals portal. Turn this brief into an implementation backlog and technical specification. Preserve the existing appeal workflow and add a reusable forms platform. Deliver technical specifications, wireframe annotations, and testable interaction requirements. The product owner will handle visual design. Write technical deliverables in English and end-user copy in Brazilian Portuguese.

## 1. Establish the legacy contract

Inspect the original project in Downloads and the working copy `tjac-preview`. Compare both Apps Script implementations, the local submission-hardening patch, and the actual deployed revision when the owner can provide it. Treat production configuration, data, and traffic as unverified until inspected. Inventory every field in a traceability matrix with source file and line, legacy key, field label, type, required condition, normalization, allowed values, validation and error, destination column or object, sensitivity, and equivalent test. Use `types.ts:71–125`, `components/Formulario.tsx:350–459`, `utils.ts:126–192`, `catalogo.ts`, `config.ts`, and the server routes and sheet headers as starting points.

- Preserve responsible party name, CPF, position and phone, and the authenticated account relationship. Map jurisdiction level, unit type, code, name and comarca. Preserve the institutional catalog, aliases, indicator eligibility and subitems, including any approved manual-entry fallback.
- Preserve the staff-list challenge flag and justification, the truth declaration, and the repeatable indicator group. Each item carries group, abbreviation, title, subitem, challenge type, preliminary and requested scores, justification, five evidence confirmations, and attachments. Distinguish blank from zero and preserve CPF leading zeros, decimal commas and local date and time semantics.
- Reconcile client and server rules. Known rules include CPF check digits, literal truth declaration, at least one indicator or a staff-list challenge, up to 40 items, 50–4,000 characters for item justification, indicator/subitem uniqueness, all five evidence confirmations, and at least one attachment per submitted indicator. Attachments currently allow up to five files per item and 10 MiB per file, with PDF, PNG, JPEG, XLSX, XLS, CSV and DOCX allowed. Capture the complete enum lists and boundary behavior from source. Obtain owner approval before changing any business rule, including conflicting lengths, coercions, applicability, or deadline behavior. Implement approved security changes separately and document their compatibility impact.
- Trace create → upload → finalize → receipt and tracking. Capture client request ID reuse, legacy RTQ protocol format, item numbering, state transitions, deadline boundaries and official time zone, folder relationships, SHA-256 metadata, receipt email behavior, and recovery after partial failures. Preserve review data, SUMAE opinion, commission decision, SEI references, disclosure status, historical documents and audit history. Keep authorization independent of what the form shows.
- Build golden fixtures with synthetic records for indicators only, staff list only, mixed appeals, maximum counts, invalid CPF, duplicate item, missing evidence, deadline edges, retried requests, and existing finalized records. Compare accepted payloads, normalized values, statuses, protocol and receipt semantics. Require sign-off on each intentional difference.

## 2. Forms platform and submission service

- Provide a form catalog and an authorized builder with create, clone, edit, reorder, preview, publish, schedule, archive and restore. Include a property editor, rule editor, accessible keyboard reorder, version comparison, unsaved-change handling, and publishing permissions. Freeze published revisions. In-progress and historical responses retain their original revision. Pin the version of referenced institutional catalogs when needed for reproducibility.
- Support short text, textarea, numeric and decimal input, date picker with keyboard entry, single choice, multiple choice, checkboxes, searchable dependent dropdowns, uploads, labeled linear scales, and grids with single or multiple choices per row. Specify per-type configuration, constraints, serialization, accessibility, localization and empty-state behavior. Provide repeatable sections for appeal items.
- Store declarative rules with typed operators, explicit AND/OR grouping, deterministic precedence and stable identifiers. Support visibility, conditional requirements and forward section jumps. Validate references, types, reachability and cycles before publication. Recompute state when prior answers change. Preserve hidden values only in the draft when policy allows and exclude them from validation, persistence and exports of finalized responses. Re-evaluate the same rules on the server. Give users a predictable Back path and explain skipped sections where useful.
- Recommend React/TypeScript with a typed API, PostgreSQL, private object storage and a background worker as a starting architecture. Compare managed hosting and Google Workspace integration with TJAC's operating constraints. Define API contracts for drafts, uploads, finalization, receipts, history, administrative searches and review actions. Return stable error codes and field paths and use request IDs for support. Document concurrency and failure behavior for each write.
- Use versioned draft saves and idempotent finalization bound to the authenticated user and request key. Finalize in a transaction and commit a receipt event in a transactional outbox. Keep email retries independent of the submission result. Use short-lived, scoped upload authorizations, private quarantine, size and count checks, format inspection and scanning, integrity checks, authorized downloads and orphan cleanup. Define what happens when scanning completes near the deadline. Keep the user informed about the status of each file.

## 3. Relational model and migration

Provide an ER diagram, DDL, constraints, query examples and an index plan. Start with the following model.

| Area | Tables and invariants |
| --- | --- |
| Identity | users, external_identities, roles, permissions, user_roles, role_permissions, unit_memberships, sessions. Unique provider issuer and subject. Scope unit roles and store grants with actor and timestamp. |
| Definitions | forms, form_versions, sections, questions, question_options, grid_rows, grid_columns, rule_groups, rule_conditions, rule_actions. Stable logical identifiers and version-scoped foreign keys. Immutable published definitions. Typed configuration for field-specific settings. |
| Responses | submissions, response_groups, answers, answer_options, grid_answers, attachments. Require consistent version references across questions and responses. Enforce uniqueness per response group and question. Keep typed scalar values and relational selections. Constrain attachment status and bind each file to its submission and relevant item or answer. |
| Domain | units, indicators, indicator_subitems, applicability, appeals, appeal_items, review_events, decisions, documents. Preserve legacy protocol as a unique reference and use opaque internal IDs. Keep a single authoritative representation for each fact and use views or projections for reports. |
| Operations | idempotency_keys, audit_events, outbox_events, migration_runs, legacy_id_map. Record data lineage and enforce deduplication. Apply explicit retention policies to PII, logs and files. |

Index owner/status/submission date, unit and review queue, protocol, version and foreign keys. Use cursor pagination and scoped projections. Keep CPF and evidence access limited and exclude them from default list payloads and telemetry. Design authorized exports with spreadsheet formula protection. Use constraints for duplicate detection and state invariants alongside service checks.

Run an idempotent migration on a restricted snapshot of Sheets, Drive and approved configuration. Profile orphan records, duplicate keys, file permissions and references, and historical formatting. Keep raw snapshots read-only with restricted access. Reconcile counts by state, source-to-target IDs, timestamps, attachment hashes and sample receipts. Stage acceptance and freeze or reconcile writes at cutover. Document how to recover new writes if rollback occurs and retain access to historical protocols throughout.

## 4. Identity and authorization

Keep Google Workspace sign-in as the institutional default. Verify identity tokens server-side with a supported verifier, including signature, issuer, audience, expiry and verified email. Enforce `hd=tjac.jus.br` and the institutional email suffix for institutional accounts. Preserve the explicitly authorized Gmail exception. Bind identities by issuer and subject after verification. Account linking requires verified ownership and an approved workflow. Fail closed on missing production configuration.

| Actor | Landing and authorized access |
| --- | --- |
| Normal verified institutional user | Open Novo recurso. Allow submission and own-resource tracking, plus approved unit access where defined. No admin or reviewer access. |
| Two designated accounts | Display ADMIN, UNIDADE and ANÁLISE after server verification. Current allowlist is `josue.silva@tjac.jus.br` and `arturgemeos06@gmail.com`. |
| Other accounts | Refuse access under the existing institutional policy. |

Define granular permissions for managing forms, viewing appeals, issuing SUMAE opinions, making commission decisions, disclosing results and exporting data. Keep these permissions distinct even when the same two accounts initially hold them. Gate every API and object lookup with role and scope checks. Use server-returned permissions for redirects and menus. Selecting a profile changes the workspace and never grants permissions. Require strong MFA for privileged users and step-up for sensitive actions. Define role revocation, session invalidation and audit trails.

Specify a separate email/password path if approved. Provision only eligible and verified accounts. Prefer Argon2id with a tuned cost or bcrypt with a calibrated cost and documented length handling. Use vetted libraries and unique salts. Store credentials server-side. Support passkeys or TOTP, one-time recovery codes, and recovery with equivalent assurance. Prefer opaque server-side sessions in Secure, HttpOnly, SameSite cookies with rotation, idle and absolute timeouts, CSRF protection and server-side revocation. If an API requires JWTs, use short-lived access tokens and rotating revocable refresh tokens. Apply shared rate limits by account and source, progressive backoff and alerting. For password recovery, use neutral responses, expiring one-time random tokens stored as hashes, bounded retries and session revocation on reset. Use accessible, localized errors and provide a path to recover from session expiry without losing authorized drafts.

## 5. Preliminary static audit and verification backlog

The evidence below comes from `tjac-preview` and the prior audit. The older Downloads project and the deployed environment may differ. Treat severity as provisional until configuration, access patterns and controls are verified.

| Priority | Finding and evidence | Remediation and verification |
| --- | --- | --- |
| High | A06. Server checks unit fields independently and indicator abbreviation by format at `Code.gs:727–754`. Catalog applicability is enforced by UI filtering in `Formulario.tsx:182–185`. | Validate combinations and membership against the authoritative catalog. Add regression cases for incompatible values and approved fallbacks. |
| High | A06/A08. Attachment handling at `Code.gs:331–368` relies on declared type except for a PDF prefix check. Upload status is read before the write lock. | Validate contents and permissions, quarantine files and perform state verification at the transaction boundary. Compare with the local patch, which has not been established as deployed. |
| High before production | A07. `Code.gs:181–218` uses Google tokeninfo and repository-specific identity policy. Live OAuth configuration and deployment have not been verified. | Use supported production token verification, and test domain claims, both exceptions/privileged paths, revoked roles and unauthorized object access in staging. |
| Medium | A02/A04. Drafts persist in browser storage at `Formulario.tsx:119–154`. Demo behavior is explicitly development-only in `config.ts:4`. | Minimize local PII and use expiring owner-scoped drafts. Confirm production builds fail closed and review real storage and Drive ACLs. |
| Medium | A03/A05. CDN runtime JavaScript is loaded at `index.html:15–16`. `Code.gs:899` has formula escaping for Sheets writes. | Bundle and pin frontend dependencies where appropriate. Inventory dependencies and review CSP, export sinks and formula protection. Verify live headers and advisory status separately. |
| Medium | A08/A09/A10. Writes cross Sheets, Drive and email at `Code.gs:285–325,353–368,376–405`. Rate limiting uses cache read/update at `Code.gs:820–825`. | Verify partial failures, reconcile orphans, use atomic quotas and durable events, and monitor state transitions without logging PII or tokens. |

Complete an OWASP Top 10 matrix with evidence, severity, confidence, owners and remediation deadlines. Mark categories without sufficient evidence as pending verification. Review dependency lockfiles, build pipeline, object and route authorization, provider settings, storage ACLs, sensitive data flows, logging, audit retention, alerts, and backup recovery. Keep assessment to authorized environments and synthetic data.

Performance hypotheses from static inspection include sequential base64 uploads (`Formulario.tsx:414–456`), application-wide locks during remote Drive/Sheets operations (`Code.gs:285–325,353–368`), and full-sheet reads for user and admin lists (`Code.gs:407–451`). Measure request duration by phase, lock contention, quotas, upload memory and wire bytes, query plans, JavaScript bundle weight and mobile interaction latency. Model daily volume, concurrent users near deadline, attachment percentiles, retries and administrative queries. Use representative, peak, burst and soak workloads in staging. Label targets separately from measurements and document capacity headroom.

## 6. UI and accessibility acceptance requirements

- Start with layout bands below 600 px, 600–1023 px and 1024 px and above. Verify at 320, 390, 768, 1024 and 1440 px and at zoom/reflow settings. Use one-column editing on phones, adapt complex tables to labeled lists or controlled scrolling, and keep submit actions visible without obscuring fields or keyboard focus.
- Meet WCAG 2.1 AA as requested and target WCAG 2.2 AA where institutional policy allows. Require semantic headings, landmarks and field groups, labels and instructions, readable contrast, no color-only signals, visible unobscured focus, accessible names, keyboard-only operation and touch targets. Support screen reader navigation, reduced motion, browser zoom, autocomplete and paste. For grids, associate row/column labels and offer a usable small-screen equivalent. Test complete workflows with assistive technology.
- Define visual states for default, hover, focus, pressed, selected, disabled, read-only, invalid, loading and completed. Pair inline errors with a linked summary after failed submission. Announce asynchronous status updates, preserve input on errors, and give users a clear recovery action. Move focus predictably after section changes and failed submissions.
- Provide annotated wireframes for sign-in, MFA and recovery, admin-only profile selection, instructions, new appeal and repeatable items, drafts, review-before-submit, file progress/quarantine/retry, deadline closed, confirmation and protocol receipt, tracking, review queue, builder, rules and publish confirmation. Specify loading, empty, no results, stale edit, access denied, offline, expired session and integration failure states for each applicable view.

## 7. Delivery plan, risks and measurable gates

| Phase | Indicative elapsed time | Exit gate |
| --- | --- | --- |
| Discovery and audit | Weeks 1–2 | Signed legacy inventory, verified deployment baseline, permissions matrix and peak load assumptions. |
| UX and architecture | Weeks 2–4 | Annotated prototype, threat model, ERD, API contracts and migration rehearsal plan. |
| Platform and parity | Weeks 4–9 | Auth and RBAC, versioned renderer, legacy submission lifecycle and approved parity tests. |
| Builder and integrations | Weeks 7–12 | Rule editor, publishing, review workflows and tested Drive/SEI integration boundaries. |
| Acceptance and cutover | Weeks 12–16 | Reconciled migration, accessibility and performance acceptance, staged rollout and tested rollback. |
| Operations | Ongoing | Named owners, monitoring, response runbooks, periodic access reviews, restore exercises and regression checks. |

Treat the schedule as a planning estimate. Staff with a product owner and TJAC domain reviewer, two to three engineers covering frontend and backend, a QA engineer, and part-time UX/accessibility, platform, security and data migration support. Re-estimate after measuring dataset size, policy approvals, integration readiness and historical data quality. Prioritize the institutional form and reviewer workflow before general-purpose builder expansion.

Maintain a risk register with likelihood, impact, mitigation, owner and trigger. Prioritize parity drift, deadline spikes, Google domain/consent restrictions, PII exposure, migration orphans, unsafe files, duplicate receipts, and dependence on external integrations. Use golden fixtures, capacity rehearsal, least privilege, reconciliation reports, idempotency and monitored queues as measurable controls.

Gate CI/CD on type and lint checks, unit tests for validators and rules, integration tests for permissions, persistence and migrations, and browser tests for full submission and review paths. Test concurrency, recovery, accessibility and representative loads in staging. Use reviewed migrations, separated secrets and environments, dependency scanning, staged releases, backups, verified restore and rollback. Monitor incidents and service health through the appeal window.

Propose measurable KPIs with owners and dashboards. Track successful finalizations per valid attempt, duplicate protocols, abandonment by section, time to first valid submission, attachment retry and scan times, p95 API latency and error rate at modeled peak, receipt delivery, accessibility defects and reconciliation mismatches. Start with candidate goals of zero duplicate protocols, zero unexplained migration discrepancies and zero unresolved critical accessibility/security defects at launch. Set numerical latency, completion and availability objectives after baselining the workload and agreeing on the appeal window.

Return a prioritized backlog with dependencies, effort ranges, acceptance criteria and decisions still requiring TJAC approval. Include a test matrix that connects each legacy business rule, permission and UI state to a verification method.

References  
[OWASP Top 10:2025](https://top10.owasp.org/2025/)  
[WCAG 2.2](https://www.w3.org/TR/WCAG22/)  
[Google ID token verification](https://developers.google.com/identity/gsi/web/guides/verify-google-id-token)
