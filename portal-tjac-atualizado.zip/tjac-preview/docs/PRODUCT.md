# Produto

<!-- impeccable:product-schema 1 -->

## Platform

web

## Usuários

Magistrados, diretores de secretaria e gestores responsáveis pela submissão de recursos de suas unidades ao resultado preliminar do Prêmio TJAC de Qualidade 2026.

## Objetivo do produto

O formulário permite interpor recursos ao resultado preliminar do Prêmio TJAC de Qualidade 2026. A remodelação deve facilitar a leitura e o preenchimento, reduzir o abandono e ajudar as pessoas a corrigir erros durante o preenchimento.

## Capacidades e restrições

- Aplicação web responsiva com abordagem mobile-first. O preenchimento deve fluir em telas pequenas.
- A hierarquia visual deve facilitar a leitura dos campos e a identificação das ações.
- As mensagens de erro devem deixar claro o que precisa ser corrigido.
- O projeto existente usa React, TypeScript e Vite.
- A seleção do grau de jurisdição e do tipo de unidade filtra os indicadores aplicáveis ao recurso.
- A meta de redução do abandono está em aberto.

## Diretrizes visuais confirmadas

Visual minimalista, profissional e direto ao ponto, com bom espaçamento entre campos, tipografia clara e microinterações sutis em botões e campos de entrada.

## Acessibilidade e inclusão

Manter contraste legível e apresentar feedback de erro claro durante o preenchimento.
