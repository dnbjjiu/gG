# Auditoria de segurança do formulário de recursos do TJAC

## Resumo

A revisão estática cobriu o formulário React/TypeScript e as duas cópias do back-end Google Apps Script. O servidor valida CPF, declaração, fundamentação e propriedade do protocolo. As maiores lacunas estão na validação de unidade e indicador contra o catálogo oficial e na verificação de anexos. O patch local trata formato e tamanho da entrada, listas de ações e tipos permitidos e a concorrência entre upload e finalização.

## Alta prioridade

### 1. Unidade e indicador sem validação de vínculo no servidor

Em `Code.gs:743–745,758–769`, o servidor valida grau e tipo separadamente, aceita o nome da unidade pelo comprimento e valida a sigla pelo formato. O filtro de unidades em `components/Formulario.tsx:182–185` orienta a interface. Uma submissão pode conter combinações que o fluxo normal do formulário não oferece, afetando a integridade do recurso.

Correção pendente. Consultar o catálogo canônico no servidor, verificar grau, tipo, unidade e indicador em conjunto e derivar os nomes a partir dos códigos aprovados. Aplicar o vínculo entre conta e unidade de acordo com as regras de acesso do TJAC.

### 2. Verificação incompleta de conteúdo de anexos

Em `Code.gs:354–366,377–379` e `apps-script/Code.gs:319–331`, o MIME vem do cliente. O único exame de conteúdo é o prefixo de PDF. O Drive recebe o arquivo com o MIME declarado. A equipe pode receber anexos cujo conteúdo diverge do tipo exibido.

Correção parcial no patch. Restringe a lista a chaves próprias e rejeita base64 acima do limite antes da decodificação. Ainda é necessário validar o formato real, inclusive a estrutura interna dos documentos Office, e verificar permissões da pasta e a política de quarentena antes de disponibilizar anexos aos avaliadores.

## Média prioridade

### 3. Rascunho persistente em navegador compartilhado

`components/Formulario.tsx:119–154` lê e grava um rascunho em `localStorage`. A remoção ocorre após envio bem-sucedido em `components/Formulario.tsx:459`. Isso pode expor dados do rascunho em perfis compartilhados.

Correção pendente. Evitar persistir dados pessoais ou texto sensível e prever descarte explícito e expiração para os campos que precisem sobreviver a uma recarga.

### 4. Tipos de entrada e limites inconsistentes

`Code.gs:144–164,710–779` interpreta o JSON sem validar previamente o formato do objeto, aceita coerções e itera pelos itens mesmo após detectar excesso. A marcação de impugnação também usa coerção booleana. `utils.ts:126–192` cobre regras de UX, mas a API precisa aplicar as regras de integridade de forma independente.

O patch limita o corpo antes do parse, valida o envelope e a estrutura dos itens, restringe o despacho à lista de ações e exige booleano literal para ativar a impugnação. Ainda é necessário validar estritamente os tipos dos campos individuais, rejeitar pontuações fornecidas fora da faixa e alinhar os limites de comprimento no cliente e servidor.

### 5. Upload concorrente com a finalização

`Code.gs:358–373,392–413` consulta o estado do protocolo antes de adquirir o lock do upload. Uma finalização concorrente pode alterar o estado antes da gravação do anexo. O patch repete a verificação de proprietário e estado dentro do lock. O fluxo entre Drive e planilha ainda deve ser validado para falhas parciais e novas tentativas.

## Verificação e implantação

O JavaScript resultante das duas cópias passou no `node --check`. A verificação foi estática. A versão implantada, as permissões reais do Drive, os cabeçalhos de produção e o comportamento de Google Sheets e Apps Script em execução continuam pendentes de verificação.

Antes da implantação, testar em ambiente separado um recurso por indicador, uma impugnação apenas da lista de servidores, anexos válidos no tamanho limite e a finalização durante um upload. Confirmar qual cópia do Apps Script é a fonte da implantação.
