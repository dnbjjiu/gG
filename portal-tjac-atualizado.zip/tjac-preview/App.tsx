import React, { useCallback, useEffect, useState } from 'react';
import { Ellipsis } from 'lucide-react';
import { PORTARIA } from './catalogo';
import { AnaliseRecurso } from './components/AnaliseRecurso';
import { Comprovante } from './components/Comprovante';
import { Formulario } from './components/Formulario';
import { Instrucoes } from './components/Instrucoes';
import { PaginaInicial } from './components/PaginaInicial';
import { LogoTJAC } from './components/LogoTJAC';
import { MeusRecursos } from './components/MeusRecursos';
import { PainelAdmin } from './components/PainelAdmin';
import { Aviso } from './components/ui';
import { MODO_DEMO, ehAdmin } from './config';
import { ApiError, api } from './services/api';
import { lerToken, sairGoogle, tokenValido } from './services/auth';
import type { ConfigServidor, ResultadoEnvio, Usuario } from './types';
import { formatarDataHora } from './utils';

type Aba = 'form' | 'meus' | 'analise' | 'admin' | 'instrucoes';
type AbaPublica = 'login' | 'instrucoes';
type Perfil = 'unidade' | 'admin';
const CHAVE_SESSAO = 'premio-tjac-2026:sessao-v2';

function sessaoInicial(): { token: string; usuario: Usuario; perfil: Perfil } | null {
  try {
    const salvo = sessionStorage.getItem(CHAVE_SESSAO);
    if (!salvo) return null;
    const { token: t, perfil } = JSON.parse(salvo);
    if (perfil !== 'admin' && perfil !== 'unidade') return null;
    if (!t) return null;
    const u = lerToken(t);
    return tokenValido(u) && Boolean(u.demo) === MODO_DEMO ? { token: t, usuario: u, perfil } : null;
  } catch {
    return null;
  }
}

export default function App() {
  const [sessao, setSessao] = useState(sessaoInicial);
  const [abaPublica, setAbaPublica] = useState<AbaPublica>('login');
  const [config, setConfig] = useState<ConfigServidor | null>(null);
  const [erroConfig, setErroConfig] = useState('');
  const [aba, setAba] = useState<Aba>('form');
  const [perfilEntrada, setPerfilEntrada] = useState<Perfil | null>(null);
  const [menuAberto, setMenuAberto] = useState(false);
  const [protocoloAnalise, setProtocoloAnalise] = useState<string>('');
  const [resultado, setResultado] = useState<ResultadoEnvio | null>(null);
  const [msgLogin, setMsgLogin] = useState('');

  const usuarioEhAdmin = sessao?.perfil === 'admin' && !!config && ehAdmin(config.usuario.email);

  const abrirAnaliseProtocolo = useCallback((protocolo: string) => {
    setProtocoloAnalise(protocolo);
    setAba('analise');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const onToken = useCallback((token: string, perfil: Perfil) => {
    try {
      const usuario = lerToken(token);
      try {
        sessionStorage.setItem(CHAVE_SESSAO, JSON.stringify({ token, perfil }));
      } catch {
        /* segue só em memória */
      }
      setMsgLogin('');
      setSessao({ token, usuario, perfil });
      setConfig(null);
      setAba('form');
    } catch {
      setMsgLogin('Não foi possível ler a credencial do Google. Tente novamente.');
    }
  }, []);

  const sair = useCallback((mensagem = '') => {
    try {
      sessionStorage.removeItem(CHAVE_SESSAO);
    } catch {
      /* idem */
    }
    sairGoogle();
    setSessao(null);
    setConfig(null);
    setPerfilEntrada(null);
    setMenuAberto(false);
    setResultado(null);
    setProtocoloAnalise('');
    setAba('form');
    setAbaPublica('login');
    setMsgLogin(mensagem);
  }, []);

  useEffect(() => {
    if (!sessao) return;
    let ativo = true;
    setErroConfig('');
    api
      .config(sessao.token)
      .then((dados) => {
        if (!ativo) return;
        if (sessao.perfil === 'admin' && !ehAdmin(dados.usuario.email)) {
          sair('Sua conta não tem permissão para entrar na administração. Escolha Unidade Judiciária.');
          return;
        }
        if (sessao.perfil === 'unidade' && !dados.usuario.email.toLowerCase().endsWith('@tjac.jus.br')) {
          sair('Para entrar como Unidade Judiciária, use sua conta institucional do TJAC.');
          return;
        }
        setAba(sessao.perfil === 'admin' ? 'admin' : 'form');
        setConfig(dados);
      })
      .catch((e) => {
        if (!ativo) return;
        if (
          e instanceof ApiError &&
          ['TOKEN_EXPIRADO', 'TOKEN_INVALIDO', 'NAO_AUTENTICADO'].includes(e.codigo)
        ) {
          return sair('Sessão expirada. Entre novamente.');
        }
        if (
          e instanceof ApiError &&
          ['NAO_AUTORIZADO', 'DOMINIO_NAO_PERMITIDO', 'EMAIL_NAO_VERIFICADO'].includes(e.codigo)
        ) {
          return sair(e.message);
        }
        setErroConfig(e instanceof Error ? e.message : 'Falha ao carregar a configuração.');
      });
    return () => { ativo = false; };
  }, [sessao, sair]);

  const abasDisponiveis: readonly [Aba, string][] = usuarioEhAdmin
    ? [
        ['admin', 'Painel Administrador'],
        ['analise', 'Análise do Recurso'],
        ['form', 'Novo recurso'],
        ['meus', 'Meus recursos'],
        ['instrucoes', 'Instruções'],
      ]
    : [
        ['form', 'Novo recurso'],
        ['meus', 'Meus recursos'],
        ['instrucoes', 'Instruções'],
      ];

  if (!sessao && abaPublica === 'login') {
    return <PaginaInicial
      perfil={perfilEntrada}
      onEscolher={setPerfilEntrada}
      onToken={onToken}
      mensagem={msgLogin}
      onInstrucoes={() => setAbaPublica('instrucoes')}
    />;
  }

  return (
    <div className="min-h-screen bg-fundo text-tinta font-[Archivo,system-ui,sans-serif]">
      <header hidden={!sessao && abaPublica === 'login'} className="bg-carmim text-white print:hidden shadow-sm">
        <div className={`flex flex-wrap items-center justify-between gap-4 py-4 sm:py-5 ${sessao && config ? 'px-3 sm:px-4' : 'mx-auto max-w-5xl px-4 sm:px-6'}`}>
          <div className="flex flex-wrap items-center gap-4 sm:gap-5">
            {sessao && config && (
              <button
                type="button"
                aria-expanded={menuAberto}
                aria-controls="menu-sessao"
                aria-label={menuAberto ? 'Fechar menu' : 'Abrir menu'}
                onClick={() => setMenuAberto(!menuAberto)}
                className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-md border border-white/50 px-3 text-sm font-semibold text-white hover:bg-white/15 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <Ellipsis size={20} aria-hidden="true" />
                Menu
              </button>
            )}
            <LogoTJAC variante="branco" mostrarSubtituloPortal={false} />
            <div className="hidden sm:block h-10 w-px bg-white/25" aria-hidden="true" />
            <div>
              <p className="text-[11px] uppercase tracking-[0.16em] text-white/75 font-semibold">
                Tribunal de Justiça do Estado do Acre · DIGED / SUMAE
              </p>
              <h1 className="text-lg sm:text-xl font-bold leading-tight">
                Prêmio TJAC de Qualidade 2026
              </h1>
              <p className="text-xs sm:text-sm text-white/85">
                Formulário e Gestão de Recursos ao Resultado Preliminar
              </p>
            </div>
          </div>

          {sessao && (
            <div className="flex items-center gap-3 bg-carmimEscuro/60 border border-white/15 rounded-lg px-3.5 py-2">
              {sessao.usuario.foto && (
                <img
                  src={sessao.usuario.foto}
                  alt=""
                  className="w-9 h-9 rounded-full border-2 border-white/40"
                  referrerPolicy="no-referrer"
                />
              )}
              <div className="text-right text-sm leading-tight">
                <div className="flex items-center justify-end gap-1.5">
                  <p className="font-semibold truncate max-w-[200px]">{sessao.usuario.nome}</p>
                  {usuarioEhAdmin && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-ouro text-white">
                      Admin
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-white/75 font-mono truncate max-w-[220px]">
                  {sessao.usuario.email}
                </p>
                <button
                  className="text-white/85 hover:text-white text-xs underline mt-0.5 cursor-pointer"
                  onClick={() => sair()}
                >
                  Encerrar sessão
                </button>
              </div>
            </div>
          )}
        </div>
        <div className="h-1 bg-gradient-to-r from-ouro via-ouro/70 to-verde" />
      </header>

      <main className={`mx-auto px-4 sm:px-6 space-y-6 ${sessao ? 'max-w-7xl py-8' : 'max-w-5xl py-4'}`}>
        {MODO_DEMO && sessao && (
          <Aviso tipo="alerta">
            <b>Modo demonstração</b> — os protocolos de exemplo e os novos recursos enviados nesta
            sessão são simulados localmente para avaliação completa do fluxo e do Painel Administrador.
          </Aviso>
        )}

        {!sessao && (
          <div className="space-y-6">
            <div className="flex justify-center print:hidden">
              <nav aria-label="Navegação pública" className="inline-flex bg-white border border-linha rounded-lg p-1 text-sm shadow-2xs">
                <button
                  type="button"
                  onClick={() => setAbaPublica('login')}
                  aria-pressed={abaPublica === 'login'}
                  className={`px-5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                    abaPublica === 'login'
                      ? 'bg-carmim text-white'
                      : 'text-suave hover:text-tinta'
                  }`}
                >
                  Login
                </button>
                <button
                  type="button"
                  onClick={() => setAbaPublica('instrucoes')}
                  aria-pressed={abaPublica === 'instrucoes'}
                  className={`px-5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                    abaPublica === 'instrucoes'
                      ? 'bg-carmim text-white'
                      : 'text-suave hover:text-tinta'
                  }`}
                >
                  Instruções
                </button>
              </nav>
            </div>

            <Instrucoes onIrParaLogin={() => setAbaPublica('login')} />
          </div>
        )}

        {sessao && !config && !erroConfig && (
          <p className="text-sm text-suave">Carregando configuração…</p>
        )}
        {sessao && erroConfig && <Aviso tipo="erro">{erroConfig}</Aviso>}

        {sessao && config && (
          <div className="space-y-4">
            <div className={menuAberto ? 'grid items-start gap-5 md:grid-cols-[12rem_minmax(0,1fr)] print:block' : ''}>
            <aside id="menu-sessao" hidden={!menuAberto} className="rounded-lg border border-linha bg-white p-2 md:sticky md:top-4 print:hidden">
              <nav aria-label={usuarioEhAdmin ? 'Menu da Administração' : 'Menu da Unidade Judiciária'} className="grid gap-1">
                {abasDisponiveis.map(([id, rot]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      setAba(id);
                      setMenuAberto(false);
                    }}
                    aria-current={aba === id ? 'page' : undefined}
                    className={`min-h-[44px] rounded-md px-3 py-2 text-left text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-carmim ${
                      aba === id ? 'bg-carmim text-white' : 'text-tinta hover:bg-fundo'
                    }`}
                  >
                    {rot}
                  </button>
                ))}
              </nav>
            </aside>

            <div className="min-w-0 space-y-4">
              <p
                className={`text-xs font-medium ${
                  config.prazo.aberto ? 'text-verde' : 'text-carmim'
                }`}
              >
                {config.prazo.aberto ? '● Prazo aberto' : '● Prazo encerrado'} · até{' '}
                {formatarDataHora(config.prazo.fim)}
              </p>

              {aba === 'admin' && usuarioEhAdmin && (
                <PainelAdmin
                  idToken={sessao.token}
                  usuario={sessao.usuario}
                  onAbrirAnalise={usuarioEhAdmin ? abrirAnaliseProtocolo : undefined}
                />
              )}

              {aba === 'analise' && usuarioEhAdmin && (
                <AnaliseRecurso
                  idToken={sessao.token}
                  usuario={sessao.usuario}
                  protocoloInicial={protocoloAnalise}
                  onSelecionarProtocolo={(prot) => setProtocoloAnalise(prot)}
                  onVoltarLista={() => setAba(usuarioEhAdmin ? 'admin' : 'meus')}
                />
              )}

              {aba === 'form' && !resultado && (
                <Formulario
                  usuario={sessao.usuario}
                  idToken={sessao.token}
                  config={config}
                  onEnviado={(r) => {
                    setResultado(r);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onSessaoExpirada={() =>
                    sair(
                      'Sua sessão expirou. Entre novamente: o rascunho foi preservado (anexe os arquivos de novo).'
                    )
                  }
                />
              )}
              {aba === 'form' && resultado && (
                <Comprovante r={resultado} onNovo={() => setResultado(null)} />
              )}
              {aba === 'meus' && (
                <MeusRecursos
                  idToken={sessao.token}
                  onAbrirAnalise={usuarioEhAdmin ? abrirAnaliseProtocolo : undefined}
                />
              )}
              {aba === 'instrucoes' && <Instrucoes />}
            </div>
          </div>
          </div>
        )}

        <footer className="text-center text-[11px] text-suave pt-6 print:hidden">
          Poder Judiciário do Estado do Acre · {PORTARIA} · DIGED/SUMAE/SEGOV
        </footer>
      </main>
    </div>
  );
}
