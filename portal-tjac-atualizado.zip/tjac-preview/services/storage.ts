import { storage, ref, uploadBytes, getDownloadURL, firebaseConfig } from '../firebase';

export interface UploadStorageParametros {
  protocolo: string;
  codUnidade?: string;
  itemN: number;
  sigla: string;
  nomeArquivo: string;
  mime: string;
  base64?: string;
  arquivo?: Blob | Uint8Array;
  sha256?: string;
  emailGoogle?: string;
}

export interface ResultadoUploadStorage {
  storagePath: string;
  downloadUrl: string;
  bucket: string;
}

function base64ParaUint8Array(b64: string): Uint8Array {
  if (typeof atob === 'function') {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
      bytes[i] = bin.charCodeAt(i);
    }
    return bytes;
  }
  return new Uint8Array(0);
}

export function construirCaminhoStorageEvidencia(params: {
  protocolo: string;
  codUnidade?: string;
  itemN: number;
  sigla: string;
  nomeArquivo: string;
}): string {
  const unidSegura = (params.codUnidade || 'UNID').replace(/[^A-Za-z0-9_-]/g, '_');
  const protSeguro = params.protocolo.replace(/[^A-Za-z0-9_-]/g, '_');
  const siglaSegura = params.sigla.replace(/[^A-Za-z0-9_-]/g, '_');
  const itemPrefix = `${String(params.itemN).padStart(2, '0')}_${siglaSegura}`;
  const nomeLimpo = params.nomeArquivo.replace(/[\\/:*?"<>|#%]/g, '_').trim() || 'evidencia.pdf';
  return `recursos-premio-tjac-2026/${unidSegura}/${protSeguro}/${itemPrefix}/${nomeLimpo}`;
}

export async function enviarEvidenciaFirebaseStorage(
  params: UploadStorageParametros
): Promise<ResultadoUploadStorage> {
  const storagePath = construirCaminhoStorageEvidencia(params);
  const storageRef = ref(storage, storagePath);

  const conteudo: Blob | Uint8Array =
    params.arquivo || (params.base64 ? base64ParaUint8Array(params.base64) : new Uint8Array(0));

  await uploadBytes(storageRef, conteudo, {
    contentType: params.mime || 'application/pdf',
    customMetadata: {
      protocolo: params.protocolo,
      itemN: String(params.itemN),
      sigla: params.sigla,
      sha256: params.sha256 || '',
      emailGoogle: params.emailGoogle || '',
    },
  });

  const downloadUrl = await getDownloadURL(storageRef);

  return {
    storagePath,
    downloadUrl,
    bucket: firebaseConfig.storageBucket || '',
  };
}
