import { UNIDADES_PADRAO } from '../catalogo';
import {
  API_URL,
  LIMITES_PADRAO,
  MODO_DEMO,
  PASTA_PROTOCOLO_DRIVE_URL,
  PASTA_RAIZ_DRIVE_URL,
  PLANILHA_MESTRA_URL,
  PRAZO_PADRAO,
  PROTOCOLO_FOLDER_ID,
  ehAdmin,
  podeAtuarComoComissao,
  podeAtuarComoSumae,
} from '../config';
import type {
  AnaliseRecursoProtocolo,
  AtualizarItemAdminPayload,
  ConfigServidor,
  CriarRecursoPayload,
  DadosAdminResposta,
  RecursoAdmin,
  RecursoResumo,
  SalvarDecisaoComissaoPayload,
  SalvarParecerSumaePayload,
  StatusAnalise,
} from '../types';
import { numeroOuVazio, validarPayloadRecurso } from '../utils';
import {
  criarAnaliseInicialParaRecurso,
  detectarFaltaEvidenciaRecurso,
  gerarCodigosAutenticidadeSei,
  resolverVinculoSeiProtocolo,
  validarEmissaoDecisaoComissao,
  validarEmissaoParecerSumae,
} from './analiseLogica';
import { lerToken, tokenValido } from './auth';
import { enviarEvidenciaFirebaseStorage } from './storage';

export class ApiError extends Error {
  codigo: string;
  constructor(codigo: string, message: string) {
    super(message);
    this.name = 'ApiError';
    this.codigo = codigo;
  }
}

interface DemoProtocoloSalvo extends RecursoAdmin {
  clientRequestId: string;
}

const CHAVE_DEMO_DB = 'premio-tjac-2026:demo-recursos-v4';
const CHAVE_PLANILHA_MESTRA = 'premio-tjac-2026:planilha-mestra-url';

export function obterPlanilhaMestraUrl(): string {
  if (PLANILHA_MESTRA_URL.trim()) return PLANILHA_MESTRA_URL.trim();
  try {
    return localStorage.getItem(CHAVE_PLANILHA_MESTRA) || '';
  } catch {
    return '';
  }
}

export function salvarPlanilhaMestraUrl(url: string): void {
  try {
    if (url.trim()) {
      localStorage.setItem(CHAVE_PLANILHA_MESTRA, url.trim());
    } else {
      localStorage.removeItem(CHAVE_PLANILHA_MESTRA);
    }
  } catch {
    /* ignora storage indisponível */
  }
}

function criarRecursosIniciaisDemo(): DemoProtocoloSalvo[] {
  return [
    {
      protocolo: 'RTQ-2026-00001',
      status: 'ENVIADO',
      criadoEm: '2026-12-04T14:15:00.000Z',
      enviadoEm: '2026-12-04T14:18:22.000Z',
      emailGoogle: '1civel.rb@tjac.jus.br',
      clientRequestId: 'seed-req-00001',
      responsavel: {
        nome: 'Dra. Helena Albuquerque',
        cpf: '52998224725',
        cargo: 'Juiz(a) de Direito Titular',
        telefone: '(68) 3212-8201',
      },
      unidade: {
        grau: '1G',
        tipo: 'CIVEL',
        codigo: 'RB-1CIV',
        nome: '1ª Vara Cível da Comarca de Rio Branco',
        comarca: 'Rio Branco',
      },
      qtdItens: 2,
      impugnaListaServidores: false,
      impugnacaoListaTexto: '',
      pastaId: PROTOCOLO_FOLDER_ID,
      pastaUrl: PASTA_PROTOCOLO_DRIVE_URL,
      declaracaoVeracidade: true,
      itens: [
        {
          protocolo: 'RTQ-2026-00001',
          itemN: 1,
          grupo: '1º Grau — Indicadores Gerais',
          sigla: 'IAD-C',
          indicador: 'Índice de Atendimento à Demanda — Critério Conjugado',
          subitem: 'Condição de Compensação pela Taxa de Congestionamento Líquida (TCL < 25%)',
          tipoImpugnacao: 'FAIXA_ARREDONDAMENTO',
          pontuacaoPreliminar: 0,
          pontuacaoPleiteada: 80,
          fundamentacao:
            'Conforme extrato do Painel de BI do PJAC (Intranet Institucional) com data de corte em 30/11/2026 às 23h59min59s, a 1ª Vara Cível da Comarca de Rio Branco alcançou IAD de 96,42% (2.154 processos baixados para 2.234 casos novos no período de 01/01/2026 a 30/11/2026) e Taxa de Congestionamento Líquida (TCL) de 23,18% (< 25%). Nos termos do art. 8º, parágrafo único, II, e Anexo IV, item 1, da Portaria PRESI nº 1961/2026 (alterada pela Portaria PRESI nº 4335/2026), aplica-se a regra de compensação para atribuir 80 pontos no indicador IAD-C.',
          evidencias: { a: true, b: true, c: true, d: true, e: true },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 2,
          statusAnalise: 'EM_ANALISE',
          relator: 'Comissão Revisora — DIGED',
          parecer: 'Em conferência dos filtros de casos novos e baixados no painel de BI do PJAC.',
          decisao: '',
          pontuacaoFinal: '',
          dataDecisao: '',
          arquivos: [
            {
              protocolo: 'RTQ-2026-00001',
              itemN: 1,
              sigla: 'IAD-C',
              nome: 'Extrato_Painel_BI_PJAC_IAD-C_1CIV_2026.pdf',
              mime: 'application/pdf',
              bytes: 482910,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
              enviadoEm: '2026-12-04T14:16:40.000Z',
              emailGoogle: '1civel.rb@tjac.jus.br',
            },
            {
              protocolo: 'RTQ-2026-00001',
              itemN: 1,
              sigla: 'IAD-C',
              nome: 'Relacao_Nominal_2154_Processos_Baixados_1CIV.xlsx',
              mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
              bytes: 319488,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
              enviadoEm: '2026-12-04T14:17:15.000Z',
              emailGoogle: '1civel.rb@tjac.jus.br',
            },
          ],
        },
        {
          protocolo: 'RTQ-2026-00001',
          itemN: 2,
          grupo: '1º Grau — Indicadores Gerais',
          sigla: 'ISU',
          indicador: 'Índice de Saneamento e/ou Consistência de Dados',
          subitem: 'Média Geral dos 4 Componentes (C1 a C4)',
          tipoImpugnacao: 'APURACAO',
          pontuacaoPreliminar: 55,
          pontuacaoPleiteada: 70,
          fundamentacao:
            'No Painel de Saneamento do BI PJAC (data de corte 30/11/2026), os 4 componentes da unidade registraram: C1 (Classe) = 99,8%, C2 (Assunto) = 99,4%, C3 (Partes) = 98,9% e C4 (Movimentos) = 99,1%, resultando em média geral de 99,30% (≥ 99%), faixa que confere 70 pontos conforme Anexo IV, item 5.',
          evidencias: { a: true, b: true, c: true, d: true, e: true },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 1,
          statusAnalise: 'PROVIDO',
          relator: 'Josué Silva (DIGED)',
          parecer: 'Confirmada a média de 99,30% nos quatro componentes C1 a C4 até 30/11/2026.',
          decisao: 'Deferido o reenquadramento na faixa máxima (70 pontos).',
          pontuacaoFinal: 70,
          dataDecisao: '2026-12-05T16:30:00.000Z',
          arquivos: [
            {
              protocolo: 'RTQ-2026-00001',
              itemN: 2,
              sigla: 'ISU',
              nome: 'Painel_Saneamento_ISU_Componentes_C1_C4.pdf',
              mime: 'application/pdf',
              bytes: 294120,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
              enviadoEm: '2026-12-04T14:18:01.000Z',
              emailGoogle: '1civel.rb@tjac.jus.br',
            },
          ],
        },
      ],
    },
    {
      protocolo: 'RTQ-2026-00002',
      status: 'ENVIADO',
      criadoEm: '2026-12-05T10:05:00.000Z',
      enviadoEm: '2026-12-05T10:09:45.000Z',
      emailGoogle: 'vep.rb@tjac.jus.br',
      clientRequestId: 'seed-req-00002',
      responsavel: {
        nome: 'Dr. Marcos Vinícius Nogueira',
        cpf: '11144477735',
        cargo: 'Juiz(a) de Direito Titular',
        telefone: '(68) 3212-8310',
      },
      unidade: {
        grau: '1G',
        tipo: 'VEP',
        codigo: 'RB-VEP',
        nome: 'Vara de Execuções Penais e Medidas Alternativas de Rio Branco',
        comarca: 'Rio Branco',
      },
      qtdItens: 1,
      impugnaListaServidores: true,
      impugnacaoListaTexto:
        'Solicita-se a inclusão da servidora Ana Paula Moura (Matrícula 30491-2), lotada ininterruptamente nesta Vara de Execuções Penais desde 15/03/2026 (mais de 8 meses anteriores a 30/11/2026), conforme Portaria de Lotação nº 812/2026 e registro oficial no sistema MPM, cumprindo integralmente o requisito do art. 6º da Portaria PRESI nº 1961/2026.',
      pastaId: PROTOCOLO_FOLDER_ID,
      pastaUrl: PASTA_PROTOCOLO_DRIVE_URL,
      declaracaoVeracidade: true,
      itens: [
        {
          protocolo: 'RTQ-2026-00002',
          itemN: 1,
          grupo: '1º Grau — Indicadores Temáticos',
          sigla: 'IPV-PR/LC-SEEU',
          indicador:
            'Índice de Julgamento dos Incidentes de Progressão de Regime e Livramento Condicional Vencidos no SEEU',
          subitem: 'Apuração Geral no SEEU',
          tipoImpugnacao: 'APURACAO',
          pontuacaoPreliminar: 30,
          pontuacaoPleiteada: 60,
          fundamentacao:
            'De acordo com o relatório oficial extraído do Sistema Eletrônico de Execução Unificado (SEEU) em 30/11/2026 às 23h55, do total de 1.840 execuções penais ativas, apenas 14 incidentes de progressão de regime e livramento condicional constavam vencidos, correspondendo ao índice de 0,76% (≤ 1,0%), fazendo jus a 60 pontos conforme Anexo IV, item 14.',
          evidencias: { a: true, b: true, c: true, d: true, e: true },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 1,
          statusAnalise: 'PENDENTE',
          relator: '',
          parecer: '',
          decisao: '',
          pontuacaoFinal: '',
          dataDecisao: '',
          arquivos: [
            {
              protocolo: 'RTQ-2026-00002',
              itemN: 1,
              sigla: 'IPV-PR/LC-SEEU',
              nome: 'Relatorio_SEEU_Incidentes_Vencidos_30_11_2026.pdf',
              mime: 'application/pdf',
              bytes: 612040,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
              enviadoEm: '2026-12-05T10:08:50.000Z',
              emailGoogle: 'vep.rb@tjac.jus.br',
            },
          ],
        },
      ],
    },
    {
      protocolo: 'RTQ-2026-00003',
      status: 'ENVIADO',
      criadoEm: '2026-12-05T15:40:00.000Z',
      enviadoEm: '2026-12-05T15:44:12.000Z',
      emailGoogle: 'gab1.1cc@tjac.jus.br',
      clientRequestId: 'seed-req-00003',
      responsavel: {
        nome: 'Bel. Ricardo Fontes de Oliveira',
        cpf: '39053344705',
        cargo: 'Assessor(a) de Gabinete',
        telefone: '(68) 3302-0415',
      },
      unidade: {
        grau: '2G',
        tipo: 'GAB_CIVEL',
        codigo: '2G-1CC-G1',
        nome: 'Gabinete de Desembargador(a) — 1ª Câmara Cível (Gabinete 1)',
        comarca: 'Rio Branco',
      },
      qtdItens: 1,
      impugnaListaServidores: false,
      impugnacaoListaTexto: '',
      pastaId: PROTOCOLO_FOLDER_ID,
      pastaUrl: PASTA_PROTOCOLO_DRIVE_URL,
      declaracaoVeracidade: true,
      itens: [
        {
          protocolo: 'RTQ-2026-00003',
          itemN: 1,
          grupo: '2º Grau — Precedentes Qualificados',
          sigla: 'IRDR/IAC-TESE',
          indicador: 'IRDR/IAC Julgado com Tese Fixada no Período (25 pts por evento, até 2)',
          subitem: 'Contabilização de IRDR/IAC julgado com tese fixada pelo Gabinete',
          tipoImpugnacao: 'APURACAO',
          pontuacaoPreliminar: 25,
          pontuacaoPleiteada: 50,
          fundamentacao:
            'O Gabinete 1 da 1ª Câmara Cível relatou e julgou com fixação de tese jurídica no Pleno dois Incidentes de Resolução de Demandas Repetitivas no período-base (IRDR nº 1000412-88.2025.8.01.0000, julgado em 14/05/2026, e IRDR nº 1000891-42.2025.8.01.0000, julgado em 22/09/2026), perfazendo 50 pontos (2 eventos × 25 pts) nos termos do Anexo I, item E, e Anexo IV, item 18.',
          evidencias: { a: true, b: true, c: true, d: true, e: true },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 1,
          statusAnalise: 'PENDENTE',
          relator: '',
          parecer: '',
          decisao: '',
          pontuacaoFinal: '',
          dataDecisao: '',
          arquivos: [
            {
              protocolo: 'RTQ-2026-00003',
              itemN: 1,
              sigla: 'IRDR/IAC-TESE',
              nome: 'Acordaos_Fixacao_Tese_IRDR_2026_Gab1.pdf',
              mime: 'application/pdf',
              bytes: 845120,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: 'e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683',
              enviadoEm: '2026-12-05T15:43:20.000Z',
              emailGoogle: 'gab1.1cc@tjac.jus.br',
            },
          ],
        },
      ],
    },
    {
      protocolo: 'RTQ-2026-00004',
      status: 'ENVIADO',
      criadoEm: '2026-12-06T11:10:00.000Z',
      enviadoEm: '2026-12-06T11:15:30.000Z',
      emailGoogle: 'vacri1bj@tjac.jus.br',
      clientRequestId: 'seed-req-00004',
      processoSei: '0013175-86.2026.8.01.0000',
      estadoTramitacao: 'ENCAMINHADO_COMISSAO',
      responsavel: {
        nome: 'Dr. Manoel Simões Pedroga',
        cpf: '28625587887',
        cargo: 'Juiz(a) de Direito Titular',
        telefone: '(68) 99223-5354',
      },
      unidade: {
        grau: '1G',
        tipo: 'VARA_UNICA',
        codigo: 'BJ-VU',
        nome: 'Vara Única da Comarca de Bujari',
        comarca: 'Bujari',
      },
      qtdItens: 1,
      impugnaListaServidores: false,
      impugnacaoListaTexto: '',
      pastaId: PROTOCOLO_FOLDER_ID,
      pastaUrl: PASTA_PROTOCOLO_DRIVE_URL,
      declaracaoVeracidade: true,
      itens: [
        {
          protocolo: 'RTQ-2026-00004',
          itemN: 1,
          grupo: '1º Grau — Indicadores Gerais',
          sigla: 'IAD-C',
          indicador: 'Índice de Atendimento à Demanda — Critério Conjugado (TCL)',
          subitem: 'Taxa de Congestionamento Líquida (TCL)',
          tipoImpugnacao: 'FONTE_DADOS',
          pontuacaoPreliminar: 0,
          pontuacaoPleiteada: 40,
          fundamentacao:
            'A revisão justifica-se por divergência metodológica na apuração do indicador TCL, uma vez que o painel interno do TJAC apontou TCL de 52,30% (0 pontos), enquanto no Painel de Estatísticas do CNJ (DataJud) constariam 598 processos baixados, 667 casos novos e 1.176 pendentes (TCL de 32,39%), pleiteando-se 40 pontos.',
          // Nota: Evidência obrigatória (e) ausente conforme Parecer Técnico SUMAE n.º 001 (não anexou relação nominal dos 69 processos)
          evidencias: { a: true, b: true, c: true, d: true, e: false },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 1,
          statusAnalise: 'EM_ANALISE',
          relator: 'Equipe SUMAE',
          parecer:
            'A unidade não anexou relação nominal dos processos específicos que demonstrem a divergência numérica de 69 processos, e o DataJud encontra-se atualizado apenas até outubro.',
          decisao: '',
          pontuacaoFinal: '',
          dataDecisao: '',
          arquivos: [
            {
              protocolo: 'RTQ-2026-00004',
              itemN: 1,
              sigla: 'IAD-C',
              nome: 'Recurso_Administrativo_Vara_Unica_Bujari_TCL.pdf',
              mime: 'application/pdf',
              bytes: 518240,
              fileId: PROTOCOLO_FOLDER_ID,
              url: PASTA_PROTOCOLO_DRIVE_URL,
              sha256: '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b',
              enviadoEm: '2026-12-06T11:14:10.000Z',
              emailGoogle: 'vacri1bj@tjac.jus.br',
            },
          ],
        },
      ],
    },
  ];
}

function garantirAnaliseNoProtocolo(rec: DemoProtocoloSalvo): AnaliseRecursoProtocolo {
  if (!rec.analise) {
    const mapSeiPadrao: Record<string, string> = {
      'RTQ-2026-00001': '0013171-49.2026.8.01.0000',
      'RTQ-2026-00002': '0013172-34.2026.8.01.0000',
      'RTQ-2026-00003': '0013173-19.2026.8.01.0000',
      'RTQ-2026-00004': '0013175-86.2026.8.01.0000',
    };
    const sei = rec.processoSei || mapSeiPadrao[rec.protocolo];
    const analise = criarAnaliseInicialParaRecurso(rec, sei);

    // Para o protocolo RTQ-2026-00004 (Vara Única de Bujari), já pré-carregamos o Parecer Técnico SUMAE n.º 001 emitido conforme o PDF anexo
    if (rec.protocolo === 'RTQ-2026-00004') {
      analise.estadoTramitacao = 'ENCAMINHADO_COMISSAO';
      analise.parecerSumae.numeroParecer = '001/2026';
      analise.parecerSumae.statusDocumento = 'EMITIDO';
      analise.parecerSumae.versao = 1;
      analise.parecerSumae.emitidoEm = '2026-12-12T14:05:00.000Z';
      analise.parecerSumae.atualizadoEm = '2026-12-12T14:05:00.000Z';
      analise.parecerSumae.codigoVerificadorSei = '2284219';
      analise.parecerSumae.codigoCrcSei = 'B42FFA0E';
      analise.parecerSumae.ultimoEmissionId = 'seed-emissao-sumae-00004';
      analise.parecerSumae.possuiFaltaEvidenciaObrigatoria = true;
      analise.parecerSumae.registroFaltasEvidencias =
        '1. A unidade não anexou relação nominal de processos específicos que demonstrem a divergência numérica de 69 processos (Anexo III, item 3, "e").\n2. Os registros de tela enviados são insuficientes para auditoria cruzada.\n3. O DataJud/CNJ reflete fechamento somente até outubro, não incorporando as movimentações de novembro.';
      analise.historicoDocumentos.push({
        id: 'doc-hist-sumae-00004-v1',
        protocolo: rec.protocolo,
        processoSei: analise.processoSei,
        tipo: 'PARECER_SUMAE',
        versao: 1,
        numeroDocumento: '001/2026',
        autoriaNome: 'Elino Silva de Mendonça / Josué da Silva Santos / Equipe SUMAE',
        autoriaCargo: 'Subsecretaria de Monitoramento e Análise Estratégica — SUMAE/SEGOV',
        autoriaEmail: 'josue.silva@tjac.jus.br',
        emitidoEm: '2026-12-12T14:05:00.000Z',
        justificativaRetificacao: '',
        codigoVerificadorSei: '2284219',
        codigoCrcSei: 'B42FFA0E',
        resumo: 'Parecer Técnico SUMAE n.º 001/2026 emitido e encaminhado à Comissão Revisora.',
        snapshotParecer: JSON.parse(JSON.stringify(analise.parecerSumae)),
      });
    }

    rec.processoSei = analise.processoSei;
    rec.estadoTramitacao = analise.estadoTramitacao;
    rec.analise = analise;
  } else {
    rec.processoSei = rec.analise.processoSei;
    rec.estadoTramitacao = rec.analise.estadoTramitacao;
  }
  return rec.analise;
}

let memoriaDemoDb: DemoProtocoloSalvo[] | null = null;

function lerBancoDemo(): DemoProtocoloSalvo[] {
  try {
    const raw = localStorage.getItem(CHAVE_DEMO_DB);
    if (raw) {
      const parsed = JSON.parse(raw) as DemoProtocoloSalvo[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        parsed.forEach(garantirAnaliseNoProtocolo);
        memoriaDemoDb = parsed;
        return parsed;
      }
    }
  } catch {
    if (memoriaDemoDb && memoriaDemoDb.length > 0) {
      return memoriaDemoDb;
    }
  }
  const iniciais = criarRecursosIniciaisDemo();
  iniciais.forEach(garantirAnaliseNoProtocolo);
  salvarBancoDemo(iniciais);
  return iniciais;
}

function salvarBancoDemo(lista: DemoProtocoloSalvo[]): void {
  memoriaDemoDb = lista;
  try {
    localStorage.setItem(CHAVE_DEMO_DB, JSON.stringify(lista));
  } catch {
    /* ignora quota / ambiente Node */
  }
}

async function chamarAppsScript<T>(
  action: string,
  idToken: string,
  payload?: unknown
): Promise<T> {
  const resp = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({ action, idToken, payload }),
  });
  if (!resp.ok) {
    throw new ApiError('REDE', `Erro de comunicação com o servidor (HTTP ${resp.status}).`);
  }
  const json = await resp.json();
  if (!json || json.ok !== true) {
    const code = json?.error?.code || 'ERRO_INTERNO';
    const message = json?.error?.message || 'Erro ao processar a solicitação no servidor.';
    throw new ApiError(code, message);
  }
  return json.data as T;
}

function exigirUsuarioDemo(idToken: string) {
  const u = lerToken(idToken);
  if (!tokenValido(u)) {
    throw new ApiError('TOKEN_EXPIRADO', 'Sessão expirada. Entre novamente.');
  }
  return u;
}

function exigirAdminDemo(idToken: string) {
  const u = exigirUsuarioDemo(idToken);
  if (!ehAdmin(u.email)) {
    throw new ApiError(
      'NAO_AUTORIZADO',
      'Acesso restrito aos administradores do sistema (josue.silva@tjac.jus.br / arturgemeos06@gmail.com).'
    );
  }
  return u;
}

export const api = {
  async config(idToken: string): Promise<ConfigServidor> {
    if (!MODO_DEMO) {
      return chamarAppsScript<ConfigServidor>('config', idToken);
    }
    const u = exigirUsuarioDemo(idToken);
    return {
      usuario: { email: u.email, nome: u.nome, sub: u.sub },
      prazo: { ...PRAZO_PADRAO },
      unidades: UNIDADES_PADRAO,
      limites: { ...LIMITES_PADRAO },
      agoraServidor: new Date().toISOString(),
    };
  },

  async create(
    idToken: string,
    payload: CriarRecursoPayload
  ): Promise<{
    protocolo: string;
    status: string;
    reaproveitado: boolean;
    itens: { itemN: number; sigla: string; subitem: string; qtdArquivos: number }[];
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('create', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    const erros = validarPayloadRecurso(payload, LIMITES_PADRAO);
    if (erros.length > 0) {
      throw new ApiError('VALIDACAO', erros.join(' | '));
    }

    const db = lerBancoDemo();
    const existente = db.find(
      (r) => r.clientRequestId === payload.clientRequestId && r.emailGoogle === u.email
    );
    if (existente) {
      return {
        protocolo: existente.protocolo,
        status: existente.status,
        reaproveitado: true,
        itens: existente.itens.map((it) => ({
          itemN: it.itemN,
          sigla: it.sigla,
          subitem: it.subitem,
          qtdArquivos: it.qtdArquivos,
        })),
      };
    }

    const seq = db.length + 1;
    const protocolo = `RTQ-2026-${String(seq).padStart(5, '0')}`;
    const pastaId = PROTOCOLO_FOLDER_ID;
    const pastaUrl = PASTA_PROTOCOLO_DRIVE_URL;

    const novo: DemoProtocoloSalvo = {
      protocolo,
      status: 'EM_ENVIO',
      criadoEm: new Date().toISOString(),
      enviadoEm: '',
      emailGoogle: u.email,
      clientRequestId: payload.clientRequestId,
      responsavel: { ...payload.responsavel },
      unidade: { ...payload.unidade },
      qtdItens: payload.itens.length,
      impugnaListaServidores: payload.listaServidores.impugna,
      impugnacaoListaTexto: payload.listaServidores.texto,
      pastaId,
      pastaUrl,
      declaracaoVeracidade: payload.declaracao,
      itens: payload.itens.map((it, idx) => {
        const itemN = idx + 1;
        return {
          protocolo,
          itemN,
          grupo: it.grupo,
          sigla: it.sigla,
          indicador: it.indicador,
          subitem: it.subitem,
          tipoImpugnacao: it.tipoImpugnacao,
          pontuacaoPreliminar: it.pontuacaoPreliminar,
          pontuacaoPleiteada: it.pontuacaoPleiteada,
          fundamentacao: it.fundamentacao,
          evidencias: { ...it.evidencias },
          pastaItemUrl: PASTA_PROTOCOLO_DRIVE_URL,
          qtdArquivos: 0,
          statusAnalise: 'PENDENTE',
          relator: '',
          parecer: '',
          decisao: '',
          pontuacaoFinal: '',
          dataDecisao: '',
          arquivos: [],
        };
      }),
    };
    db.push(novo);
    salvarBancoDemo(db);

    return {
      protocolo,
      status: 'EM_ENVIO',
      reaproveitado: false,
      itens: novo.itens.map((it) => ({
        itemN: it.itemN,
        sigla: it.sigla,
        subitem: it.subitem,
        qtdArquivos: 0,
      })),
    };
  },

  async upload(
    idToken: string,
    payload: {
      protocolo: string;
      itemN: number;
      nome: string;
      mime: string;
      base64: string;
      bytes?: number;
      sha256?: string;
    }
  ): Promise<{
    protocolo: string;
    itemN: number;
    fileId: string;
    nome: string;
    bytes: number;
    sha256: string;
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('upload', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    if (!LIMITES_PADRAO.mimes.includes(payload.mime)) {
      throw new ApiError(
        'TIPO_ARQUIVO',
        `Tipo de arquivo não permitido: ${payload.mime || 'desconhecido'}.`
      );
    }
    const db = lerBancoDemo();
    const reg = db.find((r) => r.protocolo === payload.protocolo && r.emailGoogle === u.email);
    if (!reg) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    if (reg.status !== 'EM_ENVIO') {
      throw new ApiError('PROTOCOLO_FECHADO', 'Este protocolo já foi finalizado.');
    }
    const item = reg.itens.find((i) => i.itemN === payload.itemN);
    if (!item) {
      throw new ApiError('VALIDACAO', 'Item inexistente neste protocolo.');
    }
    if (item.qtdArquivos >= LIMITES_PADRAO.maxArqPorItem) {
      throw new ApiError(
        'LIMITE_ARQUIVOS',
        `Máximo de ${LIMITES_PADRAO.maxArqPorItem} arquivos por item.`
      );
    }

    const bytesEstimados = payload.bytes ?? Math.floor((payload.base64.length * 3) / 4);
    if (bytesEstimados <= 0) {
      throw new ApiError('VALIDACAO', 'Arquivo vazio.');
    }
    if (bytesEstimados > LIMITES_PADRAO.maxBytesArq) {
      throw new ApiError('ARQUIVO_GRANDE', 'Arquivo acima de 10 MB.');
    }

    item.qtdArquivos += 1;
    const fileId = PROTOCOLO_FOLDER_ID;
    const sha256 =
      payload.sha256 || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

    let urlArquivo = PASTA_PROTOCOLO_DRIVE_URL;
    if (typeof window !== 'undefined') {
      try {
        const resStorage = await enviarEvidenciaFirebaseStorage({
          protocolo: payload.protocolo,
          codUnidade: reg.unidade.codigo,
          itemN: payload.itemN,
          sigla: item.sigla,
          nomeArquivo: payload.nome,
          mime: payload.mime,
          base64: payload.base64,
          sha256,
          emailGoogle: u.email,
        });
        if (resStorage.downloadUrl) {
          urlArquivo = resStorage.downloadUrl;
        }
      } catch {
        // Fallback para a Pasta do Protocolo no Drive
      }
    }

    item.arquivos.push({
      protocolo: payload.protocolo,
      itemN: payload.itemN,
      sigla: item.sigla,
      nome: payload.nome,
      mime: payload.mime,
      bytes: bytesEstimados,
      fileId,
      url: urlArquivo,
      sha256,
      enviadoEm: new Date().toISOString(),
      emailGoogle: u.email,
    });
    salvarBancoDemo(db);

    return {
      protocolo: payload.protocolo,
      itemN: payload.itemN,
      fileId,
      nome: payload.nome,
      bytes: bytesEstimados,
      sha256,
    };
  },

  async finalize(
    idToken: string,
    payload: { protocolo: string }
  ): Promise<{
    protocolo: string;
    status: string;
    enviadoEm: string;
    reaproveitado: boolean;
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('finalize', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    const db = lerBancoDemo();
    const reg = db.find((r) => r.protocolo === payload.protocolo && r.emailGoogle === u.email);
    if (!reg) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    if (reg.status === 'ENVIADO') {
      return {
        protocolo: reg.protocolo,
        status: 'ENVIADO',
        enviadoEm: reg.enviadoEm,
        reaproveitado: true,
      };
    }
    const semEvidencia = reg.itens.filter((i) => i.qtdArquivos < 1).map((i) => i.sigla);
    if (semEvidencia.length > 0) {
      throw new ApiError(
        'SEM_EVIDENCIA',
        `Anexe ao menos uma evidência para: ${semEvidencia.join(', ')} (Anexo III, item 3).`
      );
    }
    reg.status = 'ENVIADO';
    reg.enviadoEm = new Date().toISOString();
    salvarBancoDemo(db);

    return {
      protocolo: reg.protocolo,
      status: 'ENVIADO',
      enviadoEm: reg.enviadoEm,
      reaproveitado: false,
    };
  },

  async myAppeals(idToken: string): Promise<{ recursos: RecursoResumo[] }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('myAppeals', idToken);
    }
    const u = exigirUsuarioDemo(idToken);
    const db = lerBancoDemo().filter((r) => r.emailGoogle === u.email);
    const recursos: RecursoResumo[] = db
      .map((r) => {
        const analise = garantirAnaliseNoProtocolo(r);
        const divulgado = analise.divulgacao?.divulgado ?? false;
        return {
          protocolo: r.protocolo,
          status: r.status,
          unidade: r.unidade.nome,
          criadoEm: r.criadoEm,
          enviadoEm: r.enviadoEm,
          impugnaListaServidores: r.impugnaListaServidores,
          processoSei: analise.processoSei,
          estadoTramitacao: analise.estadoTramitacao,
          divulgado,
          itens: r.itens.map((i) => ({
            sigla: i.sigla,
            subitem: i.subitem,
            statusAnalise: divulgado ? i.statusAnalise : analise.estadoTramitacao,
            decisao: divulgado
              ? i.decisao
              : 'Resultado da análise será divulgado na etapa própria do cronograma oficial (Art. 14).',
            qtdArquivos: i.qtdArquivos,
          })),
        };
      })
      .reverse();
    return { recursos };
  },

  async adminList(idToken: string): Promise<DadosAdminResposta> {
    if (!MODO_DEMO) {
      return chamarAppsScript<DadosAdminResposta>('adminList', idToken);
    }
    exigirAdminDemo(idToken);
    const db = lerBancoDemo();
    return {
      planilhaUrl: obterPlanilhaMestraUrl(),
      pastaRaizUrl: PASTA_RAIZ_DRIVE_URL,
      recursos: [...db].reverse(),
    };
  },

  async adminUpdateItem(
    idToken: string,
    payload: AtualizarItemAdminPayload
  ): Promise<{ ok: boolean; dataDecisao: string }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('adminUpdateItem', idToken, payload);
    }
    const admin = exigirAdminDemo(idToken);
    const statusPermitidos: StatusAnalise[] = [
      'PENDENTE',
      'EM_ANALISE',
      'NAO_CONHECIDO',
      'PROVIDO',
      'PARCIALMENTE_PROVIDO',
      'IMPROVIDO',
    ];
    if (!statusPermitidos.includes(payload.statusAnalise)) {
      throw new ApiError('VALIDACAO', 'Status de análise inválido.');
    }

    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === payload.protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    const item = rec.itens.find((i) => i.itemN === Number(payload.itemN));
    if (!item) {
      throw new ApiError('NAO_ENCONTRADO', 'Item não encontrado neste protocolo.');
    }

    const agora = new Date().toISOString();
    item.statusAnalise = payload.statusAnalise;
    item.relator = payload.relator.trim() || admin.nome || admin.email;
    item.parecer = payload.parecer.trim();
    item.decisao = payload.decisao.trim();
    item.pontuacaoFinal = numeroOuVazio(payload.pontuacaoFinal);
    item.dataDecisao = agora;
    salvarBancoDemo(db);

    return { ok: true, dataDecisao: agora };
  },

  /* ==========================================================================
   * ENDPOINTS DA ABA INTERNA "ANÁLISE DO RECURSO" (SUMAE + COMISSÃO REVISORA)
   * ======================================================================== */

  async obterAnaliseRecurso(
    idToken: string,
    protocolo: string
  ): Promise<{
    recurso: RecursoAdmin;
    analise: AnaliseRecursoProtocolo;
    permissoes: {
      podeEditarParecerSumae: boolean;
      podeEditarDecisaoComissao: boolean;
    };
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('obterAnaliseRecurso', idToken, { protocolo });
    }
    const u = exigirUsuarioDemo(idToken);
    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', `Protocolo ${protocolo} não encontrado.`);
    }
    if (!ehAdmin(u.email) && rec.emailGoogle.toLowerCase() !== u.email.toLowerCase()) {
      throw new ApiError(
        'NAO_AUTORIZADO',
        'Você não possui permissão para consultar a análise deste protocolo.'
      );
    }
    const analise = garantirAnaliseNoProtocolo(rec);
    salvarBancoDemo(db);

    return {
      recurso: rec,
      analise,
      permissoes: {
        podeEditarParecerSumae: podeAtuarComoSumae(u.email),
        podeEditarDecisaoComissao: podeAtuarComoComissao(u.email),
      },
    };
  },

  async vincularProcessoSei(
    idToken: string,
    payload: { protocolo: string; processoSei: string; forcarAtualizacao?: boolean }
  ): Promise<{
    protocolo: string;
    processoSei: string;
    reutilizado: boolean;
    analise: AnaliseRecursoProtocolo;
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('vincularProcessoSei', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    if (!podeAtuarComoSumae(u.email) && !podeAtuarComoComissao(u.email)) {
      throw new ApiError(
        'NAO_AUTORIZADO',
        'Apenas integrantes da SUMAE ou da Comissão Revisora podem vincular o processo SEI.'
      );
    }
    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === payload.protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    const analise = garantirAnaliseNoProtocolo(rec);

    // Regra item 1: "Vincule um processo SEI individual a cada protocolo. Se o número do SEI
    // já estiver registrado para o mesmo recurso, reutilize o vínculo existente."
    if (analise.processoSei && !payload.forcarAtualizacao) {
      return {
        protocolo: rec.protocolo,
        processoSei: analise.processoSei,
        reutilizado: true,
        analise,
      };
    }

    const resolvido = resolverVinculoSeiProtocolo(
      rec.protocolo,
      payload.forcarAtualizacao ? '' : analise.processoSei,
      payload.processoSei
    );
    analise.processoSei = resolvido.processoSei;
    analise.seiVinculadoEm = new Date().toISOString();
    analise.seiVinculadoPor = `${u.nome} (${u.email})`;
    rec.processoSei = analise.processoSei;
    salvarBancoDemo(db);

    return {
      protocolo: rec.protocolo,
      processoSei: analise.processoSei,
      reutilizado: resolvido.reutilizado,
      analise,
    };
  },

  async salvarParecerSumae(
    idToken: string,
    payload: SalvarParecerSumaePayload
  ): Promise<{
    analise: AnaliseRecursoProtocolo;
    reaproveitado: boolean;
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('salvarParecerSumae', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    if (!podeAtuarComoSumae(u.email) || payload.papelAtivo !== 'SUMAE') {
      throw new ApiError(
        'PERMISSAO_NEGADA',
        'Permissão negada no servidor: a edição e emissão do Parecer Técnico são restritas ao perfil SUMAE.'
      );
    }

    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === payload.protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    const analise = garantirAnaliseNoProtocolo(rec);

    // Proteção contra emissão duplicada em caso de clique repetido ou retentativa após falha
    if (
      payload.acao === 'EMITIR_ENCAMINHAR' &&
      payload.emissionRequestId &&
      analise.parecerSumae.ultimoEmissionId === payload.emissionRequestId &&
      analise.parecerSumae.statusDocumento === 'EMITIDO'
    ) {
      return { analise, reaproveitado: true };
    }

    const agora = new Date().toISOString();
    if (payload.processoSei.trim() && !analise.processoSei) {
      analise.processoSei = payload.processoSei.trim();
      rec.processoSei = analise.processoSei;
    }

    if (payload.acao === 'SALVAR_RASCUNHO') {
      const estadoAnt = analise.estadoTramitacao;
      if (analise.estadoTramitacao === 'RECEBIDO') {
        analise.estadoTramitacao = 'EM_ANALISE_SUMAE';
        rec.estadoTramitacao = 'EM_ANALISE_SUMAE';
        analise.historicoTramitacao.push({
          id: `tram-${Date.now()}`,
          dataHora: agora,
          estadoAnterior: estadoAnt,
          estadoNovo: 'EM_ANALISE_SUMAE',
          atorNome: u.nome,
          atorEmail: u.email,
          papel: 'SUMAE',
          descricao: 'Rascunho do Parecer Técnico salvo pela SUMAE.',
        });
      }
      analise.parecerSumae = {
        ...analise.parecerSumae,
        ...payload.parecer,
        atualizadoEm: agora,
      };
      salvarBancoDemo(db);
      return { analise, reaproveitado: false };
    }

    // Ação: EMITIR_ENCAMINHAR
    const versaoAnterior = analise.parecerSumae.versao || 0;
    const erros = validarEmissaoParecerSumae(payload.parecer, versaoAnterior);
    if (erros.length > 0) {
      throw new ApiError('VALIDACAO_PARECER', erros.join(' | '));
    }

    const novaVersao = versaoAnterior + 1;
    const codigosSei = gerarCodigosAutenticidadeSei(
      `${rec.protocolo}|PARECER|v${novaVersao}|${agora}|${u.email}`
    );

    analise.parecerSumae = {
      ...payload.parecer,
      statusDocumento: 'EMITIDO',
      versao: novaVersao,
      atualizadoEm: agora,
      emitidoEm: agora,
      codigoVerificadorSei: codigosSei.codigoVerificador,
      codigoCrcSei: codigosSei.crc,
      ultimoEmissionId: payload.emissionRequestId || `em-${Date.now()}`,
    };

    // Sincroniza o parecer técnico em cada item do recurso para consulta rápida
    for (const conc of analise.parecerSumae.conclusoesPorItem) {
      const itemRec = rec.itens.find((i) => i.itemN === conc.itemN);
      if (itemRec) {
        itemRec.parecer = conc.conclusaoTecnica;
        if (itemRec.statusAnalise === 'PENDENTE') {
          itemRec.statusAnalise = 'EM_ANALISE';
        }
      }
    }

    // Se a SUMAE apontou falta de evidência obrigatória, sincroniza o flag na decisão da Comissão
    if (analise.parecerSumae.possuiFaltaEvidenciaObrigatoria) {
      analise.decisaoComissao.faltaEvidenciaObrigatoria = true;
      analise.decisaoComissao.conhecido = false;
      analise.decisaoComissao.resultadoGeral = 'NAO_CONHECIDO';
    }

    analise.historicoDocumentos.push({
      id: `doc-parecer-${rec.protocolo}-v${novaVersao}-${Date.now()}`,
      protocolo: rec.protocolo,
      processoSei: analise.processoSei,
      tipo: 'PARECER_SUMAE',
      versao: novaVersao,
      numeroDocumento: analise.parecerSumae.numeroParecer,
      autoriaNome: analise.parecerSumae.responsavelNome || u.nome,
      autoriaCargo: analise.parecerSumae.responsavelCargo,
      autoriaEmail: u.email,
      emitidoEm: agora,
      justificativaRetificacao:
        novaVersao > 1 ? analise.parecerSumae.justificativaRetificacao : '',
      codigoVerificadorSei: codigosSei.codigoVerificador,
      codigoCrcSei: codigosSei.crc,
      resumo:
        novaVersao > 1
          ? `Parecer Técnico SUMAE n.º ${analise.parecerSumae.numeroParecer} retificado (v${novaVersao}) e encaminhado à Comissão Revisora.`
          : `Parecer Técnico SUMAE n.º ${analise.parecerSumae.numeroParecer} emitido (v1) e encaminhado à Comissão Revisora.`,
      snapshotParecer: JSON.parse(JSON.stringify(analise.parecerSumae)),
    });

    const estadoAnt = analise.estadoTramitacao;
    if (analise.estadoTramitacao !== 'DECIDIDO') {
      analise.estadoTramitacao = 'ENCAMINHADO_COMISSAO';
      rec.estadoTramitacao = 'ENCAMINHADO_COMISSAO';
    }
    analise.historicoTramitacao.push({
      id: `tram-parecer-${Date.now()}`,
      dataHora: agora,
      estadoAnterior: estadoAnt,
      estadoNovo: analise.estadoTramitacao,
      atorNome: analise.parecerSumae.responsavelNome || u.nome,
      atorEmail: u.email,
      papel: 'SUMAE',
      descricao: `Parecer Técnico SUMAE n.º ${analise.parecerSumae.numeroParecer} (v${novaVersao}) emitido e encaminhado à Comissão Revisora.`,
    });

    salvarBancoDemo(db);
    return { analise, reaproveitado: false };
  },

  async salvarDecisaoComissao(
    idToken: string,
    payload: SalvarDecisaoComissaoPayload
  ): Promise<{
    analise: AnaliseRecursoProtocolo;
    reaproveitado: boolean;
  }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('salvarDecisaoComissao', idToken, payload);
    }
    const u = exigirUsuarioDemo(idToken);
    if (!podeAtuarComoComissao(u.email) || payload.papelAtivo !== 'COMISSAO') {
      throw new ApiError(
        'PERMISSAO_NEGADA',
        'Permissão negada no servidor: a edição e emissão da Decisão Final são restritas ao perfil Comissão Revisora.'
      );
    }

    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === payload.protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    const analise = garantirAnaliseNoProtocolo(rec);

    // Proteção de idempotência contra duplo clique / reenvio
    if (
      payload.acao === 'EMITIR_DECISAO' &&
      payload.emissionRequestId &&
      analise.decisaoComissao.ultimoEmissionId === payload.emissionRequestId &&
      analise.decisaoComissao.statusDocumento === 'EMITIDO'
    ) {
      return { analise, reaproveitado: true };
    }

    const agora = new Date().toISOString();
    const faltaNoRecurso = detectarFaltaEvidenciaRecurso(rec).faltaEvidencia;
    const faltaEvidenciaObrigatoria =
      faltaNoRecurso ||
      analise.parecerSumae.possuiFaltaEvidenciaObrigatoria ||
      payload.decisao.faltaEvidenciaObrigatoria;

    // Regra obrigatória do item 3:
    // "Quando faltar qualquer evidência obrigatória, registre o resultado “Não conhecido”,
    // exija a fundamentação e mantenha os campos de mérito desabilitados."
    const decisaoNormalizada = {
      ...payload.decisao,
      faltaEvidenciaObrigatoria,
      conhecido: faltaEvidenciaObrigatoria ? false : payload.decisao.conhecido,
      resultadoGeral:
        faltaEvidenciaObrigatoria || !payload.decisao.conhecido
          ? ('NAO_CONHECIDO' as const)
          : payload.decisao.resultadoGeral,
      itensDecididos: payload.decisao.itensDecididos.map((it) =>
        faltaEvidenciaObrigatoria || !payload.decisao.conhecido
          ? {
              ...it,
              resultadoItem: 'NAO_CONHECIDO' as const,
              pontuacaoFinal: it.pontuacaoPreliminar,
              impactoPontuacao: 'Sem alteração (Recurso não conhecido)',
              necessitaReavaliacaoReprocessamento: false,
            }
          : it
      ),
    };

    if (payload.acao === 'SALVAR_RASCUNHO') {
      const estadoAnt = analise.estadoTramitacao;
      if (analise.estadoTramitacao !== 'DECIDIDO') {
        analise.estadoTramitacao = 'EM_ANALISE_COMISSAO';
        rec.estadoTramitacao = 'EM_ANALISE_COMISSAO';
        if (estadoAnt !== 'EM_ANALISE_COMISSAO') {
          analise.historicoTramitacao.push({
            id: `tram-com-${Date.now()}`,
            dataHora: agora,
            estadoAnterior: estadoAnt,
            estadoNovo: 'EM_ANALISE_COMISSAO',
            atorNome: u.nome,
            atorEmail: u.email,
            papel: 'COMISSAO',
            descricao: 'Recurso em análise de julgamento pela Comissão Revisora (rascunho salvo).',
          });
        }
      }
      analise.decisaoComissao = {
        ...analise.decisaoComissao,
        ...decisaoNormalizada,
        atualizadoEm: agora,
      };
      salvarBancoDemo(db);
      return { analise, reaproveitado: false };
    }

    // Ação: EMITIR_DECISAO
    const versaoAnterior = analise.decisaoComissao.versao || 0;
    const erros = validarEmissaoDecisaoComissao(
      rec,
      analise.parecerSumae,
      decisaoNormalizada,
      versaoAnterior
    );
    if (erros.length > 0) {
      throw new ApiError('VALIDACAO_DECISAO', erros.join(' | '));
    }

    const novaVersao = versaoAnterior + 1;
    const codigosSei = gerarCodigosAutenticidadeSei(
      `${rec.protocolo}|DECISAO|v${novaVersao}|${agora}|${u.email}`
    );

    analise.decisaoComissao = {
      ...decisaoNormalizada,
      statusDocumento: 'EMITIDO',
      versao: novaVersao,
      atualizadoEm: agora,
      emitidoEm: agora,
      codigoVerificadorSei: codigosSei.codigoVerificador,
      codigoCrcSei: codigosSei.crc,
      ultimoEmissionId: payload.emissionRequestId || `em-dec-${Date.now()}`,
    };

    // Atualiza os itens do protocolo com o resultado decidido pela Comissão
    for (const itemDec of analise.decisaoComissao.itensDecididos) {
      const itemRec = rec.itens.find((i) => i.itemN === itemDec.itemN);
      if (itemRec) {
        if (analise.decisaoComissao.resultadoGeral === 'NAO_CONHECIDO') {
          itemRec.statusAnalise = 'NAO_CONHECIDO';
        } else if (itemDec.resultadoItem === 'PROVIDO') {
          itemRec.statusAnalise = 'PROVIDO';
        } else if (itemDec.resultadoItem === 'PARCIALMENTE_PROVIDO') {
          itemRec.statusAnalise = 'PARCIALMENTE_PROVIDO';
        } else {
          itemRec.statusAnalise = 'IMPROVIDO';
        }
        itemRec.relator = analise.decisaoComissao.relatorNome || u.nome;
        itemRec.decisao = itemDec.fundamentacao;
        itemRec.pontuacaoFinal = numeroOuVazio(itemDec.pontuacaoFinal);
        itemRec.dataDecisao = agora;
      }
    }

    analise.historicoDocumentos.push({
      id: `doc-decisao-${rec.protocolo}-v${novaVersao}-${Date.now()}`,
      protocolo: rec.protocolo,
      processoSei: analise.processoSei,
      tipo: 'DECISAO_COMISSAO',
      versao: novaVersao,
      numeroDocumento: analise.decisaoComissao.numeroDecisao,
      autoriaNome: analise.decisaoComissao.relatorNome || u.nome,
      autoriaCargo: analise.decisaoComissao.relatorCargo,
      autoriaEmail: u.email,
      emitidoEm: agora,
      justificativaRetificacao:
        novaVersao > 1 ? analise.decisaoComissao.justificativaRetificacao : '',
      codigoVerificadorSei: codigosSei.codigoVerificador,
      codigoCrcSei: codigosSei.crc,
      resumo: `Decisão Final ${analise.decisaoComissao.numeroDecisao} (v${novaVersao}) emitida — Resultado Geral: ${analise.decisaoComissao.resultadoGeral}.`,
      snapshotDecisao: JSON.parse(JSON.stringify(analise.decisaoComissao)),
    });

    const estadoAnt = analise.estadoTramitacao;
    analise.estadoTramitacao = 'DECIDIDO';
    rec.estadoTramitacao = 'DECIDIDO';

    analise.historicoTramitacao.push({
      id: `tram-decisao-${Date.now()}`,
      dataHora: agora,
      estadoAnterior: estadoAnt,
      estadoNovo: 'DECIDIDO',
      atorNome: analise.decisaoComissao.relatorNome || u.nome,
      atorEmail: u.email,
      papel: 'COMISSAO',
      descricao: `Decisão Final (${analise.decisaoComissao.resultadoGeral}) emitida pela Comissão Revisora (v${novaVersao}). Encaminhamento: ${analise.decisaoComissao.encaminhamentoCienciaProvidencias}`,
    });

    salvarBancoDemo(db);
    return { analise, reaproveitado: false };
  },

  async atualizarDivulgacaoResultado(
    idToken: string,
    payload: { protocolo: string; divulgado: boolean }
  ): Promise<{ analise: AnaliseRecursoProtocolo }> {
    if (!MODO_DEMO) {
      return chamarAppsScript('atualizarDivulgacaoResultado', idToken, payload);
    }
    const u = exigirAdminDemo(idToken);
    const db = lerBancoDemo();
    const rec = db.find((r) => r.protocolo === payload.protocolo);
    if (!rec) {
      throw new ApiError('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    }
    const analise = garantirAnaliseNoProtocolo(rec);
    const agora = new Date().toISOString();
    analise.divulgacao = {
      ...analise.divulgacao,
      divulgado: payload.divulgado,
      divulgadoEm: payload.divulgado ? agora : '',
    };
    analise.historicoTramitacao.push({
      id: `tram-divulg-${Date.now()}`,
      dataHora: agora,
      estadoAnterior: analise.estadoTramitacao,
      estadoNovo: analise.estadoTramitacao,
      atorNome: u.nome,
      atorEmail: u.email,
      papel: 'COMISSAO',
      descricao: payload.divulgado
        ? 'Resultado oficial do julgamento liberado na etapa de divulgação do cronograma do Prêmio.'
        : 'Divulgação externa suspensa (mantido restrito à tramitação interna).',
    });
    salvarBancoDemo(db);
    return { analise };
  },
};

