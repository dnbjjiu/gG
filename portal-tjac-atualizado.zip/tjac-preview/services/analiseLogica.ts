import { PORTARIA } from '../catalogo';
import type {
  AnaliseRecursoProtocolo,
  ConclusaoTecnicaItemSumae,
  DecisaoFinalComissao,
  DecisaoItemComissao,
  EstadoTramitacao,
  ParecerTecnicoSumae,
  RecursoAdmin,
} from '../types';
import { formatarCpf, formatarDataHora } from '../utils';

export const ROTULO_ESTADO_TRAMITACAO: Record<EstadoTramitacao, string> = {
  RECEBIDO: 'Recebido',
  EM_ANALISE_SUMAE: 'Em análise pela SUMAE',
  ENCAMINHADO_COMISSAO: 'Encaminhado à Comissão',
  EM_ANALISE_COMISSAO: 'Em análise pela Comissão',
  DECIDIDO: 'Decidido',
};

export const ORDEM_TRAMITACAO: readonly EstadoTramitacao[] = [
  'RECEBIDO',
  'EM_ANALISE_SUMAE',
  'ENCAMINHADO_COMISSAO',
  'EM_ANALISE_COMISSAO',
  'DECIDIDO',
];

/**
 * Gera códigos verificadores determinísticos no padrão SEI/TJAC (ex.: 2284219 / CRC B42FFA0E)
 */
export function gerarCodigosAutenticidadeSei(semente: string): {
  codigoVerificador: string;
  crc: string;
} {
  let h1 = 2166136261;
  let h2 = 0x811c9dc5;
  for (let i = 0; i < semente.length; i++) {
    const c = semente.charCodeAt(i);
    h1 ^= c;
    h1 = Math.imul(h1, 16777619);
    h2 ^= c + i;
    h2 = Math.imul(h2, 16777619);
  }
  const numVerificador = String(2280000 + (Math.abs(h1) % 19999)).slice(0, 7);
  const crc = (Math.abs(h2) >>> 0).toString(16).toUpperCase().padStart(8, '0').slice(0, 8);
  return { codigoVerificador: numVerificador, crc };
}

/**
 * Verifica se falta qualquer evidência obrigatória (Anexo III, item 3, alíneas a–e ou arquivo anexo)
 * em algum item do recurso original.
 */
export function detectarFaltaEvidenciaRecurso(recurso: RecursoAdmin): {
  faltaEvidencia: boolean;
  detalhesFaltas: string[];
} {
  const detalhesFaltas: string[] = [];

  for (const it of recurso.itens) {
    const ev = it.evidencias;
    const faltantesAlinea: string[] = [];
    if (!ev.a) faltantesAlinea.push('(a) identificação do painel/relatório');
    if (!ev.b) faltantesAlinea.push('(b) filtros aplicados');
    if (!ev.c) faltantesAlinea.push('(c) período de referência (01/01 a 30/11/2026)');
    if (!ev.d) faltantesAlinea.push('(d) memória de cálculo detalhada');
    if (!ev.e) faltantesAlinea.push('(e) número e quantidade exata dos processos');

    if (faltantesAlinea.length > 0) {
      detalhesFaltas.push(
        `Item #${it.itemN} (${it.sigla}): ausentes requisitos formais ${faltantesAlinea.join(', ')}.`
      );
    }
    if (!it.arquivos || it.arquivos.length === 0) {
      detalhesFaltas.push(
        `Item #${it.itemN} (${it.sigla}): nenhum arquivo comprobatório anexado ao protocolo.`
      );
    }
  }

  return {
    faltaEvidencia: detalhesFaltas.length > 0,
    detalhesFaltas,
  };
}

/**
 * Reutiliza o número de processo SEI se já estiver registrado para o protocolo,
 * ou atribui um processo SEI individual ao protocolo.
 */
export function resolverVinculoSeiProtocolo(
  protocolo: string,
  seiExistente: string | undefined,
  seiInformado: string | undefined
): { processoSei: string; reutilizado: boolean } {
  const existenteLimpo = (seiExistente || '').trim();
  if (existenteLimpo) {
    return { processoSei: existenteLimpo, reutilizado: true };
  }
  const informadoLimpo = (seiInformado || '').trim();
  if (informadoLimpo) {
    return { processoSei: informadoLimpo, reutilizado: false };
  }
  const sufixoNum = protocolo.replace(/\D/g, '').slice(-5) || '00001';
  const numSeiPadrao = `0013${sufixoNum.slice(-3)}-86.2026.8.01.0000`;
  return { processoSei: numSeiPadrao, reutilizado: false };
}

/**
 * Constrói a estrutura inicial de Análise do Recurso para um protocolo cadastrado
 */
export function criarAnaliseInicialParaRecurso(
  recurso: RecursoAdmin,
  processoSeiInicial?: string
): AnaliseRecursoProtocolo {
  const seqStr = recurso.protocolo.replace(/\D/g, '').slice(-3) || '001';
  const vinculo = resolverVinculoSeiProtocolo(
    recurso.protocolo,
    recurso.processoSei,
    processoSeiInicial
  );
  const verificacaoEv = detectarFaltaEvidenciaRecurso(recurso);

  const siglas = recurso.itens.map((i) => `${i.sigla} (${i.indicador})`).join('; ');
  const sintesePadrao =
    recurso.itens.length > 0
      ? `A unidade recorrente (${recurso.unidade.nome}) solicita a revisão da pontuação preliminar atribuída ao(s) indicador(es) ${siglas}, alegando divergência nos parâmetros apurados e pleiteando reenquadramento conforme documentação anexada ao protocolo ${recurso.protocolo}.`
      : `A unidade recorrente (${recurso.unidade.nome}) apresenta impugnação referente à lista de servidores vinculados (art. 5º, III, "b" e art. 6º da ${PORTARIA}).`;

  const conclusoesPorItem: ConclusaoTecnicaItemSumae[] = recurso.itens.map((it) => {
    const itemOk =
      it.evidencias.a &&
      it.evidencias.b &&
      it.evidencias.c &&
      it.evidencias.d &&
      it.evidencias.e &&
      it.arquivos.length > 0;
    return {
      itemN: it.itemN,
      sigla: it.sigla,
      indicador: it.indicador,
      subitem: it.subitem,
      evidenciasCompletas: itemOk,
      faltasEvidenciasItem: itemOk
        ? 'Evidências obrigatórias (a)–(e) do Anexo III, item 3, integralmente apresentadas.'
        : 'Falta de evidência documental exigida pelo art. 13 e Anexo III, item 3.',
      recomendacao: itemOk ? 'ACOLHER_INTEGRALMENTE' : 'NAO_CONHECER',
      pontuacaoPreliminar: it.pontuacaoPreliminar,
      pontuacaoRecomendada: itemOk ? it.pontuacaoPleiteada : it.pontuacaoPreliminar,
      impactoPontuacao:
        itemOk &&
        typeof it.pontuacaoPleiteada === 'number' &&
        typeof it.pontuacaoPreliminar === 'number'
          ? `+${it.pontuacaoPleiteada - it.pontuacaoPreliminar} pontos (${it.pontuacaoPreliminar} → ${it.pontuacaoPleiteada} pts)`
          : 'Sem alteração de pontuação (0 pts)',
      conclusaoTecnica:
        it.parecer ||
        `Após auditoria técnica na base oficial de BI do TJAC para o indicador ${it.sigla}, ${
          itemOk
            ? 'confirma-se a procedência técnica dos dados e memória de cálculo apresentados pela unidade.'
            : 'verifica-se desconformidade documental nos termos do art. 13.'
        }`,
    };
  });

  const itensDecididos: DecisaoItemComissao[] = recurso.itens.map((it) => ({
    itemN: it.itemN,
    sigla: it.sigla,
    indicador: it.indicador,
    subitem: it.subitem,
    resultadoItem: verificacaoEv.faltaEvidencia ? 'NAO_CONHECIDO' : 'PROVIDO',
    fundamentacao:
      it.decisao ||
      (verificacaoEv.faltaEvidencia
        ? 'Ausência de evidência obrigatória exigida pelo art. 13 e Anexo III, item 3, da Portaria regulamentadora.'
        : `Acolhe-se a conclusão técnica da SUMAE para o indicador ${it.sigla}, em consonância com os parâmetros do Anexo Único/IV da Portaria.`),
    providenciaDeterminada: verificacaoEv.faltaEvidencia
      ? 'Manutenção da pontuação preliminar publicada.'
      : `Retificação da pontuação do indicador ${it.sigla} no quadro geral do Prêmio TJAC de Qualidade 2026.`,
    pontuacaoPreliminar: it.pontuacaoPreliminar,
    pontuacaoFinal: verificacaoEv.faltaEvidencia
      ? it.pontuacaoPreliminar
      : it.pontuacaoFinal !== ''
        ? it.pontuacaoFinal
        : it.pontuacaoPleiteada,
    impactoPontuacao:
      !verificacaoEv.faltaEvidencia &&
      typeof it.pontuacaoPleiteada === 'number' &&
      typeof it.pontuacaoPreliminar === 'number'
        ? `+${it.pontuacaoPleiteada - it.pontuacaoPreliminar} pontos`
        : 'Mantida a pontuação preliminar',
    necessitaReavaliacaoReprocessamento: !verificacaoEv.faltaEvidencia,
    detalheReprocessamento: !verificacaoEv.faltaEvidencia
      ? `Reprocessar nota consolidada da unidade ${recurso.unidade.codigo} no Painel de BI do Prêmio 2026.`
      : '',
  }));

  return {
    protocolo: recurso.protocolo,
    processoSei: vinculo.processoSei,
    seiVinculadoEm: recurso.enviadoEm || recurso.criadoEm,
    seiVinculadoPor: 'SUMAE / Sistema Eletrônico de Recursos',
    estadoTramitacao: recurso.estadoTramitacao || 'RECEBIDO',
    parecerSumae: {
      numeroParecer: `${seqStr}/2026`,
      statusDocumento: 'RASCUNHO',
      versao: 0,
      sintesePedido: sintesePadrao,
      tempestivo: true,
      conferenciaPrazoEvidencias: verificacaoEv.faltaEvidencia
        ? `Recurso tempestivo, porém com pendências nas evidências obrigatórias: ${verificacaoEv.detalhesFaltas.join(' ')}`
        : 'Recurso protocolado tempestivamente dentro do prazo regulamentar (04/12/2026 a 07/12/2026). Todas as evidências obrigatórias previstas no art. 13 e Anexo III, item 3 (alíneas "a" a "e") foram devidamente apresentadas e conferidas.',
      possuiFaltaEvidenciaObrigatoria: verificacaoEv.faltaEvidencia,
      registroFaltasEvidencias: verificacaoEv.faltaEvidencia
        ? verificacaoEv.detalhesFaltas.join('\n')
        : 'Nenhuma falta de evidência obrigatória registrada.',
      dadosFontesConsultadas:
        'Painéis oficiais de Business Intelligence (BI TJAC / DIGED / SUMAE), sistemas processuais internos (SAJ / eproc / SEEU) e Base Nacional de Dados do Poder Judiciário (DataJud/CNJ).',
      filtrosAplicados: `Unidade Judiciária: ${recurso.unidade.codigo} — ${recurso.unidade.nome} (${recurso.unidade.comarca}); Grau: ${recurso.unidade.grau}; Indicadores auditados: ${recurso.itens.map((i) => i.sigla).join(', ') || 'Lista de Servidores'}.`,
      periodoReferencia: '01/01/2026 a 30/11/2026 (data de corte oficial do ano-base conforme Portaria PRESI/TJAC nº 1961/2026, alterada pela Portaria PRESI nº 4335/2026).',
      metodologiaMemoriaCalculo:
        'Aplicação estrita das fórmulas matemáticas e faixas de pontuação estabelecidas nos Anexos I, II e IV da Portaria PRESI/TJAC nº 1961/2026 (alterada pela Portaria PRESI nº 4335/2026), mediante auditoria cruzada entre os números únicos de processos (NPUs) listados pela unidade recorrente e os registros auditados até 30/11/2026.',
      conclusoesPorItem,
      conclusaoGeral: verificacaoEv.faltaEvidencia
        ? 'Diante do exposto, verifica-se que a documentação constante no recurso apresenta desconformidade formal quanto às evidências obrigatórias exigidas pelo art. 13 da Portaria regulamentadora, opinando-se pelo não conhecimento ou indeferimento técnico.'
        : 'Diante do exposto, após conferência técnica nos painéis oficiais de BI do TJAC e validação da memória de cálculo apresentada pela unidade recorrente, a Equipe Técnica da SUMAE opina pela procedência técnica dos apontamentos nos termos detalhados por item.',
      responsavelNome: 'Josué da Silva Santos / Equipe Técnica SUMAE',
      responsavelCargo: 'Chefe de Divisão / Analista Técnico — SUMAE/SEGOV',
      responsavelEmail: 'josue.silva@tjac.jus.br',
      lotacao: 'Subsecretaria de Monitoramento e Análise Estratégica — SUMAE/SEGOV',
      encaminhamentoComissao:
        'Diante dos elementos apresentados pela unidade recorrente e das verificações técnicas descritas neste parecer, encaminham-se os autos à Comissão Revisora do Prêmio TJAC de Qualidade 2026, para análise e deliberação quanto à admissibilidade e ao mérito do recurso, nos termos da Portaria regulamentadora.',
      justificativaRetificacao: '',
      atualizadoEm: '',
      emitidoEm: '',
      codigoVerificadorSei: '',
      codigoCrcSei: '',
      ultimoEmissionId: '',
    },
    decisaoComissao: {
      numeroDecisao: `DEC-${seqStr}/2026`,
      statusDocumento: 'RASCUNHO',
      versao: 0,
      relatorio: `Trata-se de Recurso Administrativo (${recurso.protocolo}) interposto por ${recurso.unidade.nome}, subscrito por ${recurso.responsavel.nome} (${recurso.responsavel.cargo}), em face do Resultado Preliminar do Prêmio TJAC de Qualidade 2026 (${PORTARIA}). Os autos foram instruídos e remetidos à Subsecretaria de Monitoramento e Análise Estratégica (SUMAE/SEGOV), que emitiu o Parecer Técnico SUMAE n.º ${seqStr}/2026.`,
      conhecido: !verificacaoEv.faltaEvidencia,
      faltaEvidenciaObrigatoria: verificacaoEv.faltaEvidencia,
      fundamentacaoAdmissibilidade: verificacaoEv.faltaEvidencia
        ? `Nos termos do art. 13 e Anexo III, item 3, da ${PORTARIA}, o conhecimento do recurso condiciona-se à apresentação cumulativa das evidências obrigatórias. Verificada a ausência de elementos formais indispensáveis à rastreabilidade e auditoria (${verificacaoEv.detalhesFaltas.join(' ')}), impõe-se o NÃO CONHECIMENTO do recurso.`
        : `Presentes os pressupostos objetivos e subjetivos de admissibilidade: recurso interposto tempestivamente por gestor legitimado e instruído com todas as evidências obrigatórias exigidas pelo art. 13 e Anexo III, item 3, da ${PORTARIA}. CONHECE-SE do recurso.`,
      resultadoGeral: verificacaoEv.faltaEvidencia ? 'NAO_CONHECIDO' : 'PROVIDO',
      fundamentacaoGeral: verificacaoEv.faltaEvidencia
        ? 'Deixo de apreciar o mérito recursal ante o não conhecimento por ausência de requisito formal de evidência obrigatória (art. 13 da Portaria PRESI/TJAC nº 1961/2026).'
        : `A análise do mérito baseia-se no Parecer Técnico SUMAE n.º ${seqStr}/2026, que aferiu a exatidão dos dados nos sistemas oficiais do Tribunal de Justiça do Estado do Acre até a data de corte de 30 de novembro de 2026, demonstrando a conformidade do pleito recursal com as regras objetivas de pontuação da Portaria regente.`,
      itensDecididos,
      dispositivo: verificacaoEv.faltaEvidencia
        ? `Diante do exposto, acolhe-se a preliminar técnica apontada pela SUMAE e NÃO SE CONHECE do recurso administrativo interposto por ${recurso.unidade.nome} (${recurso.protocolo}), mantendo-se inalterado o Resultado Preliminar da unidade. Ciência à unidade recorrente. Após, arquive-se no SEI.`
        : `Diante do exposto, acolhe-se o Parecer Técnico SUMAE n.º ${seqStr}/2026 e conhece-se do recurso administrativo interposto por ${recurso.unidade.nome} (${recurso.protocolo}), para, no mérito, DAR-LHE PROVIMENTO nos termos fixados por indicador, determinando-se à SUMAE/SEGOV a atualização da pontuação final da unidade para a etapa própria de divulgação oficial do Prêmio TJAC de Qualidade 2026.`,
      encaminhamentoCienciaProvidencias:
        'Encaminhe-se à SUMAE/SEGOV para registro e reprocessamento interno da pontuação (se cabível), aguardando-se a etapa própria do cronograma oficial (art. 14) para divulgação do Resultado Definitivo e ciência à Unidade Judiciária recorrente.',
      relatorNome: 'Zenice Mota Cardozo',
      relatorCargo: 'Juiz(a) Auxiliar da Presidência — Presidente/Membro da Comissão Revisora',
      relatorEmail: 'comissao.revisora@tjac.jus.br',
      membrosComissao:
        'Comissão Revisora (Art. 10): Dois Juízes indicados pela Presidência, um Juiz indicado pela Corregedoria-Geral da Justiça (COGER) e Secretário(a) de Governança e Gestão Estratégica (SEGOV).',
      justificativaRetificacao: '',
      atualizadoEm: '',
      emitidoEm: '',
      codigoVerificadorSei: '',
      codigoCrcSei: '',
      ultimoEmissionId: '',
    },
    historicoDocumentos: [],
    historicoTramitacao: [
      {
        id: `tram-init-${recurso.protocolo}`,
        dataHora: recurso.enviadoEm || recurso.criadoEm,
        estadoAnterior: 'RECEBIDO',
        estadoNovo: 'RECEBIDO',
        atorNome: recurso.responsavel.nome,
        atorEmail: recurso.emailGoogle,
        papel: 'UNIDADE',
        descricao: `Recurso protocolado pela unidade ${recurso.unidade.nome} e vinculado ao Processo SEI ${vinculo.processoSei}.`,
      },
    ],
    divulgacao: {
      divulgado: false,
      etapaCronograma:
        'Solenidade de Outorga e Divulgação do Julgamento dos Recursos (Art. 14 — 18/12/2026)',
      dataPrevistaDivulgacao: '2026-12-18T18:00:00-05:00',
      divulgadoEm: '',
    },
  };
}

/**
 * Valida o Parecer Técnico da SUMAE antes da emissão oficial
 */
export function validarEmissaoParecerSumae(
  parecer: Omit<
    ParecerTecnicoSumae,
    | 'statusDocumento'
    | 'versao'
    | 'atualizadoEm'
    | 'emitidoEm'
    | 'codigoVerificadorSei'
    | 'codigoCrcSei'
    | 'ultimoEmissionId'
  >,
  versaoAtualEmitida: number
): string[] {
  const erros: string[] = [];
  if (!parecer.numeroParecer.trim()) {
    erros.push('Informe o número do Parecer Técnico SUMAE (ex.: 001/2026).');
  }
  if (!parecer.sintesePedido || parecer.sintesePedido.trim().length < 20) {
    erros.push('Informe a síntese do pedido e identificação dos itens contestados (mín. 20 caracteres).');
  }
  if (!parecer.conferenciaPrazoEvidencias || parecer.conferenciaPrazoEvidencias.trim().length < 20) {
    erros.push('Registre a conferência do prazo e das evidências obrigatórias.');
  }
  if (
    parecer.possuiFaltaEvidenciaObrigatoria &&
    (!parecer.registroFaltasEvidencias || parecer.registroFaltasEvidencias.trim().length < 10)
  ) {
    erros.push('Descreva expressamente quais evidências obrigatórias faltaram no recurso.');
  }
  if (!parecer.dadosFontesConsultadas.trim() || !parecer.filtrosAplicados.trim() || !parecer.periodoReferencia.trim()) {
    erros.push('Preencha os dados e fontes consultadas, os filtros aplicados e o período de referência.');
  }
  if (!parecer.metodologiaMemoriaCalculo || parecer.metodologiaMemoriaCalculo.trim().length < 20) {
    erros.push('Detalhe a metodologia, memória de cálculo e fundamentação técnica da SUMAE.');
  }
  for (const c of parecer.conclusoesPorItem) {
    if (!c.conclusaoTecnica || c.conclusaoTecnica.trim().length < 10) {
      erros.push(`Preencha a conclusão técnica do Item #${c.itemN} (${c.sigla}).`);
    }
  }
  if (!parecer.conclusaoGeral || parecer.conclusaoGeral.trim().length < 15) {
    erros.push('Preencha a conclusão técnica geral do Parecer.');
  }
  if (!parecer.responsavelNome.trim() || !parecer.responsavelCargo.trim()) {
    erros.push('Identifique o responsável técnico (nome e cargo/função na SUMAE).');
  }
  if (!parecer.encaminhamentoComissao.trim()) {
    erros.push('Registre o texto de encaminhamento à Comissão Revisora.');
  }
  if (versaoAtualEmitida >= 1 && (!parecer.justificativaRetificacao || parecer.justificativaRetificacao.trim().length < 15)) {
    erros.push(
      'Para emitir uma versão retificadora (v2 ou superior) de parecer já emitido, é obrigatório informar a justificativa da retificação (mín. 15 caracteres).'
    );
  }
  return erros;
}

/**
 * Valida a Decisão Final da Comissão Revisora antes da emissão oficial.
 * Regra crítica (item 3):
 * "Quando faltar qualquer evidência obrigatória, registre o resultado “Não conhecido”,
 * exija a fundamentação e mantenha os campos de mérito desabilitados."
 */
export function validarEmissaoDecisaoComissao(
  recurso: RecursoAdmin,
  parecer: ParecerTecnicoSumae,
  decisao: Omit<
    DecisaoFinalComissao,
    | 'statusDocumento'
    | 'versao'
    | 'atualizadoEm'
    | 'emitidoEm'
    | 'codigoVerificadorSei'
    | 'codigoCrcSei'
    | 'ultimoEmissionId'
  >,
  versaoAtualEmitida: number
): string[] {
  const erros: string[] = [];
  const faltaNoRecurso = detectarFaltaEvidenciaRecurso(recurso).faltaEvidencia;
  const faltaObrigatoria =
    faltaNoRecurso ||
    parecer.possuiFaltaEvidenciaObrigatoria ||
    decisao.faltaEvidenciaObrigatoria ||
    !decisao.conhecido;

  if (!decisao.relatorio || decisao.relatorio.trim().length < 20) {
    erros.push('Preencha o Relatório da Decisão (mín. 20 caracteres).');
  }
  if (!decisao.fundamentacaoAdmissibilidade || decisao.fundamentacaoAdmissibilidade.trim().length < 20) {
    erros.push('A fundamentação do exame de admissibilidade é obrigatória (mín. 20 caracteres).');
  }

  if (faltaObrigatoria) {
    if (decisao.resultadoGeral !== 'NAO_CONHECIDO') {
      erros.push(
        'Quando faltar qualquer evidência obrigatória ou o recurso não for conhecido, o resultado geral deve ser obrigatoriamente registrado como “Não conhecido”.'
      );
    }
  } else {
    if (!['PROVIDO', 'PARCIALMENTE_PROVIDO', 'DESPROVIDO'].includes(decisao.resultadoGeral)) {
      erros.push(
        'Para recurso conhecido, registre o resultado geral como “Provido”, “Parcialmente provido” ou “Desprovido”.'
      );
    }
    if (!decisao.fundamentacaoGeral || decisao.fundamentacaoGeral.trim().length < 20) {
      erros.push('Preencha a Fundamentação de mérito da Decisão (mín. 20 caracteres).');
    }
    for (const it of decisao.itensDecididos) {
      if (!['PROVIDO', 'PARCIALMENTE_PROVIDO', 'DESPROVIDO'].includes(it.resultadoItem)) {
        erros.push(`Selecione o resultado de mérito para o Item #${it.itemN} (${it.sigla}).`);
      }
      if (!it.fundamentacao || it.fundamentacao.trim().length < 10) {
        erros.push(`Registre a fundamentação do Item #${it.itemN} (${it.sigla}).`);
      }
    }
  }

  if (!decisao.dispositivo || decisao.dispositivo.trim().length < 20) {
    erros.push('Preencha o Dispositivo da Decisão (mín. 20 caracteres).');
  }
  if (!decisao.encaminhamentoCienciaProvidencias || decisao.encaminhamentoCienciaProvidencias.trim().length < 10) {
    erros.push('Registre o encaminhamento para ciência ou providências.');
  }
  if (!decisao.relatorNome.trim() || !decisao.relatorCargo.trim()) {
    erros.push('Identifique o(a) Magistrado(a) Relator(a) / Presidente da Comissão Revisora.');
  }
  if (
    versaoAtualEmitida >= 1 &&
    (!decisao.justificativaRetificacao || decisao.justificativaRetificacao.trim().length < 15)
  ) {
    erros.push(
      'Para emitir uma nova versão retificadora da Decisão Final, é obrigatório registrar a justificativa da retificação (mín. 15 caracteres).'
    );
  }

  return erros;
}

/* ============================================================================
 * GERADOR DE PDF INSTITUCIONAL (MODELO FIXO SEI — TJAC)
 * Gera um arquivo binário %PDF-1.4 válido sem dependências externas
 * para juntada imediata ao Processo SEI.
 * ========================================================================== */

function sanitizarWinAnsi(texto: string): string {
  return texto
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[–—]/g, '-')
    .replace(/•/g, '-')
    .replace(/→/g, '->')
    .replace(/≥/g, '>=')
    .replace(/≤/g, '<=')
    .replace(/×/g, 'x')
    .replace(/÷/g, '/')
    .replace(/[^\x20-\x7E\xA0-\xFF\n]/g, '');
}

function escaparLiteralPdf(linha: string): string {
  const s = sanitizarWinAnsi(linha);
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code === 0x28 || code === 0x29 || code === 0x5c) {
      out += '\\' + s[i];
    } else if (code >= 0x20 && code <= 0x7e) {
      out += s[i];
    } else if (code >= 0xa0 && code <= 0xff) {
      out += '\\' + code.toString(8).padStart(3, '0');
    }
  }
  return out;
}

function paragrafosPdf(texto: string): string[] {
  return (texto || '').split(/\r?\n/);
}

interface LinhaFormatadaPdf {
  texto: string;
  negrito?: boolean;
  centralizado?: boolean;
  tamanho?: number;
  manterComProxima?: boolean;
}

function construirBytesPdfDeLinhas(
  tituloDoc: string,
  rodapeSei: string,
  linhasEntrada: LinhaFormatadaPdf[]
): Uint8Array {
  const margem = 50;
  const larguraPagina = 595;
  const larguraTexto = larguraPagina - 2 * margem;
  const topo = 790;
  const base = 60;
  const contexto = typeof document === 'undefined' ? null : document.createElement('canvas').getContext('2d');

  function largura(texto: string, tamanho: number, negrito?: boolean): number {
    if (!contexto) {
      let unidades = 0;
      for (const caractere of texto) {
        if (/[MW@%]/.test(caractere)) unidades += 1.05;
        else if (/[ ilI.,:;!|]/.test(caractere)) unidades += 0.34;
        else if (/[A-ZÀ-Þmw]/.test(caractere)) unidades += 0.8;
        else unidades += 0.65;
      }
      return unidades * tamanho;
    }
    contexto.font = `${negrito ? 'bold ' : ''}${tamanho}px Arial`;
    return contexto.measureText(texto).width * 1.02;
  }

  const paginas: (LinhaFormatadaPdf & { y: number })[][] = [[]];
  let y = topo;

  const entradas = linhasEntrada.length ? linhasEntrada : [{ texto: tituloDoc, negrito: true }];
  const alturaLinha = (tamanho: number) => tamanho + 4;

  for (const linha of entradas) {
    const tamanho = linha.tamanho || 10;
    const texto = sanitizarWinAnsi(linha.texto.normalize('NFC')).trim();
    if (!texto) {
      if (paginas[paginas.length - 1].length) y -= 7;
      continue;
    }
    const trechos: string[] = [];
    let trecho = '';
    for (const palavra of texto.split(/\s+/)) {
      const candidata = trecho ? `${trecho} ${palavra}` : palavra;
      if (largura(candidata, tamanho, linha.negrito) <= larguraTexto) {
        trecho = candidata;
        continue;
      }
      if (trecho) trechos.push(trecho);
      trecho = '';
      for (const caractere of palavra) {
        if (largura(trecho + caractere, tamanho, linha.negrito) > larguraTexto) {
          trechos.push(trecho);
          trecho = '';
        }
        trecho += caractere;
      }
    }
    if (trecho) trechos.push(trecho);

    const altura = alturaLinha(tamanho);
    if (linha.manterComProxima && y - trechos.length * altura < base) {
      paginas.push([]);
      y = topo;
    }
    for (const textoLinha of trechos) {
      if (y < base) {
        paginas.push([]);
        y = topo;
      }
      paginas[paginas.length - 1].push({ ...linha, texto: textoLinha, y });
      y -= altura;
    }
  }

  const objetos: string[] = [];
  // 1: Catalog, 2: Pages, 3: Font Regular (Helvetica), 4: Font Bold (Helvetica-Bold)
  objetos.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj');
  const idsPaginas: number[] = [];

  objetos.push(''); // placeholder 2 0 obj (Pages)
  objetos.push(
    '3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj'
  );
  objetos.push(
    '4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj'
  );

  paginas.forEach((linhasPag, idxPag) => {
    const idConteudo = objetos.length + 1;
    const idPagina = objetos.length + 2;
    idsPaginas.push(idPagina);

    const ops: string[] = ['BT'];

    for (const l of linhasPag) {
      const fonte = l.negrito ? '/F2' : '/F1';
      const tam = l.tamanho || 10;
      const textoEsc = escaparLiteralPdf(l.texto);
      const x = l.centralizado
        ? Math.max(margem, Math.round((larguraPagina - largura(l.texto, tam, l.negrito)) / 2))
        : margem;
      ops.push(`${fonte} ${tam} Tf`);
      ops.push(`1 0 0 1 ${x} ${l.y} Tm`);
      ops.push(`(${textoEsc}) Tj`);
    }

    // Rodapé institucional SEI em cada página
    const textoRodape = escaparLiteralPdf(
      `${rodapeSei} / pg. ${idxPag + 1} de ${paginas.length}`
    );
    ops.push('/F1 8 Tf');
    ops.push(`1 0 0 1 ${margem} 32 Tm`);
    ops.push(`(${textoRodape}) Tj`);
    ops.push('ET');

    const stream = ops.join('\n');
    objetos.push(
      `${idConteudo} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj`
    );
    objetos.push(
      `${idPagina} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${idConteudo} 0 R >>\nendobj`
    );
  });

  objetos[1] = `2 0 obj\n<< /Type /Pages /Kids [${idsPaginas.map((id) => `${id} 0 R`).join(' ')}] /Count ${idsPaginas.length} >>\nendobj`;

  let corpo = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objetos) {
    offsets.push(corpo.length);
    corpo += obj + '\n';
  }
  const startXref = corpo.length;
  corpo += `xref\n0 ${objetos.length + 1}\n`;
  corpo += '0000000000 65535 f \n';
  for (let i = 1; i <= objetos.length; i++) {
    corpo += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  corpo += `trailer\n<< /Size ${objetos.length + 1} /Root 1 0 R >>\nstartxref\n${startXref}\n%%EOF`;

  const bytes = new Uint8Array(corpo.length);
  for (let i = 0; i < corpo.length; i++) {
    bytes[i] = corpo.charCodeAt(i) & 0xff;
  }
  return bytes;
}

/**
 * Gera os bytes do PDF do Parecer Técnico da SUMAE conforme modelo fixo institucional SEI (págs. 23–26)
 */
export function gerarPdfParecerTecnicoSei(
  recurso: RecursoAdmin,
  analise: AnaliseRecursoProtocolo,
  parecerOverride?: ParecerTecnicoSumae
): Uint8Array {
  const p = parecerOverride || analise.parecerSumae;
  const linhas: LinhaFormatadaPdf[] = [
    { texto: 'PODER JUDICIÁRIO DO ESTADO DO ACRE', negrito: true, centralizado: true, tamanho: 11 },
    {
      texto: 'Subsecretaria de Monitoramento e Análise Estratégica - SUMAE/SEGOV',
      negrito: true,
      centralizado: true,
      tamanho: 10,
    },
    { texto: '' },
    { texto: 'Parecer técnico', negrito: true, centralizado: true, tamanho: 18 },
    { texto: '' },
    {
      texto: `Parecer Técnico SUMAE n.: ${p.numeroParecer} (Versão v${Math.max(1, p.versao)})`,
      negrito: true,
    },
    { texto: `Processo SEI: ${analise.processoSei} | Protocolo: ${recurso.protocolo}`, negrito: true },
    {
      texto: `Data de Análise: ${formatarDataHora(p.emitidoEm || p.atualizadoEm || new Date().toISOString())}`,
    },
    { texto: `Analista Técnico: ${p.responsavelNome} (${p.responsavelCargo})` },
    {
      texto: `Unidade Recorrente: ${recurso.unidade.codigo} - ${recurso.unidade.nome} (${recurso.unidade.comarca}-AC)`,
    },
    {
      texto: `Respondente: ${recurso.responsavel.nome} (${recurso.responsavel.cargo}) - CPF ${formatarCpf(recurso.responsavel.cpf)}`,
    },
    { texto: `E-mail: ${recurso.emailGoogle} | Telefone: ${recurso.responsavel.telefone}` },
    { texto: 'I. Objeto do recurso', negrito: true, tamanho: 13, manterComProxima: true },
  ];

  for (const l of paragrafosPdf(p.sintesePedido)) {
    linhas.push({ texto: l });
  }
  linhas.push({ texto: '' });
  linhas.push({
    texto: 'II. Prazo e evidências',
    negrito: true,
    tamanho: 13,
    manterComProxima: true,
  });
  linhas.push({
    texto: `2.1. Tempestividade e Evidencias Obrigatorias: ${p.tempestivo ? 'TEMPESTIVO' : 'INTEMPESTIVO'} | Falta de Evidencia: ${p.possuiFaltaEvidenciaObrigatoria ? 'SIM' : 'NAO'}`,
    negrito: true,
  });
  for (const l of paragrafosPdf(p.conferenciaPrazoEvidencias)) {
    linhas.push({ texto: l });
  }
  if (p.possuiFaltaEvidenciaObrigatoria && p.registroFaltasEvidencias) {
    linhas.push({ texto: 'Registro de faltas documentais:', negrito: true });
    for (const l of paragrafosPdf(p.registroFaltasEvidencias)) {
      linhas.push({ texto: l });
    }
  }
  linhas.push({ texto: '' });
  linhas.push({ texto: '2.2. Dados, Fontes Consultadas, Filtros e Periodo de Referencia:', negrito: true });
  for (const l of paragrafosPdf(`Fontes: ${p.dadosFontesConsultadas}`)) linhas.push({ texto: l });
  for (const l of paragrafosPdf(`Filtros: ${p.filtrosAplicados}`)) linhas.push({ texto: l });
  for (const l of paragrafosPdf(`Período: ${p.periodoReferencia}`)) linhas.push({ texto: l });
  linhas.push({ texto: '' });
  linhas.push({ texto: '2.3. Metodologia, Memoria de Calculo e Fundamentacao Tecnica:', negrito: true });
  for (const l of paragrafosPdf(p.metodologiaMemoriaCalculo)) linhas.push({ texto: l });

  linhas.push({ texto: '' });
  linhas.push({ texto: 'III. Conclusão por item', negrito: true, tamanho: 13, manterComProxima: true });
  for (const c of p.conclusoesPorItem) {
    linhas.push({
      texto: `Item #${c.itemN} - ${c.sigla} (${c.indicador}) | Recomendacao: ${c.recomendacao}`,
      negrito: true,
    });
    linhas.push({
      texto: `Pontuacao Preliminar: ${c.pontuacaoPreliminar !== '' ? c.pontuacaoPreliminar : '-'} pts -> Recomendada: ${c.pontuacaoRecomendada !== '' ? c.pontuacaoRecomendada : '-'} pts (${c.impactoPontuacao})`,
    });
    for (const l of paragrafosPdf(c.conclusaoTecnica)) linhas.push({ texto: l });
    linhas.push({ texto: '' });
  }
  linhas.push({ texto: 'Sintese Conclusiva da SUMAE:', negrito: true });
  for (const l of paragrafosPdf(p.conclusaoGeral)) linhas.push({ texto: l });

  if (p.versao > 1 && p.justificativaRetificacao) {
    linhas.push({ texto: '' });
    linhas.push({ texto: `NOTA DE RETIFICACAO (Versão v${p.versao}):`, negrito: true });
    for (const l of paragrafosPdf(p.justificativaRetificacao)) linhas.push({ texto: l });
  }

  linhas.push({ texto: '' });
  linhas.push({ texto: 'IV. Encaminhamento', negrito: true, tamanho: 13, manterComProxima: true });
  for (const l of paragrafosPdf(p.encaminhamentoComissao)) linhas.push({ texto: l });
  linhas.push({ texto: 'E o Parecer, S.M.J.' });
  linhas.push({ texto: '' });
  linhas.push({ texto: `${p.responsavelNome}`, negrito: true });
  linhas.push({ texto: `${p.responsavelCargo} - ${p.lotacao}` });
  linhas.push({
    texto: `Documento assinado eletronicamente por ${p.responsavelNome}, em ${formatarDataHora(p.emitidoEm || new Date().toISOString())}, conforme art. 1, III, "b", da Lei 11.419/2006.`,
  });
  linhas.push({
    texto: `Código verificador SEI: ${p.codigoVerificadorSei || 'RASCUNHO'} | Código CRC: ${p.codigoCrcSei || '--------'}`,
    negrito: true,
  });

  return construirBytesPdfDeLinhas(
    `Parecer Técnico SUMAE ${p.numeroParecer}`,
    `Parecer Técnico ${p.numeroParecer} - SUMAE (${p.codigoVerificadorSei || 'RASCUNHO'})   SEI ${analise.processoSei}`,
    linhas
  );
}

/**
 * Gera os bytes do PDF da Decisão Final da Comissão Revisora conforme modelo fixo institucional SEI (págs. 27–28)
 */
export function gerarPdfDecisaoComissaoSei(
  recurso: RecursoAdmin,
  analise: AnaliseRecursoProtocolo,
  decisaoOverride?: DecisaoFinalComissao
): Uint8Array {
  const d = decisaoOverride || analise.decisaoComissao;
  const p = analise.parecerSumae;

  const linhas: LinhaFormatadaPdf[] = [
    { texto: 'PODER JUDICIÁRIO DO ESTADO DO ACRE', negrito: true, centralizado: true, tamanho: 11 },
    {
      texto: 'Comissao Revisora do Premio TJAC de Qualidade 2026 / Divisao de Consultoria e Suporte Juridico',
      negrito: true,
      centralizado: true,
      tamanho: 10,
    },
    { texto: '' },
    { texto: `Processo Administrativo SEI n.: ${analise.processoSei}`, negrito: true },
    { texto: `Protocolo do Recurso: ${recurso.protocolo} | Local: Rio Branco - AC` },
    {
      texto: `Unidade Recorrente: ${recurso.unidade.codigo} - ${recurso.unidade.nome} (${recurso.unidade.comarca})`,
    },
    { texto: '' },
    {
      texto: `Decisão final da Comissão Revisora (${d.numeroDecisao} - v${Math.max(1, d.versao)})`,
      negrito: true,
      centralizado: true,
      tamanho: 18,
    },
    { texto: '' },
    { texto: 'I. Relatório', negrito: true, tamanho: 13, manterComProxima: true },
  ];

  for (const l of paragrafosPdf(d.relatorio)) linhas.push({ texto: l });

  linhas.push({ texto: '' });
  linhas.push({ texto: 'II. Admissibilidade e fundamentação', negrito: true, tamanho: 13, manterComProxima: true });
  linhas.push({
    texto: `1. Juizo de Admissibilidade: ${d.conhecido && !d.faltaEvidenciaObrigatoria ? 'RECURSO CONHECIDO' : 'RECURSO NAO CONHECIDO (Art. 13 e Anexo III, item 3)'}`,
    negrito: true,
  });
  for (const l of paragrafosPdf(d.fundamentacaoAdmissibilidade)) linhas.push({ texto: l });

  linhas.push({ texto: '' });
  linhas.push({
    texto: `2. Subsidio Tecnico da SUMAE (Parecer Técnico n. ${p.numeroParecer}):`,
    negrito: true,
  });
  for (const l of paragrafosPdf(p.conclusaoGeral)) linhas.push({ texto: l });

  if (d.conhecido && !d.faltaEvidenciaObrigatoria && d.resultadoGeral !== 'NAO_CONHECIDO') {
    linhas.push({ texto: '' });
    linhas.push({ texto: '3. Exame do Merito por Indicador Impugnado:', negrito: true });
    for (const l of paragrafosPdf(d.fundamentacaoGeral)) linhas.push({ texto: l });
    linhas.push({ texto: '' });

    for (const it of d.itensDecididos) {
      linhas.push({
        texto: `Item #${it.itemN} - ${it.sigla} (${it.indicador}) | Resultado: ${it.resultadoItem}`,
        negrito: true,
      });
      linhas.push({
        texto: `Pontuacao: Preliminar ${it.pontuacaoPreliminar !== '' ? it.pontuacaoPreliminar : '-'} pts -> Final ${it.pontuacaoFinal !== '' ? it.pontuacaoFinal : '-'} pts | Impacto: ${it.impactoPontuacao}`,
      });
      for (const l of paragrafosPdf(`Fundamentacao: ${it.fundamentacao}`)) {
        linhas.push({ texto: l });
      }
      if (it.providenciaDeterminada) {
        for (const l of paragrafosPdf(`Providencia: ${it.providenciaDeterminada}`)) {
          linhas.push({ texto: l });
        }
      }
      if (it.necessitaReavaliacaoReprocessamento) {
        for (const l of paragrafosPdf(
          `Reavaliacao/Reprocessamento: SIM - ${it.detalheReprocessamento || 'Determinado reprocessamento pela SUMAE.'}`
        )) {
          linhas.push({ texto: l });
        }
      }
      linhas.push({ texto: '' });
    }
  }

  linhas.push({ texto: 'III. Dispositivo', negrito: true, tamanho: 13, manterComProxima: true });
  linhas.push({
    texto: `RESULTADO GERAL DO JULGAMENTO: ${d.resultadoGeral}`,
    negrito: true,
  });
  for (const l of paragrafosPdf(d.dispositivo)) linhas.push({ texto: l });
  linhas.push({ texto: '' });
  linhas.push({ texto: 'Encaminhamento e Ciencia Institucional:', negrito: true });
  for (const l of paragrafosPdf(d.encaminhamentoCienciaProvidencias)) {
    linhas.push({ texto: l });
  }

  if (d.versao > 1 && d.justificativaRetificacao) {
    linhas.push({ texto: '' });
    linhas.push({ texto: `NOTA DE RETIFICACAO (Versão v${d.versao}):`, negrito: true });
    for (const l of paragrafosPdf(d.justificativaRetificacao)) linhas.push({ texto: l });
  }

  linhas.push({ texto: '' });
  linhas.push({ texto: `${d.relatorNome}`, negrito: true });
  linhas.push({ texto: `${d.relatorCargo}` });
  linhas.push({ texto: `${d.membrosComissao}` });
  linhas.push({
    texto: `Documento assinado eletronicamente por ${d.relatorNome}, ${d.relatorCargo}, em ${formatarDataHora(d.emitidoEm || new Date().toISOString())}, conforme art. 1, III, "b", da Lei 11.419/2006.`,
  });
  linhas.push({
    texto: `Código verificador SEI: ${d.codigoVerificadorSei || 'RASCUNHO'} | Código CRC: ${d.codigoCrcSei || '--------'}`,
    negrito: true,
  });

  return construirBytesPdfDeLinhas(
    `Decisao Comissao Revisora ${d.numeroDecisao}`,
    `Decisao ${d.codigoVerificadorSei || 'RASCUNHO'}   SEI ${analise.processoSei}`,
    linhas
  );
}

/**
 * Inicia o download imediato do arquivo PDF para juntada ao SEI no navegador
 */
export function baixarBytesPdfNoNavegador(bytes: Uint8Array, nomeArquivo: string): void {
  if (typeof window === 'undefined') return;
  const copia = new Uint8Array(bytes.byteLength);
  copia.set(bytes);
  const blob = new Blob([copia.buffer], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nomeArquivo.endsWith('.pdf') ? nomeArquivo : `${nomeArquivo}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
