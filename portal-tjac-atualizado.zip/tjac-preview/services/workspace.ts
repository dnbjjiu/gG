import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  type User,
} from 'firebase/auth';
import {
  PASTA_RAIZ_DRIVE_URL,
  ROOT_FOLDER_ID,
} from '../config';
import { app } from '../firebase';
import {
  DRIVE_ROOT_FOLDER_ID,
  listarEvidenciasPastaRaiz,
  organizarEvidenciasNoDrive,
} from '../src/services/drive';
import type { RecursoAdmin } from '../types';
import { formatarCpf } from '../utils';
import { salvarPlanilhaMestraUrl } from './api';

export const SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.activity',
  'https://www.googleapis.com/auth/drive.activity.readonly',
  'https://www.googleapis.com/auth/drive.appdata',
  'https://www.googleapis.com/auth/drive.apps.readonly',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.install',
  'https://www.googleapis.com/auth/drive.meet.readonly',
  'https://www.googleapis.com/auth/drive.metadata',
  'https://www.googleapis.com/auth/drive.metadata.readonly',
  'https://www.googleapis.com/auth/drive.photos.readonly',
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/drive.scripts',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/spreadsheets.readonly',
  'https://www.googleapis.com/auth/forms.body',
  'https://www.googleapis.com/auth/forms.body.readonly',
  'https://www.googleapis.com/auth/forms.responses.readonly',
];

const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => provider.addScope(scope));
provider.setCustomParameters({ prompt: 'consent' });

// Flag indicando se o fluxo de login está em andamento
let isSigningIn = false;
// Cache em memória para o access token OAuth (nunca salvo em localStorage/sessionStorage)
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{
  user: User;
  accessToken: string;
  idToken: string;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Não foi possível obter o token de acesso do Google Workspace.');
    }
    const idToken = credential.idToken || (await result.user.getIdToken());
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken, idToken };
  } catch (error) {
    console.error('Erro no login Google Workspace:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logoutWorkspace = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

/* ============================================================================
 * GOOGLE DRIVE API (drive.googleapis.com)
 * ========================================================================== */
export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  size?: string;
  modifiedTime?: string;
}

export async function listarArquivosDrive(
  accessToken: string,
  termoBusca = '',
  folderId: string = DRIVE_ROOT_FOLDER_ID
): Promise<DriveFileItem[]> {
  const itens = await listarEvidenciasPastaRaiz(accessToken, termoBusca, folderId);
  return itens.map((it) => ({
    id: it.id,
    name: it.name,
    mimeType: it.mimeType,
    webViewLink: it.webViewLink,
    size: it.size !== undefined ? String(it.size) : undefined,
    modifiedTime: it.modifiedTime,
  }));
}

export async function sincronizarEstruturaPastasDrive(
  accessToken: string,
  recursos: RecursoAdmin[]
): Promise<{ pastaRaizId: string; pastaRaizUrl: string; pastasCriadas: number }> {
  const resultado = await organizarEvidenciasNoDrive(accessToken, recursos, ROOT_FOLDER_ID);
  return {
    pastaRaizId: resultado.rootFolderId,
    pastaRaizUrl: PASTA_RAIZ_DRIVE_URL,
    pastasCriadas: resultado.pastasVerificadasOuCriadas,
  };
}

/* ============================================================================
 * GOOGLE SHEETS API (sheets.googleapis.com)
 * ========================================================================== */
export interface MetadadosPlanilha {
  spreadsheetId: string;
  titulo: string;
  spreadsheetUrl: string;
  abas: { sheetId: number; title: string }[];
}

export async function obterMetadadosPlanilha(
  accessToken: string,
  spreadsheetId: string
): Promise<MetadadosPlanilha> {
  const safeId = encodeURIComponent(spreadsheetId.trim());
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${safeId}?fields=spreadsheetId,spreadsheetUrl,properties.title,sheets.properties(sheetId,title)`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Erro ao abrir planilha no Google Sheets (${res.status}): ${errText.slice(0, 180)}`);
  }
  const data = await res.json();
  return {
    spreadsheetId: data.spreadsheetId,
    titulo: data.properties?.title || 'Planilha sem título',
    spreadsheetUrl: data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${data.spreadsheetId}/edit`,
    abas: (data.sheets || []).map((s: { properties: { sheetId: number; title: string } }) => ({
      sheetId: s.properties.sheetId,
      title: s.properties.title,
    })),
  };
}

export async function lerAbaPlanilha(
  accessToken: string,
  spreadsheetId: string,
  tituloAba: string
): Promise<string[][]> {
  const safeId = encodeURIComponent(spreadsheetId.trim());
  const safeRange = encodeURIComponent(`'${tituloAba.replace(/'/g, "''")}'!A1:Z50`);
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${safeId}/values/${safeRange}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Erro ao ler aba "${tituloAba}" (${res.status}): ${errText.slice(0, 180)}`);
  }
  const data = await res.json();
  return Array.isArray(data.values) ? data.values : [];
}

export async function criarPlanilhaConsolidadaSheets(
  accessToken: string,
  recursos: RecursoAdmin[]
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: 'Prêmio TJAC 2026 — Recursos Consolidados (DIGED/SUMAE)',
      },
      sheets: [
        { properties: { title: 'RECURSOS' } },
        { properties: { title: 'ITENS' } },
        { properties: { title: 'ARQUIVOS' } },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Falha ao criar planilha no Google Sheets (${createRes.status}): ${errText.slice(0, 180)}`);
  }

  const created = await createRes.json();
  const spreadsheetId = created.spreadsheetId as string;
  const spreadsheetUrl =
    (created.spreadsheetUrl as string) ||
    `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  const linhasRecursos = [
    [
      'PROTOCOLO',
      'STATUS',
      'ENVIADO_EM',
      'EMAIL_GOOGLE',
      'NOME',
      'CPF',
      'CARGO_FUNCAO',
      'TELEFONE',
      'GRAU',
      'TIPO_UNIDADE',
      'COD_UNIDADE',
      'UNIDADE',
      'COMARCA',
      'QTD_ITENS',
      'IMPUGNA_LISTA_SERVIDORES',
      'IMPUGNACAO_LISTA_TEXTO',
      'PASTA_URL',
    ],
    ...recursos.map((r) => [
      r.protocolo,
      r.status,
      r.enviadoEm,
      r.emailGoogle,
      r.responsavel.nome,
      formatarCpf(r.responsavel.cpf),
      r.responsavel.cargo,
      r.responsavel.telefone,
      r.unidade.grau,
      r.unidade.tipo,
      r.unidade.codigo,
      r.unidade.nome,
      r.unidade.comarca,
      String(r.qtdItens),
      r.impugnaListaServidores ? 'SIM' : 'NAO',
      r.impugnacaoListaTexto,
      r.pastaUrl,
    ]),
  ];

  const linhasItens = [
    [
      'PROTOCOLO',
      'ITEM_N',
      'GRUPO',
      'SIGLA',
      'INDICADOR',
      'SUBITEM',
      'TIPO_IMPUGNACAO',
      'PONTUACAO_PRELIMINAR',
      'PONTUACAO_PLEITEADA',
      'STATUS_ANALISE',
      'RELATOR',
      'DECISAO',
      'PONTUACAO_FINAL',
      'PASTA_ITEM_URL',
      'QTD_ARQUIVOS',
      'FUNDAMENTACAO',
    ],
    ...recursos.flatMap((r) =>
      r.itens.map((it) => [
        r.protocolo,
        String(it.itemN),
        it.grupo,
        it.sigla,
        it.indicador,
        it.subitem,
        it.tipoImpugnacao,
        String(it.pontuacaoPreliminar),
        String(it.pontuacaoPleiteada),
        it.statusAnalise,
        it.relator,
        it.decisao,
        String(it.pontuacaoFinal),
        it.pastaItemUrl,
        String(it.arquivos.length),
        it.fundamentacao,
      ])
    ),
  ];

  const linhasArquivos = [
    [
      'PROTOCOLO',
      'ITEM_N',
      'SIGLA',
      'NOME_ARQUIVO',
      'MIME',
      'BYTES',
      'URL_DRIVE',
      'SHA256',
      'ENVIADO_EM',
      'EMAIL_GOOGLE',
    ],
    ...recursos.flatMap((r) =>
      r.itens.flatMap((it) =>
        it.arquivos.map((a) => [
          r.protocolo,
          String(it.itemN),
          it.sigla,
          a.nome,
          a.mime,
          String(a.bytes),
          a.url,
          a.sha256,
          a.enviadoEm,
          a.emailGoogle,
        ])
      )
    ),
  ];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: [
          { range: "'RECURSOS'!A1", values: linhasRecursos },
          { range: "'ITENS'!A1", values: linhasItens },
          { range: "'ARQUIVOS'!A1", values: linhasArquivos },
        ],
      }),
    }
  );

  salvarPlanilhaMestraUrl(spreadsheetUrl);
  return { spreadsheetId, spreadsheetUrl };
}

/* ============================================================================
 * GOOGLE FORMS API (forms.googleapis.com)
 * ========================================================================== */
export interface DadosFormularioGoogle {
  formId: string;
  titulo: string;
  responderUri: string;
  qtdQuestoes: number;
  qtdRespostas: number;
}

export async function consultarFormularioGoogle(
  accessToken: string,
  formId: string
): Promise<DadosFormularioGoogle> {
  const safeFormId = encodeURIComponent(formId.trim());
  const resForm = await fetch(`https://forms.googleapis.com/v1/forms/${safeFormId}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!resForm.ok) {
    const errText = await resForm.text();
    throw new Error(`Erro ao consultar Google Forms (${resForm.status}): ${errText.slice(0, 180)}`);
  }
  const form = await resForm.json();

  let qtdRespostas = 0;
  const resResp = await fetch(
    `https://forms.googleapis.com/v1/forms/${safeFormId}/responses`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (resResp.ok) {
    const respData = await resResp.json();
    qtdRespostas = Array.isArray(respData.responses) ? respData.responses.length : 0;
  }

  return {
    formId: form.formId || formId,
    titulo: form.info?.title || 'Formulário Google',
    responderUri: form.responderUri || `https://docs.google.com/forms/d/${safeFormId}/viewform`,
    qtdQuestoes: Array.isArray(form.items) ? form.items.length : 0,
    qtdRespostas,
  };
}

export async function criarFormularioGoogleRecursos(
  accessToken: string
): Promise<DadosFormularioGoogle> {
  const createRes = await fetch('https://forms.googleapis.com/v1/forms', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      info: {
        title: 'Prêmio TJAC de Qualidade 2026 — Formulário de Recursos (Espelho Google Forms)',
        documentTitle: 'Recursos — Prêmio TJAC de Qualidade 2026',
      },
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Falha ao criar formulário no Google Forms (${createRes.status}): ${errText.slice(0, 180)}`);
  }

  const form = await createRes.json();
  const safeFormId = encodeURIComponent(String(form.formId || '').trim());

  await fetch(`https://forms.googleapis.com/v1/forms/${safeFormId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      requests: [
        {
          updateFormInfo: {
            info: {
              description:
                'Formulário auxiliar espelho no Google Forms para registro de recursos ao Resultado Preliminar do Prêmio TJAC de Qualidade 2026 (Portaria PRESI/TJAC nº 1961/2026, alterada pela Portaria PRESI nº 4335/2026).',
            },
            updateMask: 'description',
          },
        },
        {
          createItem: {
            item: {
              title: 'Unidade Judiciária / Órgão Recorrente (1º ou 2º Grau)',
              questionItem: {
                question: {
                  required: true,
                  textQuestion: { paragraph: false },
                },
              },
            },
            location: { index: 0 },
          },
        },
        {
          createItem: {
            item: {
              title: 'Sigla do Indicador Impugnado (Anexo II da Portaria PRESI nº 1961/2026)',
              questionItem: {
                question: {
                  required: true,
                  textQuestion: { paragraph: false },
                },
              },
            },
            location: { index: 1 },
          },
        },
        {
          createItem: {
            item: {
              title: 'Fundamentação Técnica, Memória de Cálculo e Link das Evidências no Drive (Art. 13)',
              questionItem: {
                question: {
                  required: true,
                  textQuestion: { paragraph: true },
                },
              },
            },
            location: { index: 2 },
          },
        },
      ],
    }),
  });

  return {
    formId: form.formId,
    titulo: 'Prêmio TJAC de Qualidade 2026 — Formulário de Recursos (Espelho Google Forms)',
    responderUri: form.responderUri || `https://docs.google.com/forms/d/${safeFormId}/edit`,
    qtdQuestoes: 3,
    qtdRespostas: 0,
  };
}
