import type { Usuario } from '../types';

declare global {
  interface Window {
    google?: {
      accounts?: {
        id?: {
          initialize: (config: {
            client_id: string;
            callback: (resp: { credential?: string }) => void;
            auto_select?: boolean;
            cancel_on_tap_outside?: boolean;
          }) => void;
          renderButton: (
            parent: HTMLElement,
            options: {
              theme?: 'outline' | 'filled_blue' | 'filled_black';
              size?: 'large' | 'medium' | 'small';
              text?: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
              shape?: 'rectangular' | 'pill' | 'circle' | 'square';
              width?: number;
              locale?: string;
            }
          ) => void;
          disableAutoSelect?: () => void;
        };
      };
    };
  }
}

function decodificarBase64Url(str: string): string {
  const base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const pad = base64.length % 4 === 0 ? '' : '='.repeat(4 - (base64.length % 4));
  const bin = atob(base64 + pad);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder('utf-8').decode(bytes);
}

function codificarBase64Url(obj: Record<string, unknown>): string {
  const json = JSON.stringify(obj);
  const bytes = new TextEncoder().encode(json);
  let bin = '';
  bytes.forEach((b) => {
    bin += String.fromCharCode(b);
  });
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function lerToken(token: string): Usuario {
  if (!token || typeof token !== 'string') {
    throw new Error('Credencial vazia.');
  }
  const partes = token.split('.');
  if (partes.length < 2) {
    throw new Error('Formato de token JWT inválido.');
  }
  const payload = JSON.parse(decodificarBase64Url(partes[1]));
  if (!payload || !payload.email) {
    throw new Error('Token sem endereço de e-mail.');
  }
  return {
    email: String(payload.email).toLowerCase(),
    nome: String(payload.name || payload.email),
    sub: String(payload.sub || payload.email),
    foto: payload.picture ? String(payload.picture) : undefined,
    exp: payload.exp ? Number(payload.exp) : undefined,
    demo: Boolean(payload.demo),
  };
}

export function tokenValido(u: Usuario | null | undefined): boolean {
  if (!u || !u.email) return false;
  if (!u.exp) return true;
  const agoraSeg = Math.floor(Date.now() / 1000);
  return u.exp > agoraSeg + 15;
}

export function criarTokenDemo(parcial?: { nome?: string; email?: string }): string {
  const agora = Math.floor(Date.now() / 1000);
  const header = codificarBase64Url({ alg: 'none', typ: 'JWT' });
  const body = codificarBase64Url({
    iss: 'https://accounts.google.com',
    sub: 'demo-tjac-2026',
    email: (parcial?.email || 'magistrado.demo@tjac.jus.br').toLowerCase(),
    email_verified: true,
    name: parcial?.nome || 'Magistrado(a) / Diretor(a) — Demonstração TJAC',
    iat: agora,
    exp: agora + 8 * 3600,
    demo: true,
  });
  return `${header}.${body}.demo`;
}

export function sairGoogle(): void {
  try {
    window.google?.accounts?.id?.disableAutoSelect?.();
  } catch {
    /* ignora se GIS não estiver carregado */
  }
}
