export type Grau = '1G' | '2G';

export type TipoUnidade =
  | 'CIVEL'
  | 'FAMILIA'
  | 'FAZENDA'
  | 'EXEC_FISCAL'
  | 'CRIMINAL'
  | 'JURI'
  | 'ROUBO'
  | 'VIOL_DOM'
  | 'INFANCIA'
  | 'VEP'
  | 'JEC'
  | 'JECRIM'
  | 'JEFAZ'
  | 'TURMA_RECURSAL'
  | 'VARA_UNICA'
  | 'GARANTIAS'
  | 'GAB_CIVEL'
  | 'GAB_CRIMINAL'
  | 'VICE_PRESIDENCIA'
  | 'SEJUD';

export type TipoImpugnacao =
  | 'APURACAO'
  | 'APLICABILIDADE'
  | 'FAIXA_ARREDONDAMENTO'
  | 'FONTE_DADOS'
  | 'OUTRO';

export interface Usuario {
  email: string;
  nome: string;
  sub: string;
  foto?: string;
  exp?: number;
  demo?: boolean;
}

export interface UnidadeCatalogo {
  codigo: string;
  nome: string;
  tipo: TipoUnidade;
  grau: Grau;
  comarca: string;
}

export interface ConfigServidor {
  usuario: {
    email: string;
    nome: string;
    sub: string;
  };
  prazo: {
    inicio: string;
    fim: string;
    aberto: boolean;
  };
  unidades: UnidadeCatalogo[];
  limites: {
    maxTexto: number;
    minTexto: number;
    maxArqPorItem: number;
    maxBytesArq: number;
    mimes: string[];
  };
  agoraServidor: string;
}

export interface EvidenciasChecklist {
  a: boolean;
  b: boolean;
  c: boolean;
  d: boolean;
  e: boolean;
}

export interface ItemRecursoInput {
  id: string;
  grupo: string;
  sigla: string;
  indicador: string;
  subitem: string;
  tipoImpugnacao: TipoImpugnacao;
  pontuacaoPreliminar: string;
  pontuacaoPleiteada: string;
  fundamentacao: string;
  evidencias: EvidenciasChecklist;
}

export interface ItemRecursoPayload {
  grupo: string;
  sigla: string;
  indicador: string;
  subitem: string;
  tipoImpugnacao: TipoImpugnacao;
  pontuacaoPreliminar: number | '';
  pontuacaoPleiteada: number | '';
  fundamentacao: string;
  evidencias: EvidenciasChecklist;
}

export interface CriarRecursoPayload {
  clientRequestId: string;
  declaracao: boolean;
  responsavel: {
    nome: string;
    cpf: string;
    cargo: string;
    telefone: string;
  };
  unidade: {
    grau: Grau;
    tipo: TipoUnidade;
    codigo: string;
    nome: string;
    comarca: string;
  };
  listaServidores: {
    impugna: boolean;
    texto: string;
  };
  itens: ItemRecursoPayload[];
}

export interface ArquivoEnviadoResumo {
  itemN: number;
  sigla: string;
  subitem: string;
  nome: string;
  mime: string;
  bytes: number;
  sha256: string;
  fileId: string;
}

export interface ResultadoEnvio {
  protocolo: string;
  status: string;
  enviadoEm: string;
  reaproveitado: boolean;
  usuario: Usuario;
  payload: CriarRecursoPayload;
  arquivos: ArquivoEnviadoResumo[];
}

export interface ItemRecursoResumo {
  sigla: string;
  subitem: string;
  statusAnalise: string;
  decisao: string;
  qtdArquivos: number;
}

export interface RecursoResumo {
  protocolo: string;
  status: string;
  unidade: string;
  criadoEm: string;
  enviadoEm: string;
  itens: ItemRecursoResumo[];
  impugnaListaServidores?: boolean;
  processoSei?: string;
  estadoTramitacao?: EstadoTramitacao;
  divulgado?: boolean;
}

export type StatusAnalise =
  | 'PENDENTE'
  | 'EM_ANALISE'
  | 'NAO_CONHECIDO'
  | 'PROVIDO'
  | 'PARCIALMENTE_PROVIDO'
  | 'IMPROVIDO';

export interface ArquivoAdmin {
  protocolo: string;
  itemN: number;
  sigla: string;
  nome: string;
  mime: string;
  bytes: number;
  fileId: string;
  url: string;
  sha256: string;
  enviadoEm: string;
  emailGoogle: string;
}

export interface ItemRecursoAdmin {
  protocolo: string;
  itemN: number;
  grupo: string;
  sigla: string;
  indicador: string;
  subitem: string;
  tipoImpugnacao: TipoImpugnacao;
  pontuacaoPreliminar: number | '';
  pontuacaoPleiteada: number | '';
  fundamentacao: string;
  evidencias: EvidenciasChecklist;
  pastaItemUrl: string;
  qtdArquivos: number;
  statusAnalise: StatusAnalise;
  relator: string;
  parecer: string;
  decisao: string;
  pontuacaoFinal: number | '';
  dataDecisao: string;
  arquivos: ArquivoAdmin[];
}

export interface RecursoAdmin {
  protocolo: string;
  status: string;
  criadoEm: string;
  enviadoEm: string;
  emailGoogle: string;
  responsavel: {
    nome: string;
    cpf: string;
    cargo: string;
    telefone: string;
  };
  unidade: {
    grau: Grau;
    tipo: TipoUnidade;
    codigo: string;
    nome: string;
    comarca: string;
  };
  qtdItens: number;
  impugnaListaServidores: boolean;
  impugnacaoListaTexto: string;
  pastaUrl: string;
  pastaId: string;
  declaracaoVeracidade: boolean;
  itens: ItemRecursoAdmin[];
  processoSei?: string;
  estadoTramitacao?: EstadoTramitacao;
  analise?: AnaliseRecursoProtocolo;
}

export interface DadosAdminResposta {
  planilhaUrl: string;
  pastaRaizUrl: string;
  recursos: RecursoAdmin[];
}

export interface AtualizarItemAdminPayload {
  protocolo: string;
  itemN: number;
  statusAnalise: StatusAnalise;
  relator: string;
  parecer: string;
  decisao: string;
  pontuacaoFinal: number | '';
}

/* ============================================================================
 * ANÁLISE DO RECURSO: PARECER TÉCNICO DA SUMAE E DECISÃO DA COMISSÃO REVISORA
 * ========================================================================== */

export type EstadoTramitacao =
  | 'RECEBIDO'
  | 'EM_ANALISE_SUMAE'
  | 'ENCAMINHADO_COMISSAO'
  | 'EM_ANALISE_COMISSAO'
  | 'DECIDIDO';

export type PapelInstitucional = 'SUMAE' | 'COMISSAO' | 'UNIDADE';

export type RecomendacaoTecnicaItem =
  | 'ACOLHER_INTEGRALMENTE'
  | 'ACOLHER_PARCIALMENTE'
  | 'REJEITAR'
  | 'NAO_CONHECER';

export interface ConclusaoTecnicaItemSumae {
  itemN: number;
  sigla: string;
  indicador: string;
  subitem: string;
  evidenciasCompletas: boolean;
  faltasEvidenciasItem: string;
  recomendacao: RecomendacaoTecnicaItem;
  pontuacaoPreliminar: number | '';
  pontuacaoRecomendada: number | '';
  impactoPontuacao: string;
  conclusaoTecnica: string;
}

export interface ParecerTecnicoSumae {
  numeroParecer: string; // Ex.: "001/2026"
  statusDocumento: 'RASCUNHO' | 'EMITIDO';
  versao: number;
  sintesePedido: string;
  tempestivo: boolean;
  conferenciaPrazoEvidencias: string;
  possuiFaltaEvidenciaObrigatoria: boolean;
  registroFaltasEvidencias: string;
  dadosFontesConsultadas: string;
  filtrosAplicados: string;
  periodoReferencia: string;
  metodologiaMemoriaCalculo: string;
  conclusoesPorItem: ConclusaoTecnicaItemSumae[];
  conclusaoGeral: string;
  responsavelNome: string;
  responsavelCargo: string;
  responsavelEmail: string;
  lotacao: string;
  encaminhamentoComissao: string;
  justificativaRetificacao: string;
  atualizadoEm: string;
  emitidoEm: string;
  codigoVerificadorSei: string;
  codigoCrcSei: string;
  ultimoEmissionId: string;
}

export type ResultadoMeritoItem = 'PROVIDO' | 'PARCIALMENTE_PROVIDO' | 'DESPROVIDO';

export type ResultadoGeralDecisao =
  | 'NAO_CONHECIDO'
  | 'PROVIDO'
  | 'PARCIALMENTE_PROVIDO'
  | 'DESPROVIDO';

export interface DecisaoItemComissao {
  itemN: number;
  sigla: string;
  indicador: string;
  subitem: string;
  resultadoItem: ResultadoMeritoItem | 'NAO_CONHECIDO';
  fundamentacao: string;
  providenciaDeterminada: string;
  pontuacaoPreliminar: number | '';
  pontuacaoFinal: number | '';
  impactoPontuacao: string;
  necessitaReavaliacaoReprocessamento: boolean;
  detalheReprocessamento: string;
}

export interface DecisaoFinalComissao {
  numeroDecisao: string; // Ex.: "DEC-001/2026"
  statusDocumento: 'RASCUNHO' | 'EMITIDO';
  versao: number;
  relatorio: string;
  conhecido: boolean;
  faltaEvidenciaObrigatoria: boolean;
  fundamentacaoAdmissibilidade: string;
  resultadoGeral: ResultadoGeralDecisao;
  fundamentacaoGeral: string;
  itensDecididos: DecisaoItemComissao[];
  dispositivo: string;
  encaminhamentoCienciaProvidencias: string;
  relatorNome: string;
  relatorCargo: string;
  relatorEmail: string;
  membrosComissao: string;
  justificativaRetificacao: string;
  atualizadoEm: string;
  emitidoEm: string;
  codigoVerificadorSei: string;
  codigoCrcSei: string;
  ultimoEmissionId: string;
}

export interface DocumentoEmitidoHistorico {
  id: string;
  protocolo: string;
  processoSei: string;
  tipo: 'PARECER_SUMAE' | 'DECISAO_COMISSAO';
  versao: number;
  numeroDocumento: string;
  autoriaNome: string;
  autoriaCargo: string;
  autoriaEmail: string;
  emitidoEm: string;
  justificativaRetificacao: string;
  codigoVerificadorSei: string;
  codigoCrcSei: string;
  resumo: string;
  snapshotParecer?: ParecerTecnicoSumae;
  snapshotDecisao?: DecisaoFinalComissao;
}

export interface HistoricoTramitacaoItem {
  id: string;
  dataHora: string;
  estadoAnterior: EstadoTramitacao;
  estadoNovo: EstadoTramitacao;
  atorNome: string;
  atorEmail: string;
  papel: PapelInstitucional;
  descricao: string;
}

export interface AnaliseRecursoProtocolo {
  protocolo: string;
  processoSei: string;
  seiVinculadoEm: string;
  seiVinculadoPor: string;
  estadoTramitacao: EstadoTramitacao;
  parecerSumae: ParecerTecnicoSumae;
  decisaoComissao: DecisaoFinalComissao;
  historicoDocumentos: DocumentoEmitidoHistorico[];
  historicoTramitacao: HistoricoTramitacaoItem[];
  divulgacao: {
    divulgado: boolean;
    etapaCronograma: string;
    dataPrevistaDivulgacao: string;
    divulgadoEm: string;
  };
}

export interface SalvarParecerSumaePayload {
  protocolo: string;
  processoSei: string;
  papelAtivo: PapelInstitucional;
  acao: 'SALVAR_RASCUNHO' | 'EMITIR_ENCAMINHAR';
  emissionRequestId: string;
  parecer: Omit<
    ParecerTecnicoSumae,
    | 'statusDocumento'
    | 'versao'
    | 'atualizadoEm'
    | 'emitidoEm'
    | 'codigoVerificadorSei'
    | 'codigoCrcSei'
    | 'ultimoEmissionId'
  >;
}

export interface SalvarDecisaoComissaoPayload {
  protocolo: string;
  processoSei: string;
  papelAtivo: PapelInstitucional;
  acao: 'SALVAR_RASCUNHO' | 'EMITIR_DECISAO';
  emissionRequestId: string;
  decisao: Omit<
    DecisaoFinalComissao,
    | 'statusDocumento'
    | 'versao'
    | 'atualizadoEm'
    | 'emitidoEm'
    | 'codigoVerificadorSei'
    | 'codigoCrcSei'
    | 'ultimoEmissionId'
  >;
}


