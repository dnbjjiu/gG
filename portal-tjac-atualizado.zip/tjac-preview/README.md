<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/7d7094f4-635d-4f18-8336-3b972731adb1

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Login Google do portal TJAC

1. No Google Cloud, crie um cliente OAuth do tipo Aplicativo da Web. Configure a audiência como Externa para aceitar a conta Gmail autorizada. Se o aplicativo estiver em teste, cadastre as contas que participarão do teste.
2. Em Origens JavaScript autorizadas, adicione a origem exata da prévia (por exemplo, `http://127.0.0.1:3011`) e a origem de produção.
3. Configure `CLIENT_ID` nas propriedades do Apps Script com o mesmo ID de cliente. Use o `Code.gs` da raiz para publicar o Web App com as ações de análise e copie a URL terminada em `/exec`.
4. Em `.env.local`, configure `VITE_GOOGLE_CLIENT_ID` e `VITE_API_URL`. Reinicie o Vite ou gere um novo build.

O servidor exige uma conta Google verificada, o domínio gerenciado `tjac.jus.br` para contas institucionais e autoriza a exceção `arturgemeos06@gmail.com`. Apenas essa conta e `josue.silva@tjac.jus.br` recebem os perfis privilegiados. Confirme com a equipe do TJAC que o domínio está no Google Workspace. A validação atual usa `tokeninfo`, indicado pelo Google para desenvolvimento. Para produção, use um serviço que valide a assinatura e as demais declarações do token com a biblioteca oficial.
