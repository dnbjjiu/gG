@echo off
cd /d "%~dp0"
set "VITE_MODO_DEMO=true"
npm.cmd run dev -- --host 127.0.0.1 --port 3011 --strictPort --open
