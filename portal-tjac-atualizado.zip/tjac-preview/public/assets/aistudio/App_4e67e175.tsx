import React, { useCallback, useEffect, useState } from 'react';
import { PORTARIA } from './catalogo';
import { Comprovante } from './components/Comprovante';
import { Formulario } from './components/Formulario';
import { Login } from './components/Login';
import { MeusRecursos } from './components/MeusRecursos';
import { Aviso } from './components/ui';
import { MODO_DEMO } from './config';
import { ApiError, api } from './services/api';
import { lerToken, sairGoogle, tokenValido } from './services/auth';
import type { ConfigServidor, ResultadoEnvio, Usuario } from './types';
import { formatarDataHora } from './utils';

type Aba = 'form' | 'meus';
const CHAVE_SESSAO = 'premio-tjac-2026:idtoken';

function sessaoInicial(): { token: string; usuario: Usuario } | null {
  try {
    const t = sessionStorage.getItem(CHAVE_SESSAO);
    if (!t) return null;
    const u = lerToken(t);
    return tokenValido(u) ? { token: t, usuario: u } : null;
  } catch {
    return null;
  }
}

export default function App() {
  const [sessao, setSessao] = useState(sessaoInicial);
  const [config, setConfig] = useState<ConfigServidor | null>(null);
  const [erroConfig, setErroConfig] = useState('');
  const [aba, setAba] = useState<Aba>('form');
  const [resultado, setResultado] = useState<ResultadoEnvio | null>(null);
  const [msgLogin, setMsgLogin] = useState('');

  const onToken = useCallback((token: string) => {
    try {
      const usuario = lerToken(token);
      try { sessionStorage.setItem(CHAVE_SESSAO, token); } catch { /* segue só em memória */ }
      setMsgLogin('');
      setSessao({ token, usuario });
    } catch {
      setMsgLogin('Não foi possível ler a credencial do Google. Tente novamente.');
    }
  }, []);

  const sair = useCallback((mensagem = '') => {
    try { sessionStorage.removeItem(CHAVE_SESSAO); } catch { /* idem */ }
    sairGoogle();
    setSessao(null);
    setConfig(null);
    setMsgLogin(mensagem);
  }, []);

  useEffect(() => {
    if (!sessao) return;
    setErroConfig('');
    api.config(sessao.token).then(setConfig).catch((e) => {
      if (e instanceof ApiError && ['TOKEN_EXPIRADO', 'TOKEN_INVALIDO', 'NAO_AUTENTICADO'].includes(e.codigo)) return sair('Sessão expirada. Entre novamente.');
      if (e instanceof ApiError && ['NAO_AUTORIZADO', 'DOMINIO_NAO_PERMITIDO', 'EMAIL_NAO_VERIFICADO'].includes(e.codigo)) return sair(e.message);
      setErroConfig(e instanceof Error ? e.message : 'Falha ao carregar a configuração.');
    });
  }, [sessao, sair]);

  return (
    <div className="min-h-screen bg-fundo text-tinta font-[Archivo,system-ui,sans-serif]">
      <header className="bg-carmim text-white print:hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.18em] text-white/70">Tribunal de Justiça do Estado do Acre</p>
            <h1 className="text-xl sm:text-2xl font-bold leading-tight">Prêmio TJAC de Qualidade 2026</h1>
            <p className="text-sm text-white/85">Formulário para submissão de recursos contra o Resultado Preliminar</p>
          </div>
          {sessao && (
            <div className="flex items-center gap-3">
              {sessao.usuario.foto && <img src={sessao.usuario.foto} alt="" className="w-9 h-9 rounded-full border-2 border-white/40" referrerPolicy="no-referrer" />}
              <div className="text-right text-sm leading-tight">
                <p className="font-semibold truncate max-w-[200px]">{sessao.usuario.nome}</p>
                <button className="text-white/80 hover:text-white text-xs underline" onClick={() => sair()}>Sair</button>
              </div>
            </div>
          )}
        </div>
        <div className="h-1 bg-gradient-to-r from-ouro via-ouro/70 to-verde" />
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        {MODO_DEMO && sessao && <Aviso tipo="alerta"><b>Modo demonstração</b> — nenhum dado é gravado no Google Drive.</Aviso>}

        {!sessao && <Login onToken={onToken} mensagem={msgLogin} />}

        {sessao && !config && !erroConfig && <p className="text-sm text-suave">Carregando configuração…</p>}
        {sessao && erroConfig && <Aviso tipo="erro">{erroConfig}</Aviso>}

        {sessao && config && (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
              <nav className="inline-flex bg-white border border-linha rounded-lg p-1 text-sm">
                {([['form', 'Novo recurso'], ['meus', 'Meus recursos']] as const).map(([id, rot]) => (
                  <button key={id} onClick={() => setAba(id)}
                    className={`px-4 py-1.5 rounded-md font-medium ${aba === id ? 'bg-carmim text-white' : 'text-suave hover:text-tinta'}`}>{rot}</button>
                ))}
              </nav>
              <p className={`text-xs font-medium ${config.prazo.aberto ? 'text-verde' : 'text-carmim'}`}>
                {config.prazo.aberto ? '● Prazo aberto' : '● Prazo encerrado'} · até {formatarDataHora(config.prazo.fim)}
              </p>
            </div>

            {aba === 'form' && !resultado && (
              <Formulario usuario={sessao.usuario} idToken={sessao.token} config={config}
                onEnviado={(r) => { setResultado(r); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                onSessaoExpirada={() => sair('Sua sessão expirou. Entre novamente: o rascunho foi preservado (anexe os arquivos de novo).')} />
            )}
            {aba === 'form' && resultado && <Comprovante r={resultado} onNovo={() => setResultado(null)} />}
            {aba === 'meus' && <MeusRecursos idToken={sessao.token} />}
          </>
        )}

        <footer className="text-center text-[11px] text-suave pt-6 print:hidden">
          {PORTARIA} · DIGED/SUMAE/SEGOV
        </footer>
      </main>
    </div>
  );
}
