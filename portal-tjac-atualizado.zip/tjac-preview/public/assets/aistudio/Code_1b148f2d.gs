/**
 * ============================================================================
 * PRÊMIO TJAC DE QUALIDADE 2026 — FORMULÁRIO DE RECURSOS (BACK-END)
 * Base normativa: Portaria PRESI/TJAC nº 1961/2026, alterada pela nº 4335/2026
 *   - art. 5º, III, "a"  → prazo final para recursos (7/12/2026)
 *   - art. 13            → recurso objetivo + evidências, sob pena de não conhecimento
 *   - Anexo III, item 3  → evidências obrigatórias (a) a (e)
 * ----------------------------------------------------------------------------
 * Implantação: Apps Script Web App
 *   Executar como: EU (dono)  |  Quem tem acesso: QUALQUER PESSOA
 *   A identidade NÃO vem da sessão do Apps Script: vem do ID Token do Google
 *   (Google Identity Services) enviado pelo front-end e verificado aqui.
 *   Assim, contas @tjac.jus.br e @gmail.com funcionam, e os dados ficam no
 *   Drive do dono (ou drive compartilhado da DIGED), nunca no do usuário.
 * ============================================================================
 */

const VERSAO = '1.0.0';

const CFG = Object.freeze({
  ANO: 2026,
  ABAS: {
    RECURSOS: 'RECURSOS',
    ITENS: 'ITENS',
    ARQUIVOS: 'ARQUIVOS',
    UNIDADES: 'UNIDADES',
    AUTORIZADOS: 'AUTORIZADOS',
    LOG: 'LOG',
  },
  MAX_TEXTO: 4000,
  MIN_TEXTO: 50,
  MAX_ITENS: 40,
  MAX_ARQ_POR_ITEM: 5,
  MAX_BYTES_ARQ: 10 * 1024 * 1024, // 10 MB por arquivo (payload base64 ~13,4 MB < limite de 50 MB do doPost)
  LIMITE_CRIACOES_HORA: 10,
  LIMITE_UPLOADS_HORA: 200,
  MIME_PERMITIDOS: {
    'application/pdf': 'pdf',
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-excel': 'xls',
    'text/csv': 'csv',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  },
  TIPOS_IMPUGNACAO: ['APURACAO', 'APLICABILIDADE', 'FAIXA_ARREDONDAMENTO', 'FONTE_DADOS', 'OUTRO'],
  TIPOS_UNIDADE: [
    'CIVEL', 'FAMILIA', 'FAZENDA', 'EXEC_FISCAL', 'CRIMINAL', 'JURI', 'ROUBO', 'VIOL_DOM',
    'INFANCIA', 'VEP', 'JEC', 'JECRIM', 'JEFAZ', 'TURMA_RECURSAL', 'VARA_UNICA', 'GARANTIAS',
    'GAB_CIVEL', 'GAB_CRIMINAL', 'VICE_PRESIDENCIA', 'SEJUD',
  ],
});

const CABECALHOS = {
  RECURSOS: ['PROTOCOLO', 'STATUS', 'CRIADO_EM', 'ENVIADO_EM', 'EMAIL_GOOGLE', 'NOME', 'CPF', 'CARGO_FUNCAO',
    'TELEFONE', 'GRAU', 'TIPO_UNIDADE', 'COD_UNIDADE', 'UNIDADE', 'COMARCA', 'QTD_ITENS', 'IMPUGNA_LISTA_SERVIDORES',
    'IMPUGNACAO_LISTA_TEXTO', 'PASTA_URL', 'PASTA_ID', 'CLIENT_REQUEST_ID', 'DECLARACAO_VERACIDADE'],
  ITENS: ['PROTOCOLO', 'ITEM_N', 'GRUPO', 'SIGLA', 'INDICADOR', 'SUBITEM', 'TIPO_IMPUGNACAO', 'PONTUACAO_PRELIMINAR',
    'PONTUACAO_PLEITEADA', 'FUNDAMENTACAO', 'EV_A_PAINEL', 'EV_B_FILTROS', 'EV_C_PERIODO', 'EV_D_MEMORIA',
    'EV_E_PROCESSOS', 'PASTA_ITEM_URL', 'QTD_ARQUIVOS', 'STATUS_ANALISE', 'RELATOR', 'PARECER', 'DECISAO',
    'PONTUACAO_FINAL', 'DATA_DECISAO'],
  ARQUIVOS: ['PROTOCOLO', 'ITEM_N', 'SIGLA', 'NOME_ARQUIVO', 'MIME', 'BYTES', 'FILE_ID', 'URL', 'SHA256', 'ENVIADO_EM', 'EMAIL_GOOGLE'],
  UNIDADES: ['CODIGO', 'NOME', 'TIPO', 'GRAU', 'COMARCA', 'ATIVO'],
  AUTORIZADOS: ['EMAIL', 'NOME', 'COD_UNIDADE', 'OBS'],
  LOG: ['TIMESTAMP', 'EMAIL', 'ACAO', 'PROTOCOLO', 'RESULTADO', 'DETALHE'],
};

/* ============================================================================
 * SETUP — executar UMA vez no editor (Executar ▸ setup)
 * ========================================================================== */
function setup() {
  const p = PropertiesService.getScriptProperties();
  let ssId = p.getProperty('SPREADSHEET_ID');
  let ss;
  if (ssId) {
    ss = SpreadsheetApp.openById(ssId);
  } else {
    ss = SpreadsheetApp.create(`Prêmio TJAC ${CFG.ANO} — Recursos (BASE)`);
    ssId = ss.getId();
  }
  Object.keys(CABECALHOS).forEach((k) => {
    const nome = CFG.ABAS[k];
    let sh = ss.getSheetByName(nome) || ss.insertSheet(nome);
    const cab = CABECALHOS[k];
    sh.getRange(1, 1, 1, cab.length).setValues([cab]).setFontWeight('bold').setBackground('#A01928').setFontColor('#FFFFFF');
    sh.setFrozenRows(1);
  });
  const padrao = ss.getSheetByName('Página1') || ss.getSheetByName('Sheet1');
  if (padrao && ss.getSheets().length > 1) ss.deleteSheet(padrao);

  // Validação do TIPO na aba UNIDADES (chaves devem casar com o catálogo do front-end)
  const shU = ss.getSheetByName(CFG.ABAS.UNIDADES);
  shU.getRange('C2:C1000').setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(CFG.TIPOS_UNIDADE, true).setAllowInvalid(false).build());
  shU.getRange('D2:D1000').setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(['1G', '2G'], true).build());
  shU.getRange('F2:F1000').setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(['SIM', 'NAO'], true).build());
  const shI = ss.getSheetByName(CFG.ABAS.ITENS);
  shI.getRange('R2:R5000').setDataValidation(SpreadsheetApp.newDataValidation()
    .requireValueInList(['PENDENTE', 'EM_ANALISE', 'NAO_CONHECIDO', 'PROVIDO', 'PARCIALMENTE_PROVIDO', 'IMPROVIDO'], true).build());

  let rootId = p.getProperty('ROOT_FOLDER_ID');
  if (!rootId) {
    const root = DriveApp.createFolder(`Prêmio TJAC ${CFG.ANO} — Recursos (EVIDÊNCIAS)`);
    rootId = root.getId();
  }

  const defaults = {
    SPREADSHEET_ID: ssId,
    ROOT_FOLDER_ID: rootId,
    PRAZO_INICIO: '2026-12-04T00:00:00-05:00', // art. 5º, II — publicação do Resultado Preliminar
    PRAZO_FIM: '2026-12-07T23:59:59-05:00',    // art. 5º, III, "a" — horário de Rio Branco (UTC-5)
    MODO_ACESSO: 'ABERTO',                      // ABERTO = qualquer conta Google verificada | LISTA = só e-mails da aba AUTORIZADOS
    DOMINIOS_PERMITIDOS: '',                    // ex.: "tjac.jus.br,gmail.com" — vazio = qualquer domínio
    ENVIAR_EMAIL: 'SIM',
    EMAILS_COMISSAO: '',                        // cópia oculta do comprovante, separada por vírgula
    SEQ: p.getProperty('SEQ') || '0',
  };
  Object.keys(defaults).forEach((k) => { if (!p.getProperty(k)) p.setProperty(k, defaults[k]); });

  Logger.log('Planilha: %s', ss.getUrl());
  Logger.log('Pasta raiz: %s', DriveApp.getFolderById(rootId).getUrl());
  Logger.log('FALTA definir a propriedade CLIENT_ID (OAuth Client ID do Google Cloud).');
}

/* ============================================================================
 * ROTEAMENTO HTTP
 * ========================================================================== */
function doGet() {
  return json_({ ok: true, servico: 'recursos-premio-tjac', versao: VERSAO, agora: new Date().toISOString() });
}

function doPost(e) {
  let acao = 'desconhecida';
  let email = '';
  try {
    if (!e || !e.postData || !e.postData.contents) throw new ErroApp('REQ_VAZIA', 'Requisição vazia.');
    const req = JSON.parse(e.postData.contents);
    acao = String(req.action || '');
    const usuario = autenticar_(req.idToken);
    email = usuario.email;

    const rotas = {
      config: () => acaoConfig_(usuario),
      create: () => acaoCriar_(req.payload, usuario),
      upload: () => acaoUpload_(req.payload, usuario),
      finalize: () => acaoFinalizar_(req.payload, usuario),
      myAppeals: () => acaoMeusRecursos_(usuario),
    };
    if (!rotas[acao]) throw new ErroApp('ACAO_INVALIDA', `Ação não suportada: ${acao}`);
    const data = rotas[acao]();
    if (acao !== 'config' && acao !== 'myAppeals') log_(email, acao, data && data.protocolo, 'OK', '');
    return json_({ ok: true, data });
  } catch (err) {
    const codigo = err instanceof ErroApp ? err.codigo : 'ERRO_INTERNO';
    const msg = err instanceof ErroApp ? err.message : 'Erro interno. A equipe da DIGED foi notificada pelo log.';
    try { log_(email, acao, '', codigo, String(err && err.stack || err).slice(0, 1500)); } catch (_) { /* log é best-effort */ }
    return json_({ ok: false, error: { code: codigo, message: msg } });
  }
}

/* ============================================================================
 * AUTENTICAÇÃO — verificação do ID Token (JWT) do Google Identity Services
 * ========================================================================== */
function autenticar_(idToken) {
  if (!idToken || typeof idToken !== 'string' || idToken.length > 4096) {
    throw new ErroApp('NAO_AUTENTICADO', 'Faça login com sua conta Google.');
  }
  const p = PropertiesService.getScriptProperties();
  const clientId = p.getProperty('CLIENT_ID');
  if (!clientId) throw new ErroApp('CONFIG', 'Back-end sem CLIENT_ID configurado.');

  const cache = CacheService.getScriptCache();
  const chave = 'tok_' + sha256Hex_(idToken).slice(0, 40);
  const emCache = cache.get(chave);
  let info;
  if (emCache) {
    info = JSON.parse(emCache);
  } else {
    const resp = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken),
      { muteHttpExceptions: true });
    if (resp.getResponseCode() !== 200) throw new ErroApp('TOKEN_INVALIDO', 'Sessão inválida ou expirada. Entre novamente.');
    info = JSON.parse(resp.getContentText());
  }

  const agora = Math.floor(Date.now() / 1000);
  if (info.aud !== clientId) throw new ErroApp('TOKEN_INVALIDO', 'Token emitido para outra aplicação.');
  if (['accounts.google.com', 'https://accounts.google.com'].indexOf(info.iss) < 0) throw new ErroApp('TOKEN_INVALIDO', 'Emissor do token inválido.');
  if (Number(info.exp) <= agora) throw new ErroApp('TOKEN_EXPIRADO', 'Sessão expirada. Entre novamente.');
  if (String(info.email_verified) !== 'true') throw new ErroApp('EMAIL_NAO_VERIFICADO', 'E-mail da conta Google não verificado.');

  const email = String(info.email).toLowerCase();
  const dominios = (p.getProperty('DOMINIOS_PERMITIDOS') || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (dominios.length && dominios.indexOf(email.split('@')[1]) < 0) {
    throw new ErroApp('DOMINIO_NAO_PERMITIDO', 'Domínio de e-mail não autorizado para este formulário.');
  }
  if ((p.getProperty('MODO_ACESSO') || 'ABERTO') === 'LISTA' && !emailAutorizado_(email)) {
    throw new ErroApp('NAO_AUTORIZADO', 'Seu e-mail não consta na lista de responsáveis autorizados. Procure a DIGED/SUMAE.');
  }

  if (!emCache) {
    const ttl = Math.max(1, Math.min(300, Number(info.exp) - agora));
    cache.put(chave, JSON.stringify(info), ttl);
  }
  return { email, nome: String(info.name || ''), sub: String(info.sub) };
}

function emailAutorizado_(email) {
  const sh = planilha_().getSheetByName(CFG.ABAS.AUTORIZADOS);
  if (sh.getLastRow() < 2) return false;
  const achou = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(email).matchEntireCell(true).matchCase(false).findNext();
  return !!achou;
}

/* ============================================================================
 * AÇÕES
 * ========================================================================== */
function acaoConfig_(usuario) {
  const p = PropertiesService.getScriptProperties();
  const sh = planilha_().getSheetByName(CFG.ABAS.UNIDADES);
  let unidades = [];
  if (sh.getLastRow() > 1) {
    unidades = sh.getRange(2, 1, sh.getLastRow() - 1, CABECALHOS.UNIDADES.length).getValues()
      .filter((r) => r[0] && String(r[5]).toUpperCase() !== 'NAO')
      .map((r) => ({ codigo: String(r[0]), nome: String(r[1]), tipo: String(r[2]), grau: String(r[3]), comarca: String(r[4]) }));
  }
  return {
    usuario,
    prazo: { inicio: p.getProperty('PRAZO_INICIO'), fim: p.getProperty('PRAZO_FIM'), aberto: prazoAberto_() },
    unidades,
    limites: { maxTexto: CFG.MAX_TEXTO, minTexto: CFG.MIN_TEXTO, maxArqPorItem: CFG.MAX_ARQ_POR_ITEM, maxBytesArq: CFG.MAX_BYTES_ARQ, mimes: Object.keys(CFG.MIME_PERMITIDOS) },
    agoraServidor: new Date().toISOString(),
  };
}

function acaoCriar_(payload, usuario) {
  exigirPrazo_();
  limitarTaxa_(usuario.email, 'create', CFG.LIMITE_CRIACOES_HORA);
  const d = validarRecurso_(payload);

  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const ss = planilha_();
    const shR = ss.getSheetByName(CFG.ABAS.RECURSOS);

    // Idempotência: reenvio do mesmo clientRequestId pelo mesmo e-mail devolve o protocolo existente.
    const existente = buscarLinha_(shR, 'CLIENT_REQUEST_ID', d.clientRequestId);
    if (existente) {
      const reg = existente.registro;
      if (reg.EMAIL_GOOGLE !== usuario.email) throw new ErroApp('CONFLITO', 'Identificador de requisição já utilizado.');
      return { protocolo: reg.PROTOCOLO, status: reg.STATUS, reaproveitado: true, itens: itensPastas_(reg.PROTOCOLO) };
    }

    const p = PropertiesService.getScriptProperties();
    const seq = Number(p.getProperty('SEQ') || '0') + 1;
    p.setProperty('SEQ', String(seq));
    const protocolo = `RTQ-${CFG.ANO}-${('00000' + seq).slice(-5)}`;

    const raiz = DriveApp.getFolderById(p.getProperty('ROOT_FOLDER_ID'));
    const pastaUnidade = obterOuCriarPasta_(raiz, nomeSeguro_(`${d.unidade.codigo || 'SC'} - ${d.unidade.nome}`));
    const pastaProt = pastaUnidade.createFolder(protocolo);
    const agora = new Date();

    shR.appendRow([
      protocolo, 'EM_ENVIO', agora, '', usuario.email, d.resp.nome, d.resp.cpf, d.resp.cargo, d.resp.telefone,
      d.unidade.grau, d.unidade.tipo, d.unidade.codigo, d.unidade.nome, d.unidade.comarca, d.itens.length,
      d.listaServidores.impugna ? 'SIM' : 'NAO', d.listaServidores.texto, pastaProt.getUrl(), pastaProt.getId(),
      d.clientRequestId, d.declaracao ? 'SIM' : 'NAO',
    ].map(seguro_));

    const shI = ss.getSheetByName(CFG.ABAS.ITENS);
    const linhas = d.itens.map((it, i) => {
      const n = i + 1;
      const pastaItem = pastaProt.createFolder(nomeSeguro_(`${('0' + n).slice(-2)}_${it.sigla}`));
      return [protocolo, n, it.grupo, it.sigla, it.indicador, it.subitem, it.tipoImpugnacao, it.pontuacaoPreliminar,
        it.pontuacaoPleiteada, it.fundamentacao, sn_(it.evidencias.a), sn_(it.evidencias.b), sn_(it.evidencias.c),
        sn_(it.evidencias.d), sn_(it.evidencias.e), pastaItem.getUrl(), 0, 'PENDENTE', '', '', '', '', ''].map(seguro_);
    });
    if (linhas.length) shI.getRange(shI.getLastRow() + 1, 1, linhas.length, linhas[0].length).setValues(linhas);
    SpreadsheetApp.flush();
    return { protocolo, status: 'EM_ENVIO', reaproveitado: false, itens: itensPastas_(protocolo) };
  } finally {
    lock.releaseLock();
  }
}

function acaoUpload_(payload, usuario) {
  exigirPrazo_();
  limitarTaxa_(usuario.email, 'upload', CFG.LIMITE_UPLOADS_HORA);
  if (!payload) throw new ErroApp('VALIDACAO', 'Arquivo ausente.');
  const protocolo = texto_(payload.protocolo, 20);
  const itemN = Number(payload.itemN);
  const nome = nomeSeguro_(texto_(payload.nome, 180));
  const mime = String(payload.mime || '');
  if (!CFG.MIME_PERMITIDOS[mime]) throw new ErroApp('TIPO_ARQUIVO', `Tipo de arquivo não permitido: ${mime || 'desconhecido'}.`);
  if (!payload.base64 || typeof payload.base64 !== 'string') throw new ErroApp('VALIDACAO', 'Conteúdo do arquivo ausente.');

  const reg = registroDoUsuario_(protocolo, usuario.email);
  if (reg.STATUS !== 'EM_ENVIO') throw new ErroApp('PROTOCOLO_FECHADO', 'Este protocolo já foi finalizado.');

  const bytes = Utilities.base64Decode(payload.base64);
  if (bytes.length === 0) throw new ErroApp('VALIDACAO', 'Arquivo vazio.');
  if (bytes.length > CFG.MAX_BYTES_ARQ) throw new ErroApp('ARQUIVO_GRANDE', `Arquivo acima de ${CFG.MAX_BYTES_ARQ / 1048576} MB.`);
  if (mime === 'application/pdf' && Utilities.newBlob(bytes.slice(0, 4)).getDataAsString() !== '%PDF') {
    throw new ErroApp('TIPO_ARQUIVO', `"${nome}" não é um PDF válido.`);
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const shI = planilha_().getSheetByName(CFG.ABAS.ITENS);
    const item = linhaItem_(shI, protocolo, itemN);
    if (!item) throw new ErroApp('VALIDACAO', 'Item inexistente neste protocolo.');
    const qtd = Number(item.registro.QTD_ARQUIVOS || 0);
    if (qtd >= CFG.MAX_ARQ_POR_ITEM) throw new ErroApp('LIMITE_ARQUIVOS', `Máximo de ${CFG.MAX_ARQ_POR_ITEM} arquivos por item.`);

    const pastaId = String(item.registro.PASTA_ITEM_URL).match(/[-\w]{25,}/)[0];
    const blob = Utilities.newBlob(bytes, mime, nome);
    const arq = DriveApp.getFolderById(pastaId).createFile(blob);
    const hash = sha256Hex_(bytes);

    shI.getRange(item.linha, CABECALHOS.ITENS.indexOf('QTD_ARQUIVOS') + 1).setValue(qtd + 1);
    planilha_().getSheetByName(CFG.ABAS.ARQUIVOS).appendRow([
      protocolo, itemN, item.registro.SIGLA, nome, mime, bytes.length, arq.getId(), arq.getUrl(), hash, new Date(), usuario.email,
    ].map(seguro_));
    return { protocolo, itemN, fileId: arq.getId(), nome, bytes: bytes.length, sha256: hash };
  } finally {
    lock.releaseLock();
  }
}

function acaoFinalizar_(payload, usuario) {
  exigirPrazo_();
  const protocolo = texto_(payload && payload.protocolo, 20);
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  let reg;
  try {
    const shR = planilha_().getSheetByName(CFG.ABAS.RECURSOS);
    const achado = buscarLinha_(shR, 'PROTOCOLO', protocolo);
    if (!achado || achado.registro.EMAIL_GOOGLE !== usuario.email) throw new ErroApp('NAO_ENCONTRADO', 'Protocolo não encontrado.');
    reg = achado.registro;
    if (reg.STATUS === 'ENVIADO') return { protocolo, status: 'ENVIADO', enviadoEm: reg.ENVIADO_EM, reaproveitado: true };

    const itens = itensDoProtocolo_(protocolo);
    const semEvidencia = itens.filter((i) => Number(i.QTD_ARQUIVOS) < 1).map((i) => i.SIGLA);
    if (semEvidencia.length) {
      throw new ErroApp('SEM_EVIDENCIA', `Anexe ao menos uma evidência para: ${semEvidencia.join(', ')} (Anexo III, item 3).`);
    }
    const enviadoEm = new Date();
    shR.getRange(achado.linha, CABECALHOS.RECURSOS.indexOf('STATUS') + 1).setValue('ENVIADO');
    shR.getRange(achado.linha, CABECALHOS.RECURSOS.indexOf('ENVIADO_EM') + 1).setValue(enviadoEm);
    SpreadsheetApp.flush();
    reg.ENVIADO_EM = enviadoEm;
    reg._itens = itens;
  } finally {
    lock.releaseLock();
  }
  try { enviarComprovante_(reg, usuario.email); } catch (e) { log_(usuario.email, 'email', protocolo, 'FALHA_EMAIL', String(e)); }
  return { protocolo, status: 'ENVIADO', enviadoEm: reg.ENVIADO_EM.toISOString(), reaproveitado: false };
}

function acaoMeusRecursos_(usuario) {
  const sh = planilha_().getSheetByName(CFG.ABAS.RECURSOS);
  if (sh.getLastRow() < 2) return { recursos: [] };
  const dados = sh.getRange(2, 1, sh.getLastRow() - 1, CABECALHOS.RECURSOS.length).getValues();
  const iE = CABECALHOS.RECURSOS.indexOf('EMAIL_GOOGLE');
  const recursos = dados.filter((r) => r[iE] === usuario.email).map((r) => {
    const o = objeto_(CABECALHOS.RECURSOS, r);
    const itens = itensDoProtocolo_(o.PROTOCOLO).map((i) => ({
      sigla: i.SIGLA, subitem: i.SUBITEM, statusAnalise: i.STATUS_ANALISE, decisao: i.DECISAO, qtdArquivos: Number(i.QTD_ARQUIVOS),
    }));
    return {
      protocolo: o.PROTOCOLO, status: o.STATUS, unidade: o.UNIDADE,
      criadoEm: o.CRIADO_EM instanceof Date ? o.CRIADO_EM.toISOString() : String(o.CRIADO_EM),
      enviadoEm: o.ENVIADO_EM instanceof Date ? o.ENVIADO_EM.toISOString() : '',
      itens,
    };
  });
  return { recursos: recursos.reverse() };
}

/* ============================================================================
 * VALIDAÇÃO (o back-end NÃO confia no front-end)
 * ========================================================================== */
function validarRecurso_(p) {
  if (!p || typeof p !== 'object') throw new ErroApp('VALIDACAO', 'Dados do recurso ausentes.');
  const erros = [];
  const resp = p.responsavel || {};
  const unidade = p.unidade || {};
  const out = {
    clientRequestId: texto_(p.clientRequestId, 64),
    declaracao: p.declaracao === true,
    resp: {
      nome: texto_(resp.nome, 150),
      cpf: String(resp.cpf || '').replace(/\D/g, ''),
      cargo: texto_(resp.cargo, 120),
      telefone: texto_(resp.telefone, 30),
    },
    unidade: {
      grau: texto_(unidade.grau, 2),
      tipo: texto_(unidade.tipo, 30),
      codigo: texto_(unidade.codigo, 30),
      nome: texto_(unidade.nome, 200),
      comarca: texto_(unidade.comarca, 80),
    },
    listaServidores: {
      impugna: !!(p.listaServidores && p.listaServidores.impugna),
      texto: texto_(p.listaServidores && p.listaServidores.texto, CFG.MAX_TEXTO),
    },
    itens: [],
  };

  if (!/^[\w-]{8,64}$/.test(out.clientRequestId)) erros.push('Identificador de requisição inválido.');
  if (!out.declaracao) erros.push('É obrigatório aceitar a declaração de veracidade.');
  if (out.resp.nome.length < 5) erros.push('Nome do responsável inválido.');
  if (!cpfValido_(out.resp.cpf)) erros.push('CPF inválido.');
  if (out.resp.cargo.length < 3) erros.push('Informe cargo/função.');
  if (['1G', '2G'].indexOf(out.unidade.grau) < 0) erros.push('Grau de jurisdição inválido.');
  if (CFG.TIPOS_UNIDADE.indexOf(out.unidade.tipo) < 0) erros.push('Tipo de unidade inválido.');
  if (out.unidade.nome.length < 3) erros.push('Informe a unidade.');
  if (out.listaServidores.impugna && out.listaServidores.texto.length < CFG.MIN_TEXTO) {
    erros.push(`Fundamente a impugnação da lista de servidores (mín. ${CFG.MIN_TEXTO} caracteres).`);
  }

  const itens = Array.isArray(p.itens) ? p.itens : [];
  if (!itens.length && !out.listaServidores.impugna) erros.push('Selecione ao menos um indicador ou a impugnação da lista de servidores.');
  if (itens.length > CFG.MAX_ITENS) erros.push(`Máximo de ${CFG.MAX_ITENS} itens por protocolo.`);
  const chaves = {};
  itens.forEach((it, i) => {
    const rot = `Item ${i + 1}`;
    const ev = it.evidencias || {};
    const o = {
      grupo: texto_(it.grupo, 60),
      sigla: texto_(it.sigla, 30),
      indicador: texto_(it.indicador, 200),
      subitem: texto_(it.subitem, 120),
      tipoImpugnacao: texto_(it.tipoImpugnacao, 30),
      pontuacaoPreliminar: numeroOuVazio_(it.pontuacaoPreliminar),
      pontuacaoPleiteada: numeroOuVazio_(it.pontuacaoPleiteada),
      fundamentacao: String(it.fundamentacao || '').trim(),
      evidencias: { a: ev.a === true, b: ev.b === true, c: ev.c === true, d: ev.d === true, e: ev.e === true },
    };
    if (!/^[A-Za-z0-9/\-]{2,30}$/.test(o.sigla)) erros.push(`${rot}: sigla inválida.`);
    if (CFG.TIPOS_IMPUGNACAO.indexOf(o.tipoImpugnacao) < 0) erros.push(`${rot} (${o.sigla}): tipo de impugnação inválido.`);
    if (o.fundamentacao.length < CFG.MIN_TEXTO) erros.push(`${rot} (${o.sigla}): fundamentação com menos de ${CFG.MIN_TEXTO} caracteres.`);
    if (o.fundamentacao.length > CFG.MAX_TEXTO) erros.push(`${rot} (${o.sigla}): fundamentação acima de ${CFG.MAX_TEXTO} caracteres.`);
    if (!(o.evidencias.a && o.evidencias.b && o.evidencias.c && o.evidencias.d && o.evidencias.e)) {
      erros.push(`${rot} (${o.sigla}): confirme as cinco evidências obrigatórias do Anexo III, item 3.`);
    }
    const k = `${o.sigla}|${o.subitem}`;
    if (chaves[k]) erros.push(`${rot}: indicador/subitem duplicado (${o.sigla} ${o.subitem}).`);
    chaves[k] = true;
    out.itens.push(o);
  });

  if (erros.length) throw new ErroApp('VALIDACAO', erros.join(' | '));
  return out;
}

function cpfValido_(c) {
  if (!/^\d{11}$/.test(c) || /^(\d)\1{10}$/.test(c)) return false;
  const dv = (base) => {
    let s = 0;
    for (let i = 0; i < base.length; i++) s += Number(base[i]) * (base.length + 1 - i);
    const r = (s * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return dv(c.slice(0, 9)) === Number(c[9]) && dv(c.slice(0, 10)) === Number(c[10]);
}

/* ============================================================================
 * INFRA
 * ========================================================================== */
function ErroApp(codigo, mensagem) {
  this.codigo = codigo;
  this.message = mensagem;
  this.stack = new Error(mensagem).stack;
}
ErroApp.prototype = Object.create(Error.prototype);

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

let _ss = null;
function planilha_() {
  if (!_ss) {
    const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
    if (!id) throw new ErroApp('CONFIG', 'Execute a função setup() antes de publicar.');
    _ss = SpreadsheetApp.openById(id);
  }
  return _ss;
}

function prazoAberto_() {
  const p = PropertiesService.getScriptProperties();
  const agora = Date.now();
  const ini = Date.parse(p.getProperty('PRAZO_INICIO'));
  const fim = Date.parse(p.getProperty('PRAZO_FIM'));
  return (!isNaN(ini) ? agora >= ini : true) && (!isNaN(fim) ? agora <= fim : true);
}

function exigirPrazo_() {
  if (!prazoAberto_()) {
    throw new ErroApp('FORA_DO_PRAZO', 'Fora do prazo recursal (art. 5º, III, "a", da Portaria PRESI nº 1961/2026).');
  }
}

function limitarTaxa_(email, acao, limite) {
  const cache = CacheService.getScriptCache();
  const chave = `rl_${acao}_${sha256Hex_(email).slice(0, 24)}`;
  const n = Number(cache.get(chave) || '0') + 1;
  if (n > limite) throw new ErroApp('LIMITE_TAXA', 'Muitas requisições. Aguarde alguns minutos e tente novamente.');
  cache.put(chave, String(n), 3600);
}

function buscarLinha_(sh, coluna, valor) {
  if (!valor || sh.getLastRow() < 2) return null;
  const cab = CABECALHOS[chaveAba_(sh.getName())];
  const col = cab.indexOf(coluna) + 1;
  const cel = sh.getRange(2, col, sh.getLastRow() - 1, 1).createTextFinder(String(valor)).matchEntireCell(true).findNext();
  if (!cel) return null;
  const linha = cel.getRow();
  return { linha, registro: objeto_(cab, sh.getRange(linha, 1, 1, cab.length).getValues()[0]) };
}

function registroDoUsuario_(protocolo, email) {
  const achado = buscarLinha_(planilha_().getSheetByName(CFG.ABAS.RECURSOS), 'PROTOCOLO', protocolo);
  if (!achado || achado.registro.EMAIL_GOOGLE !== email) throw new ErroApp('NAO_ENCONTRADO', 'Protocolo não encontrado.');
  return achado.registro;
}

function linhaItem_(shI, protocolo, itemN) {
  if (shI.getLastRow() < 2) return null;
  const cab = CABECALHOS.ITENS;
  const dados = shI.getRange(2, 1, shI.getLastRow() - 1, cab.length).getValues();
  for (let i = 0; i < dados.length; i++) {
    if (dados[i][0] === protocolo && Number(dados[i][1]) === itemN) return { linha: i + 2, registro: objeto_(cab, dados[i]) };
  }
  return null;
}

function itensDoProtocolo_(protocolo) {
  const sh = planilha_().getSheetByName(CFG.ABAS.ITENS);
  if (sh.getLastRow() < 2) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, CABECALHOS.ITENS.length).getValues()
    .filter((r) => r[0] === protocolo).map((r) => objeto_(CABECALHOS.ITENS, r));
}

function itensPastas_(protocolo) {
  return itensDoProtocolo_(protocolo).map((i) => ({ itemN: Number(i.ITEM_N), sigla: i.SIGLA, subitem: i.SUBITEM, qtdArquivos: Number(i.QTD_ARQUIVOS) }));
}

function obterOuCriarPasta_(pai, nome) {
  const it = pai.getFoldersByName(nome);
  return it.hasNext() ? it.next() : pai.createFolder(nome);
}

function enviarComprovante_(reg, email) {
  const p = PropertiesService.getScriptProperties();
  if ((p.getProperty('ENVIAR_EMAIL') || 'SIM') !== 'SIM') return;
  const itens = (reg._itens || []).map((i) => `<li><b>${esc_(i.SIGLA)}</b>${i.SUBITEM ? ' — ' + esc_(i.SUBITEM) : ''} (${Number(i.QTD_ARQUIVOS)} arquivo[s])</li>`).join('');
  const html = `<div style="font-family:Arial,sans-serif;color:#1f1f1f">
    <h2 style="color:#A01928;margin:0">Prêmio TJAC de Qualidade ${CFG.ANO}</h2>
    <p>Comprovante de interposição de recurso contra o Resultado Preliminar.</p>
    <p><b>Protocolo:</b> ${esc_(reg.PROTOCOLO)}<br><b>Unidade:</b> ${esc_(reg.UNIDADE)}<br>
    <b>Responsável:</b> ${esc_(reg.NOME)}<br><b>Enviado em:</b> ${Utilities.formatDate(reg.ENVIADO_EM, 'America/Rio_Branco', 'dd/MM/yyyy HH:mm:ss')} (Rio Branco)</p>
    <p><b>Itens impugnados:</b></p><ul>${itens || '<li>Somente impugnação da lista de servidores vinculados</li>'}</ul>
    ${reg.IMPUGNA_LISTA_SERVIDORES === 'SIM' ? '<p>Inclui impugnação da lista de servidores vinculados (art. 5º, III, "b").</p>' : ''}
    <p style="font-size:12px;color:#666">O resultado da avaliação dos recursos será divulgado por ocasião da outorga do Prêmio (art. 14 da Portaria PRESI nº 1961/2026).</p></div>`;
  const bcc = (p.getProperty('EMAILS_COMISSAO') || '').trim();
  const opts = { htmlBody: html, name: 'Prêmio TJAC de Qualidade — DIGED/SUMAE' };
  if (bcc) opts.bcc = bcc;
  MailApp.sendEmail(email, `[Prêmio TJAC ${CFG.ANO}] Recurso ${reg.PROTOCOLO} recebido`, 'Seu recurso foi recebido.', opts);
}

function log_(email, acao, protocolo, resultado, detalhe) {
  planilha_().getSheetByName(CFG.ABAS.LOG).appendRow([new Date(), email || '', acao, protocolo || '', resultado, detalhe || ''].map(seguro_));
}

/* ---- helpers puros ---- */
function chaveAba_(nome) { return Object.keys(CFG.ABAS).filter((k) => CFG.ABAS[k] === nome)[0]; }
function objeto_(cab, linha) { const o = {}; cab.forEach((c, i) => { o[c] = linha[i]; }); return o; }
function texto_(v, max) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max); }
function numeroOuVazio_(v) { if (v === '' || v == null) return ''; const n = Number(String(v).replace(',', '.')); return isFinite(n) && n >= 0 && n <= 1000 ? n : ''; }
function sn_(b) { return b ? 'SIM' : 'NAO'; }
/** Neutraliza injeção de fórmula em planilhas (=, +, -, @). */
function seguro_(v) { if (typeof v !== 'string') return v; return /^[=+\-@\t\r]/.test(v) ? "'" + v : v; }
function nomeSeguro_(s) { return String(s).replace(/[\\/:*?"<>|#%\u0000-\u001F]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'arquivo'; }
function esc_(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function sha256Hex_(dados) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, dados);
  return bytes.map((b) => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
}
